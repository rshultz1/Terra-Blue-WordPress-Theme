<?php
/**
 * The template for displaying all pages
 *
 * @package Terra-Blue
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<div class="nx-single-wrap">

	<?php while ( have_posts() ) : the_post(); ?>

	<article id="post-<?php the_ID(); ?>" <?php post_class( 'nx-page' ); ?>>

		<?php if ( ! is_front_page() ) : ?>
		<header class="nx-page__header">
			<h1 class="nx-page__title"><?php the_title(); ?></h1>
		</header>
		<?php endif; ?>

		<div class="nx-page__content">
			<?php
			the_content();
			wp_link_pages( array(
				'before' => '<nav class="nx-page-links"><span>' . esc_html__( 'Pages:', 'terra-blue' ) . '</span>',
				'after'  => '</nav>',
			) );
			?>
		</div>

		<?php if ( comments_open() || get_comments_number() ) : ?>
		<?php comments_template(); ?>
		<?php endif; ?>

	</article>

	<?php endwhile; ?>

</div>

<?php get_footer(); ?>
