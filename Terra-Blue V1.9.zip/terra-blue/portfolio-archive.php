<?php
defined( 'ABSPATH' ) || exit;
/**
 * Template Name: Portfolio Archive
 * Description: A masonry-style grid for showcasing portfolio items.
 *
 * @package Terra-Blue
 */

get_header(); ?>

<div class="nx-container-wide nx-section nx-portfolio-archive-template">

	<header class="nx-archive-header">
		<?php the_title( '<h1 class="nx-archive-title">', '</h1>' ); ?>
		<?php if ( has_excerpt() ) : ?>
			<div class="nx-archive-description"><?php the_excerpt(); ?></div>
		<?php endif; ?>
	</header>

	<?php
	$portfolio_query = new WP_Query( array(
		'post_type'      => 'portfolio',
		'posts_per_page' => 12,
		'paged'          => max( 1, get_query_var( 'paged' ) ),
	) );
	?>

	<?php if ( $portfolio_query->have_posts() ) : ?>

		<div class="nx-portfolio-grid nx-stagger">
			<?php while ( $portfolio_query->have_posts() ) : $portfolio_query->the_post(); ?>

				<article <?php post_class( 'nx-card nx-portfolio-card nx-reveal' ); ?>>
					<?php if ( has_post_thumbnail() ) : ?>
					<a class="nx-portfolio-card__thumbnail" href="<?php the_permalink(); ?>">
						<?php the_post_thumbnail( 'terra-blue-card', array( 'loading' => 'lazy' ) ); ?>
					</a>
					<?php endif; ?>
					<div class="nx-portfolio-card__body">
						<h2 class="nx-portfolio-card__title">
							<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
						</h2>
						<?php if ( has_excerpt() ) : ?>
						<p class="nx-portfolio-card__excerpt"><?php echo wp_trim_words( get_the_excerpt(), 15, '&hellip;' ); ?></p>
						<?php endif; ?>
					</div>
				</article>

			<?php endwhile; ?>
		</div>

		<?php
		echo paginate_links( array(
			'total'   => $portfolio_query->max_num_pages,
			'current' => max( 1, get_query_var( 'paged' ) ),
		) );
		wp_reset_postdata();
		?>

	<?php else : ?>

		<div class="entry-content nx-entry-content">
			<?php the_content(); ?>
		</div>

	<?php endif; ?>

</div>

<?php get_footer(); ?>
