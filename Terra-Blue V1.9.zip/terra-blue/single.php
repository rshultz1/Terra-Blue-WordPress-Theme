<?php
/**
 * The template for displaying all single posts
 *
 * @package Terra-Blue
 */

defined( 'ABSPATH' ) || exit;

get_header();

$post_id       = get_the_ID();
$hero_style    = get_post_meta( $post_id, '_terra_blue_hero_style', true ) ?: get_theme_mod( 'terra_blue_post_hero_style', 'standard' );
$show_toc      = get_theme_mod( 'terra_blue_show_toc', true );
$show_author   = get_theme_mod( 'terra_blue_show_author_box', true );
$show_share    = get_theme_mod( 'terra_blue_show_social_share', true );
$show_nav      = get_theme_mod( 'terra_blue_show_post_nav', true );
?>

<style>
/* Single post nuclear containment — injected inline to guarantee priority */
.nx-single-wrap{width:100%;max-width:100%;overflow-x:clip;padding:0 16px;box-sizing:border-box}
.nx-single-wrap .nx-single-post{display:block!important;width:100%!important;max-width:700px!important;margin:0 auto!important;padding:0!important;overflow:hidden!important;overflow-wrap:break-word!important;word-break:break-word!important;box-sizing:border-box!important;float:none!important;position:relative!important}
.nx-single-wrap .nx-single-post *{max-width:100%!important;box-sizing:border-box!important}
.nx-single-wrap .nx-single-post img,.nx-single-wrap .nx-single-post iframe,.nx-single-wrap .nx-single-post video,.nx-single-wrap .nx-single-post embed,.nx-single-wrap .nx-single-post object,.nx-single-wrap .nx-single-post table,.nx-single-wrap .nx-single-post pre{max-width:100%!important;height:auto!important}
.nx-single-wrap .nx-single-post table{display:block!important;overflow-x:auto!important}
.nx-single-wrap .nx-single-post .jp-relatedposts,.nx-single-wrap .nx-single-post .sharedaddy,.nx-single-wrap .nx-single-post .sd-block,.nx-single-wrap .nx-single-post .wpcnt{max-width:100%!important;overflow:hidden!important;box-sizing:border-box!important}
.nx-single-wrap .nx-single-post .jp-relatedposts-items{display:flex!important;flex-wrap:wrap!important;gap:12px!important}
.nx-single-wrap .nx-single-post .jp-relatedposts-post{flex:1 1 180px!important;min-width:0!important;max-width:100%!important}
</style>

<?php if ( $hero_style === 'full' && has_post_thumbnail() ) : ?>
<div class="nx-post-hero nx-post-hero--full">
	<div class="nx-post-hero__image">
		<?php the_post_thumbnail( 'terra-blue-hero' ); ?>
		<div class="nx-post-hero__overlay"></div>
	</div>
	<div class="nx-post-hero__content nx-container-wide">
		<?php terra_blue_post_categories(); ?>
		<h1 class="nx-post-hero__title"><?php the_title(); ?></h1>
		<?php terra_blue_post_meta_full(); ?>
	</div>
</div>
<?php endif; ?>

<div class="nx-single-wrap" style="width:100%;max-width:100%;overflow-x:clip;padding:0 16px;box-sizing:border-box">

	<article id="post-<?php the_ID(); ?>" <?php post_class( 'nx-single-post' ); ?> style="display:block!important;width:100%!important;max-width:700px!important;margin:0 auto!important;overflow:hidden!important;box-sizing:border-box!important" itemscope itemtype="https://schema.org/Article">

		<?php if ( $hero_style !== 'full' ) : ?>
		<header class="nx-single-post__header" style="text-align:center;padding:3rem 0 1.5rem;max-width:100%">
			<?php terra_blue_post_categories(); ?>
			<h1 class="nx-single-post__title" itemprop="headline" style="font-size:clamp(1.5rem,4vw,2.5rem);font-weight:700;line-height:1.2;margin-bottom:1.25rem;overflow-wrap:break-word;word-break:break-word"><?php the_title(); ?></h1>
			<?php terra_blue_post_meta_full(); ?>
			<?php if ( $hero_style === 'standard' && has_post_thumbnail() ) : ?>
			<div class="nx-single-post__thumbnail" style="margin:1rem 0 2.5rem;border-radius:16px;overflow:hidden;max-width:100%">
				<?php the_post_thumbnail( 'terra-blue-hero', array( 'itemprop' => 'image', 'class' => 'nx-single-post__img', 'style' => 'width:100%;height:auto;display:block;max-width:100%' ) ); ?>
			</div>
			<?php endif; ?>
		</header>
		<?php endif; ?>

		<div class="nx-single-post__body" itemprop="articleBody" style="width:100%;max-width:100%;overflow:hidden">
			<?php if ( $show_toc ) : ?>
			<div class="nx-toc" id="nx-toc" aria-label="<?php esc_attr_e( 'Table of contents', 'terra-blue' ); ?>">
				<div class="nx-toc__header">
					<span class="nx-toc__title"><?php esc_html_e( 'On This Page', 'terra-blue' ); ?></span>
				</div>
				<nav class="nx-toc__nav" id="nx-toc-list"></nav>
			</div>
			<?php endif; ?>

			<div class="nx-post-content" itemprop="text" style="width:100%;max-width:100%;overflow:hidden;overflow-wrap:break-word;word-break:break-word">
				<?php the_content(); ?>
				<?php wp_link_pages( array(
					'before' => '<nav class="nx-page-links"><span>' . esc_html__( 'Pages:', 'terra-blue' ) . '</span>',
					'after'  => '</nav>',
				) ); ?>
			</div>

			<?php if ( has_tag() ) : ?>
			<footer class="nx-post-tags">
				<span class="nx-post-tags__label"><?php esc_html_e( 'Tagged:', 'terra-blue' ); ?></span>
				<?php the_tags( '', '', '' ); ?>
			</footer>
			<?php endif; ?>
		</div>

		<?php if ( $show_share ) : ?>
		<div class="nx-share-bar">
			<span class="nx-share-bar__label"><?php esc_html_e( 'Share this post', 'terra-blue' ); ?></span>
			<div class="nx-share-bar__links">
				<?php if ( function_exists( 'terra_blue_share_links' ) ) terra_blue_share_links(); ?>
			</div>
		</div>
		<?php endif; ?>

		<?php if ( $show_nav ) : ?>
		<nav class="nx-post-nav" aria-label="<?php esc_attr_e( 'Post navigation', 'terra-blue' ); ?>">
			<?php
			$prev = get_previous_post();
			$next = get_next_post();
			?>
			<?php if ( $prev ) : ?>
			<a class="nx-post-nav__item nx-post-nav__item--prev" href="<?php echo esc_url( get_permalink( $prev ) ); ?>">
				<span class="nx-post-nav__direction">
					<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg>
					<?php esc_html_e( 'Previous', 'terra-blue' ); ?>
				</span>
				<span class="nx-post-nav__title"><?php echo esc_html( get_the_title( $prev ) ); ?></span>
			</a>
			<?php endif; ?>
			<?php if ( $next ) : ?>
			<a class="nx-post-nav__item nx-post-nav__item--next" href="<?php echo esc_url( get_permalink( $next ) ); ?>">
				<span class="nx-post-nav__direction">
					<?php esc_html_e( 'Next', 'terra-blue' ); ?>
					<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
				</span>
				<span class="nx-post-nav__title"><?php echo esc_html( get_the_title( $next ) ); ?></span>
			</a>
			<?php endif; ?>
		</nav>
		<?php endif; ?>

		<?php if ( $show_author && function_exists( 'terra_blue_author_box' ) ) : terra_blue_author_box(); endif; ?>

		<?php comments_template(); ?>

	</article>

</div>

<?php get_footer(); ?>
