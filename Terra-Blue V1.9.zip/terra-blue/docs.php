<?php
defined( 'ABSPATH' ) || exit;
/**
 * Template Name: Documentation
 * Description: A documentation layout with table of contents sidebar.
 *
 * @package Terra-Blue
 */

get_header(); ?>

<div class="nx-container-wide nx-section nx-docs-template">

	<div class="nx-docs-layout">

		<aside class="nx-docs-sidebar" role="complementary">
			<nav class="nx-docs-toc" aria-label="<?php esc_attr_e( 'Table of Contents', 'terra-blue' ); ?>">
				<h2 class="nx-docs-toc__title"><?php esc_html_e( 'On this page', 'terra-blue' ); ?></h2>
				<div class="nx-docs-toc__links" id="nx-docs-toc"></div>
			</nav>
			<?php if ( is_active_sidebar( 'sidebar-docs' ) ) : ?>
				<?php dynamic_sidebar( 'sidebar-docs' ); ?>
			<?php endif; ?>
		</aside>

		<div class="nx-docs-main">

			<?php while ( have_posts() ) : the_post(); ?>

				<article id="post-<?php the_ID(); ?>" <?php post_class( 'nx-docs-article' ); ?>>

					<header class="nx-page-header">
						<?php the_title( '<h1 class="nx-page-title">', '</h1>' ); ?>
						<?php if ( function_exists( 'terra_blue_breadcrumbs' ) ) : ?>
							<?php terra_blue_breadcrumbs(); ?>
						<?php endif; ?>
					</header>

					<div class="entry-content nx-entry-content nx-prose">
						<?php
						the_content();
						wp_link_pages( array(
							'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'terra-blue' ),
							'after'  => '</div>',
						) );
						?>
					</div>

				</article>

				<?php if ( comments_open() || get_comments_number() ) : ?>
					<?php comments_template(); ?>
				<?php endif; ?>

			<?php endwhile; ?>

		</div>

	</div>

</div>

<?php get_footer(); ?>
