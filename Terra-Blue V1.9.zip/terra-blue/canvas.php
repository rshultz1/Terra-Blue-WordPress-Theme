<?php
/**
 * Template Name: Blank Canvas
 * Description: A completely blank canvas — header and footer are omitted. Perfect for custom block layouts.
 *
 * @package Terra-Blue
 */

defined( 'ABSPATH' ) || exit;
?>
<!doctype html>
<html <?php language_attributes(); ?> data-theme="dark">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<?php wp_head(); ?>
</head>
<body <?php body_class( 'nx-canvas-template' ); ?>>
<?php wp_body_open(); ?>

<div id="page" class="site">
	<main id="main" class="site-main" role="main">

		<?php while ( have_posts() ) : the_post(); ?>

			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
				<div class="entry-content nx-entry-content">
					<?php the_content(); ?>
				</div>
			</article>

		<?php endwhile; ?>

	</main>
</div>

<?php wp_footer(); ?>
</body>
</html>
