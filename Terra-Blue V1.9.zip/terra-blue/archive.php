<?php
/**
 * The template for displaying archive pages
 *
 * @package Terra-Blue
 */

defined( 'ABSPATH' ) || exit;


get_header();

$blog_layout = get_theme_mod( 'terra_blue_blog_layout', 'grid' );
$columns     = get_theme_mod( 'terra_blue_blog_columns', '3' );
?>

<main id="main" class="nx-site-main">
<div class="nx-container-wide">

	<header class="nx-archive-header nx-reveal">
		<div class="nx-archive-header__inner">
			<?php if ( is_category() ) : ?>
				<div class="nx-badge nx-badge--accent"><?php esc_html_e( 'Category', 'terra-blue' ); ?></div>
				<h1 class="nx-archive-header__title"><?php single_cat_title(); ?></h1>
				<?php if ( category_description() ) : ?>
				<p class="nx-archive-header__desc"><?php echo wp_kses_post( category_description() ); ?></p>
				<?php endif; ?>

			<?php elseif ( is_tag() ) : ?>
				<div class="nx-badge"><?php esc_html_e( 'Tag', 'terra-blue' ); ?></div>
				<h1 class="nx-archive-header__title">
					<span class="nx-gradient-text">#</span><?php single_tag_title(); ?>
				</h1>

			<?php elseif ( is_author() ) : ?>
				<div class="nx-archive-author">
					<?php echo get_avatar( get_the_author_meta( 'ID' ), 80, '', '', array( 'class' => 'nx-archive-author__avatar' ) ); ?>
					<div>
						<div class="nx-badge"><?php esc_html_e( 'Author', 'terra-blue' ); ?></div>
						<h1 class="nx-archive-header__title"><?php the_author(); ?></h1>
						<?php if ( get_the_author_meta( 'description' ) ) : ?>
						<p class="nx-archive-header__desc"><?php the_author_meta( 'description' ); ?></p>
						<?php endif; ?>
					</div>
				</div>

			<?php elseif ( is_date() ) : ?>
				<div class="nx-badge"><?php esc_html_e( 'Archive', 'terra-blue' ); ?></div>
				<h1 class="nx-archive-header__title">
					<?php
					if ( is_year() ) {
						echo esc_html( get_the_date( 'Y' ) );
					} elseif ( is_month() ) {
						echo esc_html( get_the_date( 'F Y' ) );
					} else {
						echo esc_html( get_the_date( get_option( 'date_format' ) ) );
					}
					?>
				</h1>

			<?php else : ?>
				<?php the_archive_title( '<h1 class="nx-archive-header__title">', '</h1>' ); ?>
				<?php the_archive_description( '<p class="nx-archive-header__desc">', '</p>' ); ?>
			<?php endif; ?>
		</div>
	</header>

	<?php if ( have_posts() ) : ?>

	<div class="nx-posts-grid nx-posts-grid--<?php echo esc_attr( $blog_layout ); ?> nx-posts-grid--cols-<?php echo esc_attr( $columns ); ?>" id="nx-posts-container">
		<?php
		while ( have_posts() ) :
			the_post();
			get_template_part( 'template-parts/post-card' );
		endwhile;
		?>
	</div>

	<?php terra_blue_pagination(); ?>

	<?php else : ?>
		<?php get_template_part( 'template-parts/content', 'none' ); ?>
	<?php endif; ?>

</div>
</main>

<?php get_footer(); ?>
