Terra-Blue
=================

Contributors: robertshultz
Requires at least: WordPress 6.3
Tested up to: WordPress 6.7
Requires PHP: 7.4
Stable tag: 1.3.0
License: GNU General Public License v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A professional, modern WordPress theme with dark-first design, fluid typography, WooCommerce integration, and accessibility-ready markup.


Description
-----------

Terra-Blue is a highly polished, developer-friendly WordPress theme built for creatives and professionals. It ships with a complete design token system, dark/light mode switching, glass-morphism UI components, Gutenberg block patterns, custom block style variations, WooCommerce support, and a performance-optimised JavaScript bundle.

Key Features:

* Full Site Editing (FSE) compatible — theme.json v3
* Dark-first design with user-controllable theme toggle
* Fluid typography via CSS clamp() from xs–5xl scale
* CSS Grid and Flexbox layouts throughout
* 5 Custom Post Types: Portfolio, Testimonial, FAQ, Team Member, Case Study
* 5 Custom Block Patterns: Hero, Features Grid, CTA Banner, Testimonials, Pricing
* 20+ Custom Block Style Variations
* Live WordPress Customizer with 11 sections
* WooCommerce: shop, single product, cart, checkout, account pages styled
* WCAG 2.1 AA accessibility — skip links, ARIA labels, focus-visible states, reduced-motion support
* Schema.org structured data for articles
* Open Graph + Twitter Card meta tags
* Infinite scroll (optional), reading progress bar, table of contents
* AJAX-powered live search
* RTL language support
* Translation-ready with .pot file included


Installation
------------

1. Log in to your WordPress admin dashboard.
2. Navigate to Appearance → Themes → Add New → Upload Theme.
3. Upload the terra-blue.zip file.
4. Activate the theme.
5. Optionally, navigate to Appearance → Customise to configure colours, typography, header and footer options.


Frequently Asked Questions
--------------------------

Does this theme require a page builder?

No. Terra-Blue is built entirely with the native WordPress Block Editor (Gutenberg) and does not require any page builder plugin.

Is WooCommerce required?

No. WooCommerce integration is optional. The theme detects WooCommerce automatically and loads shop styles only when needed.

Does the theme support Full Site Editing?

Yes. The theme ships with a theme.json v3 configuration and supports all FSE features available in WordPress 6.3+.


Changelog
---------

1.0.0
* Initial release.


Copyright
---------

Terra-Blue WordPress Theme, Copyright 2024 Robert Shultz.
Terra-Blue is distributed under the terms of the GNU GPL v2 or later.

This theme bundles the following third-party resources:

** Fonts (Google Fonts — served via self-hosted CDN request):
   - Instrument Sans, Instrument Serif — License: SIL Open Font License 1.1 — https://fonts.google.com/specimen/Instrument+Sans
   - Syne — License: SIL Open Font License 1.1 — https://fonts.google.com/specimen/Syne
   - JetBrains Mono — License: SIL Open Font License 1.1 — https://fonts.google.com/specimen/JetBrains+Mono

** Screenshot image:
   Procedurally generated — no third-party image assets used.
