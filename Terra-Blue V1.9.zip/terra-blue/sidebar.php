<?php
/**
 * The sidebar template
 *
 * @package Terra-Blue
 */

defined( 'ABSPATH' ) || exit;


if ( ! is_active_sidebar( 'sidebar-1' ) ) {
	return;
}
?>

<div class="nx-sidebar" id="secondary" role="complementary">
	<?php dynamic_sidebar( 'sidebar-1' ); ?>
</div>
