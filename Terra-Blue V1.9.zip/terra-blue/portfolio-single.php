<?php
defined( 'ABSPATH' ) || exit;
/**
 * Template Name: Portfolio Single
 * Description: A showcase layout for individual portfolio items.
 *
 * @package Terra-Blue
 */

get_header(); ?>

<div class="nx-container-wide nx-section nx-portfolio-single-template">

	<?php while ( have_posts() ) : the_post(); ?>

		<article id="post-<?php the_ID(); ?>" <?php post_class( 'nx-portfolio-single' ); ?>>

			<?php if ( has_post_thumbnail() ) : ?>
			<div class="nx-portfolio-hero">
				<?php the_post_thumbnail( 'terra-blue-hero', array( 'class' => 'nx-portfolio-hero__img' ) ); ?>
			</div>
			<?php endif; ?>

			<header class="nx-page-header">
				<?php the_title( '<h1 class="nx-page-title">', '</h1>' ); ?>
				<?php if ( function_exists( 'terra_blue_breadcrumbs' ) ) : ?>
					<?php terra_blue_breadcrumbs(); ?>
				<?php endif; ?>
			</header>

			<div class="entry-content nx-entry-content">
				<?php the_content(); ?>
			</div>

			<nav class="nx-post-navigation" aria-label="<?php esc_attr_e( 'Portfolio navigation', 'terra-blue' ); ?>">
				<div class="nx-post-navigation__prev">
					<?php previous_post_link( '%link', '&larr; %title' ); ?>
				</div>
				<div class="nx-post-navigation__next">
					<?php next_post_link( '%link', '%title &rarr;' ); ?>
				</div>
			</nav>

		</article>

		<?php if ( comments_open() || get_comments_number() ) : ?>
			<?php comments_template(); ?>
		<?php endif; ?>

	<?php endwhile; ?>

</div>

<?php get_footer(); ?>
