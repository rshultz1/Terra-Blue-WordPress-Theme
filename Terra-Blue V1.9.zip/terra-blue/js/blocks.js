/**
 * Terra-Blue — Block Editor Enhancements
 * Loaded via enqueue_block_editor_assets.
 * Adds custom block styles and editor UI tweaks.
 */
( function( wp ) {
	'use strict';

	var registerBlockStyle = wp.blocks && wp.blocks.registerBlockStyle;
	if ( ! registerBlockStyle ) return;

	/* ── Button styles ────────────────────────────── */
	registerBlockStyle( 'core/button', {
		name: 'nx-outline',
		label: 'Outline',
	} );
	registerBlockStyle( 'core/button', {
		name: 'nx-ghost',
		label: 'Ghost',
	} );

	/* ── Image styles ─────────────────────────────── */
	registerBlockStyle( 'core/image', {
		name: 'nx-rounded',
		label: 'Rounded',
	} );
	registerBlockStyle( 'core/image', {
		name: 'nx-frame',
		label: 'Framed',
	} );

	/* ── Separator styles ─────────────────────────── */
	registerBlockStyle( 'core/separator', {
		name: 'nx-gradient',
		label: 'Gradient',
	} );

	/* ── Quote styles ─────────────────────────────── */
	registerBlockStyle( 'core/quote', {
		name: 'nx-callout',
		label: 'Callout',
	} );

} )( window.wp || {} );
