/**
 * Terra-Blue — Core JavaScript
 * @version 1.0.0
 */

( function() {
  'use strict';

  // ─── Data & Config ────────────────────────────────────────────────────────
  const DATA    = window.TT6ixData || {};
  const REDUCED = window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;

  // ─── DOM Ready (handles defer scripts where DOMContentLoaded already fired) ─
  if ( document.readyState === 'loading' ) {
    document.addEventListener( 'DOMContentLoaded', init );
  } else {
    init();
  }

  function init() {
    setupThemeToggle();
    setupMobileMenu();
    setupSearchOverlay();
    setupStickyHeader();
    setupScrollReveal();
    setupBackToTop();
    setupCodeCopy();
    setupLiveSearch();
    setupSmoothScroll();
    setupCookieNotice();
    setupInfiniteScroll();
    setupImageLightbox();
    setupActiveNavLink();
    setupExternalLinks();
    setupReadingProgress();
    setupTableOfContents();
    setupCarousel();
  }

  // ─── Theme (Dark/Light) Toggle ────────────────────────────────────────────
  function setupThemeToggle() {
    const btn     = document.querySelector( '[data-nx-theme-toggle]' );
    const html    = document.documentElement;
    const STORAGE = 'nx-theme';
    const moonIco = document.querySelector( '.nx-icon-moon' );
    const sunIco  = document.querySelector( '.nx-icon-sun' );

    const saved = localStorage.getItem( STORAGE );
    const prefersDark = window.matchMedia( '(prefers-color-scheme: dark)' ).matches;
    const currentTheme = saved || ( prefersDark ? 'dark' : 'light' );

    applyTheme( currentTheme );

    if ( btn ) {
      btn.addEventListener( 'click', () => {
        const next = html.dataset.theme === 'dark' ? 'light' : 'dark';
        applyTheme( next );
        localStorage.setItem( STORAGE, next );
      } );
    }

    function applyTheme( theme ) {
      html.dataset.theme = theme;
      if ( moonIco && sunIco ) {
        moonIco.style.display = theme === 'dark'  ? 'block' : 'none';
        sunIco.style.display  = theme === 'light' ? 'block' : 'none';
      }
    }
  }

  // ─── Mobile Menu ──────────────────────────────────────────────────────────
  function setupMobileMenu() {
    const toggle = document.querySelector( '[data-nx-menu-toggle]' );
    const nav    = document.getElementById( 'site-navigation' );
    if ( ! toggle || ! nav ) return;

    toggle.addEventListener( 'click', () => {
      const isOpen = nav.classList.toggle( 'is-open' );
      toggle.setAttribute( 'aria-expanded', isOpen );
      toggle.classList.toggle( 'is-active', isOpen );
      document.body.style.overflow = isOpen ? 'hidden' : '';
    } );

    // Close on Escape
    document.addEventListener( 'keydown', ( e ) => {
      if ( e.key === 'Escape' && nav.classList.contains( 'is-open' ) ) {
        nav.classList.remove( 'is-open' );
        toggle.setAttribute( 'aria-expanded', 'false' );
        toggle.classList.remove( 'is-active' );
        document.body.style.overflow = '';
        toggle.focus();
      }
    } );

    // Close on outside click
    document.addEventListener( 'click', ( e ) => {
      if ( nav.classList.contains( 'is-open' ) && ! nav.contains( e.target ) && ! toggle.contains( e.target ) ) {
        nav.classList.remove( 'is-open' );
        toggle.setAttribute( 'aria-expanded', 'false' );
        toggle.classList.remove( 'is-active' );
        document.body.style.overflow = '';
      }
    } );
  }

  // ─── Search Overlay ───────────────────────────────────────────────────────
  function setupSearchOverlay() {
    const openBtn  = document.querySelector( '[data-nx-search-toggle]' );
    const overlay  = document.querySelector( '[data-nx-search-overlay]' );
    const closeBtn = document.querySelector( '[data-nx-search-close]' );
    if ( ! overlay ) return;

    const input = overlay.querySelector( 'input[type="search"]' );

    function open() {
      overlay.classList.add( 'is-active' );
      document.body.style.overflow = 'hidden';
      openBtn && openBtn.setAttribute( 'aria-expanded', 'true' );
      setTimeout( () => input && input.focus(), 100 );
    }
    function close() {
      overlay.classList.remove( 'is-active' );
      document.body.style.overflow = '';
      openBtn && openBtn.setAttribute( 'aria-expanded', 'false' );
      openBtn && openBtn.focus();
    }

    openBtn  && openBtn.addEventListener(  'click', open  );
    closeBtn && closeBtn.addEventListener( 'click', close );

    overlay.addEventListener( 'click', ( e ) => {
      if ( e.target === overlay ) close();
    } );

    document.addEventListener( 'keydown', ( e ) => {
      if ( e.key === 'Escape' && overlay.classList.contains( 'is-active' ) ) close();
    } );

    // Live search
    if ( input && DATA.ajaxUrl ) {
      let timer;
      const results = document.getElementById( 'nx-search-results' );
      input.addEventListener( 'input', () => {
        clearTimeout( timer );
        const val = input.value.trim();
        if ( val.length < 2 ) { if ( results ) results.innerHTML = ''; return; }
        timer = setTimeout( () => runSearch( val, results ), 300 );
      } );
    }
  }

  function runSearch( term, container ) {
    if ( ! container ) return;
    const form = new FormData();
    form.append( 'action', 'terra_blue_search' );
    form.append( 'term',   term );
    form.append( 'nonce',  DATA.nonce );

    container.innerHTML = '<p class="nx-search-loading" style="padding:1rem;color:var(--nx-text-muted)">' + ( DATA.i18n.loading || 'Searching…' ) + '</p>';

    fetch( DATA.ajaxUrl, { method: 'POST', body: form } )
      .then( r => r.json() )
      .then( ( { data } ) => {
        if ( ! data || ! data.length ) {
          container.innerHTML = '<p style="padding:1rem;color:var(--nx-text-muted)">No results found.</p>';
          return;
        }
        container.innerHTML = data.map( p =>
          `<a href="${ p.url }" class="nx-search-result-item" style="display:flex;gap:.75rem;align-items:center;padding:.75rem;border-radius:8px;text-decoration:none;color:var(--nx-text);transition:.15s">
            ${ p.thumbnail ? `<img src="${ p.thumbnail }" alt="" style="width:48px;height:48px;object-fit:cover;border-radius:6px;flex-shrink:0">` : '' }
            <div>
              <div style="font-weight:600;font-size:.9rem">${ p.title }</div>
              <div style="font-size:.8rem;color:var(--nx-text-muted)">${ p.excerpt }</div>
            </div>
          </a>`
        ).join( '' );
      } )
      .catch( () => { container.innerHTML = ''; } );
  }

  // ─── Sticky Header ────────────────────────────────────────────────────────
  function setupStickyHeader() {
    const header = document.getElementById( 'masthead' );
    if ( ! header ) return;

    let lastY = 0;
    let ticking = false;

    function onScroll() {
      const y = window.scrollY;
      if ( ! ticking ) {
        requestAnimationFrame( () => {
          header.classList.toggle( 'nx-scrolled', y > 60 );
          header.classList.toggle( 'nx-hidden', y > lastY + 5 && y > 200 );
          header.classList.toggle( 'nx-visible', y < lastY );
          lastY = y;
          ticking = false;
        } );
        ticking = true;
      }
    }

    window.addEventListener( 'scroll', onScroll, { passive: true } );
  }

  // ─── Scroll Reveal ────────────────────────────────────────────────────────
  function setupScrollReveal() {
    if ( REDUCED || ! DATA.animations ) return;
    const els = document.querySelectorAll( '.nx-reveal' );
    if ( ! els.length ) return;

    const io = new IntersectionObserver( ( entries ) => {
      entries.forEach( ( entry ) => {
        if ( entry.isIntersecting ) {
          entry.target.classList.add( 'is-visible' );
          io.unobserve( entry.target );
        }
      } );
    }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' } );

    els.forEach( el => io.observe( el ) );
  }

  // ─── Back to Top ─────────────────────────────────────────────────────────
  function setupBackToTop() {
    const btn = document.querySelector( '[data-nx-back-to-top]' );
    if ( ! btn ) return;

    window.addEventListener( 'scroll', () => {
      btn.classList.toggle( 'is-visible', window.scrollY > 500 );
    }, { passive: true } );

    btn.addEventListener( 'click', () => {
      window.scrollTo( { top: 0, behavior: REDUCED ? 'auto' : 'smooth' } );
    } );
  }

  // ─── Code Block Copy ──────────────────────────────────────────────────────
  function setupCodeCopy() {
    document.querySelectorAll( 'pre' ).forEach( pre => {
      if ( pre.querySelector( '.nx-copy-btn' ) ) return;

      const btn = document.createElement( 'button' );
      btn.className  = 'nx-copy-btn nx-btn nx-btn-sm nx-btn-secondary';
      btn.textContent = 'Copy';
      btn.setAttribute( 'aria-label', 'Copy code' );
      btn.style.cssText = 'position:absolute;top:.75rem;right:.75rem;opacity:0;transition:.15s';

      pre.style.position = 'relative';
      pre.appendChild( btn );

      pre.addEventListener( 'mouseenter', () => ( btn.style.opacity = '1' ) );
      pre.addEventListener( 'mouseleave', () => ( btn.style.opacity = '0' ) );

      btn.addEventListener( 'click', () => {
        const code = pre.querySelector( 'code' );
        navigator.clipboard.writeText( code ? code.textContent : pre.textContent ).then( () => {
          btn.textContent = DATA.i18n.copied || 'Copied!';
          btn.style.opacity = '1';
          setTimeout( () => {
            btn.textContent = 'Copy';
            btn.style.opacity = '0';
          }, 2000 );
        } );
      } );
    } );
  }

  // ─── Live Search (Standalone) ─────────────────────────────────────────────
  function setupLiveSearch() { /* Handled in setupSearchOverlay */ }

  // ─── Smooth Scroll ────────────────────────────────────────────────────────
  function setupSmoothScroll() {
    if ( REDUCED || ! DATA.smoothScroll ) return;

    document.querySelectorAll( 'a[href^="#"]' ).forEach( a => {
      a.addEventListener( 'click', ( e ) => {
        const id = a.getAttribute( 'href' ).slice( 1 );
        if ( ! id ) return;
        const target = document.getElementById( id );
        if ( target ) {
          e.preventDefault();
          const headerH = document.getElementById( 'masthead' )?.offsetHeight || 0;
          const top = target.getBoundingClientRect().top + window.scrollY - headerH - 24;
          window.scrollTo( { top, behavior: 'smooth' } );
          target.setAttribute( 'tabindex', '-1' );
          target.focus( { preventScroll: true } );
        }
      } );
    } );
  }

  // ─── Cookie Notice ────────────────────────────────────────────────────────
  function setupCookieNotice() {
    const notice = document.getElementById( 'nx-cookie-notice' );
    const btn    = document.getElementById( 'nx-cookie-accept' );
    if ( ! notice || ! btn ) return;

    btn.addEventListener( 'click', () => {
      document.cookie = 'nx_cookie_ok=1;path=/;max-age=' + ( 60 * 60 * 24 * 365 );
      notice.style.transition = 'opacity .3s,transform .3s';
      notice.style.opacity    = '0';
      notice.style.transform  = 'translateY(100%)';
      setTimeout( () => notice.remove(), 400 );
    } );
  }

  // ─── Infinite Scroll ──────────────────────────────────────────────────────
  function setupInfiniteScroll() {
    if ( ! DATA.infiniteScroll ) return;

    const grid    = document.getElementById( 'nx-posts-grid' );
    const nextBtn = document.querySelector( '.nx-pagination .next' );
    if ( ! grid || ! nextBtn ) return;

    let loading  = false;
    let nextUrl  = nextBtn.href;

    const sentinel = document.createElement( 'div' );
    sentinel.style.height = '1px';
    grid.after( sentinel );

    const io = new IntersectionObserver( ( [ entry ] ) => {
      if ( entry.isIntersecting && ! loading && nextUrl ) {
        loading = true;
        fetchPosts();
      }
    }, { rootMargin: '200px' } );

    io.observe( sentinel );

    function fetchPosts() {
      const loader = document.createElement( 'div' );
      loader.className = 'nx-posts-loader';
      loader.innerHTML = '<div class="nx-skeleton" style="height:320px;border-radius:12px"></div>'.repeat( 3 );
      loader.style.cssText = 'grid-column:1/-1;display:contents';
      grid.appendChild( loader );

      fetch( nextUrl )
        .then( r => r.text() )
        .then( html => {
          const doc  = new DOMParser().parseFromString( html, 'text/html' );
          const posts = doc.querySelectorAll( '#nx-posts-grid > *' );
          const next  = doc.querySelector( '.nx-pagination .next' );

          loader.remove();
          posts.forEach( p => grid.appendChild( p ) );

          nextUrl = next ? next.href : null;
          loading = false;

          if ( ! nextUrl ) io.disconnect();
        } )
        .catch( () => { loader.remove(); loading = false; } );
    }
  }

  // ─── Lightbox ─────────────────────────────────────────────────────────────
  function setupImageLightbox() {
    const images = document.querySelectorAll( '.nx-post-content img, .nx-lightbox-trigger' );
    if ( ! images.length ) return;

    let lightbox = null;

    images.forEach( img => {
      img.style.cursor = 'zoom-in';
      img.addEventListener( 'click', () => openLightbox( img.src, img.alt ) );
    } );

    function openLightbox( src, alt ) {
      if ( lightbox ) lightbox.remove();
      lightbox = document.createElement( 'div' );
      lightbox.innerHTML = `
        <div style="position:fixed;inset:0;background:rgba(0,0,0,.95);z-index:9999;display:flex;align-items:center;justify-content:center;padding:2rem;cursor:zoom-out" role="dialog" aria-modal="true">
          <button style="position:absolute;top:1.5rem;right:1.5rem;background:none;border:none;color:white;font-size:2rem;cursor:pointer;line-height:1" aria-label="Close">&times;</button>
          <img src="${ src }" alt="${ alt || '' }" style="max-width:100%;max-height:90vh;object-fit:contain;border-radius:8px">
        </div>`;
      document.body.appendChild( lightbox );
      lightbox.querySelector( '[role="dialog"]' ).addEventListener( 'click', () => { lightbox.remove(); lightbox = null; } );
      lightbox.querySelector( 'button' ).addEventListener( 'click', () => { lightbox.remove(); lightbox = null; } );
    }

    document.addEventListener( 'keydown', e => {
      if ( e.key === 'Escape' && lightbox ) { lightbox.remove(); lightbox = null; }
    } );
  }

  // ─── Active Nav Link ──────────────────────────────────────────────────────
  function setupActiveNavLink() {
    const currentPath = window.location.pathname;
    document.querySelectorAll( '.nx-nav-menu a' ).forEach( a => {
      try {
        const url = new URL( a.href );
        if ( url.pathname === currentPath ) a.classList.add( 'is-active' );
      } catch {}
    } );
  }

  // ─── External Links ───────────────────────────────────────────────────────
  function setupExternalLinks() {
    const host = window.location.hostname;
    document.querySelectorAll( '.nx-post-content a[href]' ).forEach( a => {
      try {
        const url = new URL( a.href );
        if ( url.hostname && url.hostname !== host ) {
          a.setAttribute( 'target', '_blank' );
          a.setAttribute( 'rel', 'noopener noreferrer' );
          if ( ! a.querySelector( '.screen-reader-text' ) ) {
            const label = document.createElement( 'span' );
            label.className = 'screen-reader-text';
            label.textContent = ' (opens in new tab)';
            a.appendChild( label );
          }
        }
      } catch {}
    } );
  }

  // ─── Reading Progress Bar ─────────────────────────────────────────────────
  function setupReadingProgress() {
    if ( ! document.body.classList.contains( 'nx-single-post' ) ) return;

    const bar = document.createElement( 'div' );
    bar.id = 'nx-reading-progress';
    bar.style.cssText = 'position:fixed;top:0;left:0;width:0%;height:3px;background:var(--nx-accent);z-index:9999;transition:width .1s;pointer-events:none';
    document.body.prepend( bar );

    const article = document.querySelector( '.nx-post-content' );
    if ( ! article ) return;

    window.addEventListener( 'scroll', () => {
      const rect = article.getBoundingClientRect();
      const total = article.offsetHeight + rect.top + window.scrollY;
      const progress = Math.min( 100, Math.max( 0, ( window.scrollY / ( total - window.innerHeight ) ) * 100 ) );
      bar.style.width = progress + '%';
    }, { passive: true } );
  }

  // ─── Table of Contents (Auto-generate) ───────────────────────────────────
  function setupTableOfContents() {
    const tocContainer = document.getElementById( 'nx-toc' );
    const content = document.querySelector( '.nx-post-content' );
    if ( ! tocContainer || ! content ) return;

    const headings = content.querySelectorAll( 'h2, h3' );
    if ( headings.length < 2 ) { tocContainer.remove(); return; }

    const list = document.createElement( 'ol' );
    list.style.cssText = 'margin:0;padding:0 0 0 1.25rem;list-style:decimal';

    headings.forEach( ( h, i ) => {
      if ( ! h.id ) h.id = 'nx-heading-' + i;
      const li = document.createElement( 'li' );
      li.style.cssText = `margin-bottom:.5rem;font-size:.875rem;${ h.tagName === 'H3' ? 'margin-left:1rem;list-style:circle' : '' }`;
      li.innerHTML = `<a href="#${ h.id }" style="color:var(--nx-text-muted);text-decoration:none">${ h.textContent }</a>`;
      list.appendChild( li );
    } );

    tocContainer.appendChild( list );

    // Highlight active heading
    const io2 = new IntersectionObserver( ( entries ) => {
      entries.forEach( entry => {
        const link = tocContainer.querySelector( `a[href="#${ entry.target.id }"]` );
        if ( link ) link.style.color = entry.isIntersecting ? 'var(--nx-accent)' : 'var(--nx-text-muted)';
      } );
    }, { rootMargin: '-20% 0px -75% 0px' } );

    headings.forEach( h => io2.observe( h ) );
  }

  // ─── BlogCarousel v1 — Floating 3D Carousel ─────────────────────────
  function setupCarousel() {
    var carousel = document.querySelector( '[data-bc-carousel]' );
    if ( ! carousel ) return;

    var stage   = document.getElementById( 'bcStage' );
    var wrapper = document.getElementById( 'bcWrapper' );
    if ( ! stage ) return;

    var cards   = Array.from( stage.querySelectorAll( '.bc-card' ) );
    var total   = cards.length;
    var prevBtn = carousel.querySelector( '[data-bc-prev]' );
    var nextBtn = carousel.querySelector( '[data-bc-next]' );
    var dotsC   = carousel.querySelector( '[data-bc-dots]' );
    var dots    = dotsC ? Array.from( dotsC.querySelectorAll( '.bc-dot' ) ) : [];

    if ( total < 1 ) return;

    var currentIndex = 0;
    var isAnimating  = false;

    function positionCards() {
      cards.forEach( function( card, i ) {
        var offset = i - currentIndex;

        // Wrap around
        if ( offset > Math.floor( total / 2 ) ) offset -= total;
        if ( offset < -Math.floor( total / 2 ) ) offset += total;

        var absOffset  = Math.abs( offset );
        var translateX = offset * 200;
        var translateZ = -absOffset * 180;
        var rotateY    = -offset * 25;
        var scale      = Math.max( 1 - absOffset * 0.12, 0.65 );
        var opacity    = absOffset === 0 ? 1 : absOffset > 2 ? 0 : 0.85;

        card.style.transform = 'translateX(' + translateX + 'px) translateZ(' + translateZ + 'px) rotateY(' + rotateY + 'deg) scale(' + scale + ')';
        card.style.opacity   = opacity;
        card.style.zIndex    = total - absOffset;
        card.style.pointerEvents = absOffset <= 2 ? 'auto' : 'none';

        card.classList.toggle( 'active', offset === 0 );
      } );

      // Update dots
      dots.forEach( function( dot, i ) {
        var isActive = i === currentIndex;
        dot.classList.toggle( 'active', isActive );
        dot.setAttribute( 'aria-selected', isActive ? 'true' : 'false' );
      } );
    }

    function goTo( index ) {
      if ( isAnimating ) return;
      isAnimating = true;
      currentIndex = ( ( index % total ) + total ) % total;
      positionCards();
      setTimeout( function() { isAnimating = false; }, 800 );
    }

    function next() { goTo( currentIndex + 1 ); }
    function prev() { goTo( currentIndex - 1 ); }

    // Arrow clicks
    if ( prevBtn ) prevBtn.addEventListener( 'click', prev );
    if ( nextBtn ) nextBtn.addEventListener( 'click', next );

    // Dot clicks
    if ( dotsC ) {
      dotsC.addEventListener( 'click', function( e ) {
        var dot = e.target.closest( '.bc-dot' );
        if ( dot && dot.dataset.dot !== undefined ) {
          goTo( parseInt( dot.dataset.dot, 10 ) );
        }
      } );
    }

    // Card clicks — navigate to that card if not active
    cards.forEach( function( card ) {
      card.addEventListener( 'click', function() {
        var idx = parseInt( card.dataset.index, 10 );
        if ( idx !== currentIndex ) goTo( idx );
      } );
    } );

    // Keyboard
    carousel.setAttribute( 'tabindex', '0' );
    carousel.addEventListener( 'keydown', function( e ) {
      if ( e.key === 'ArrowLeft' )  { prev(); e.preventDefault(); }
      if ( e.key === 'ArrowRight' ) { next(); e.preventDefault(); }
    } );

    // Touch / swipe
    var touchStartX = 0;
    if ( wrapper ) {
      wrapper.addEventListener( 'touchstart', function( e ) {
        touchStartX = e.touches[0].clientX;
      }, { passive: true } );
      wrapper.addEventListener( 'touchend', function( e ) {
        var diff = touchStartX - e.changedTouches[0].clientX;
        if ( Math.abs( diff ) > 50 ) diff > 0 ? next() : prev();
      } );
    }

    // Auto-advance (pauses on hover/focus)
    var isPaused = false;
    carousel.addEventListener( 'mouseenter', function() { isPaused = true; } );
    carousel.addEventListener( 'mouseleave', function() { isPaused = false; } );
    carousel.addEventListener( 'focusin',    function() { isPaused = true; } );
    carousel.addEventListener( 'focusout',   function() { isPaused = false; } );

    if ( ! REDUCED ) {
      setInterval( function() {
        if ( ! isPaused ) next();
      }, 5000 );
    }

    // Init
    positionCards();
  }

  // ─── Expose public API ────────────────────────────────────────────────────
  window.TT6ixTheme = {
    runSearch,
    init,
    version: '1.0.0',
  };

} )();
