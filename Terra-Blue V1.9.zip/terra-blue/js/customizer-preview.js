/**
 * Terra-Blue — Customizer Live Preview
 *
 * Handles postMessage transport bindings so Customizer changes are
 * reflected in the preview iframe instantly without a full page reload.
 *
 * @package Terra-Blue
 * @version 1.0.0
 */
( function( $, api ) {
	'use strict';

	/* ─── Helpers ─────────────────────────────────────────────────────────── */

	/**
	 * Set or update an inline <style> tag in the preview iframe <head>.
	 *
	 * @param {string} id  Unique style tag ID (no #).
	 * @param {string} css CSS string to inject.
	 */
	function injectCSS( id, css ) {
		var tag = document.getElementById( id );
		if ( ! tag ) {
			tag = document.createElement( 'style' );
			tag.id = id;
			document.head.appendChild( tag );
		}
		tag.textContent = css;
	}

	/**
	 * Bind a Customizer setting to a CSS custom property on :root.
	 *
	 * @param {string} settingId   Customizer setting ID.
	 * @param {string} cssVar      CSS custom property name, e.g. '--nx-accent'.
	 */
	function bindCSSVar( settingId, cssVar ) {
		api( settingId, function( setting ) {
			setting.bind( function( value ) {
				injectCSS(
					'nx-preview-' + settingId.replace( /[^a-z0-9]/gi, '-' ),
					':root { ' + cssVar + ': ' + value + '; }'
				);
			} );
		} );
	}

	/**
	 * Bind a Customizer setting to update the text content of matched elements.
	 *
	 * @param {string} settingId  Customizer setting ID.
	 * @param {string} selector   CSS selector string.
	 */
	function bindText( settingId, selector ) {
		api( settingId, function( setting ) {
			setting.bind( function( value ) {
				$( selector ).text( value );
			} );
		} );
	}

	/**
	 * Bind a Customizer setting to update the href of matched links.
	 *
	 * @param {string} settingId  Customizer setting ID.
	 * @param {string} selector   CSS selector string.
	 */
	function bindHref( settingId, selector ) {
		api( settingId, function( setting ) {
			setting.bind( function( value ) {
				$( selector ).attr( 'href', value );
			} );
		} );
	}

	/* ─── Colors ──────────────────────────────────────────────────────────── */

	bindCSSVar( 'terra_blue_accent_color',   '--nx-accent' );
	bindCSSVar( 'terra_blue_accent_2_color', '--nx-accent-2' );
	bindCSSVar( 'terra_blue_accent_3_color', '--nx-accent-3' );

	api( 'terra_blue_theme_color', function( setting ) {
		setting.bind( function( value ) {
			$( 'meta[name="theme-color"]' ).attr( 'content', value );
		} );
	} );

	/* ─── Typography ──────────────────────────────────────────────────────── */

	api( 'terra_blue_font_display', function( setting ) {
		setting.bind( function( value ) {
			if ( value ) {
				injectCSS(
					'nx-preview-font-display',
					':root { --nx-font-display: \'' + value + '\', system-ui, sans-serif; }'
				);
			}
		} );
	} );

	api( 'terra_blue_font_body', function( setting ) {
		setting.bind( function( value ) {
			if ( value ) {
				injectCSS(
					'nx-preview-font-body',
					':root { --nx-font-body: \'' + value + '\', system-ui, sans-serif; }'
				);
			}
		} );
	} );

	/* ─── Header ──────────────────────────────────────────────────────────── */

	/* Logo size (live preview) */
	api( 'terra_blue_logo_height', function( setting ) {
		setting.bind( function( value ) {
			injectCSS(
				'nx-preview-logo-height',
				':root { --nx-logo-height: ' + parseInt( value, 10 ) + 'px; }'
			);
		} );
	} );

	api( 'terra_blue_logo_max_width', function( setting ) {
		setting.bind( function( value ) {
			injectCSS(
				'nx-preview-logo-width',
				':root { --nx-logo-max-width: ' + parseInt( value, 10 ) + 'px; }'
			);
		} );
	} );

	bindText( 'terra_blue_header_cta_text', '.nx-header-actions .nx-btn-primary:last-child' );
	bindHref( 'terra_blue_header_cta_url',  '.nx-header-actions .nx-btn-primary:last-child' );

	api( 'terra_blue_sticky_header', function( setting ) {
		setting.bind( function( value ) {
			$( 'body' ).toggleClass( 'nx-sticky-header', !! value );
		} );
	} );

	api( 'terra_blue_header_style', function( setting ) {
		setting.bind( function( value ) {
			var header = $( '#masthead' );
			header.removeClass( 'nx-header--default nx-header--centered nx-header--minimal' );
			header.addClass( 'nx-header--' + value );
		} );
	} );

	api( 'terra_blue_header_search', function( setting ) {
		setting.bind( function( value ) {
			$( '.nx-search-toggle' ).toggle( !! value );
		} );
	} );

	/* ─── Hero / Homepage ─────────────────────────────────────────────────── */

	bindText( 'terra_blue_hero_badge',       '.nx-hero .nx-badge, .nx-hero__badge' );
	bindText( 'terra_blue_hero_title',        '.nx-hero__title, .nx-hero h1' );
	bindText( 'terra_blue_hero_subtitle',     '.nx-hero__subtitle, .nx-hero h2' );
	bindText( 'terra_blue_hero_description',  '.nx-hero__description, .nx-hero p:first-of-type' );
	bindText( 'terra_blue_hero_cta_1_text',   '.nx-hero .nx-btn-primary, .nx-hero__cta-1' );
	bindHref( 'terra_blue_hero_cta_1_url',    '.nx-hero .nx-btn-primary, .nx-hero__cta-1' );
	bindText( 'terra_blue_hero_cta_2_text',   '.nx-hero .nx-btn-ghost, .nx-hero .nx-btn-secondary, .nx-hero__cta-2' );
	bindHref( 'terra_blue_hero_cta_2_url',    '.nx-hero .nx-btn-ghost, .nx-hero .nx-btn-secondary, .nx-hero__cta-2' );

	// Stats
	bindText( 'terra_blue_stat_1_number', '.nx-hero-stat:nth-child(1) .nx-hero-stat__number' );
	bindText( 'terra_blue_stat_1_label',  '.nx-hero-stat:nth-child(1) .nx-hero-stat__label' );
	bindText( 'terra_blue_stat_2_number', '.nx-hero-stat:nth-child(2) .nx-hero-stat__number' );
	bindText( 'terra_blue_stat_2_label',  '.nx-hero-stat:nth-child(2) .nx-hero-stat__label' );
	bindText( 'terra_blue_stat_3_number', '.nx-hero-stat:nth-child(3) .nx-hero-stat__number' );
	bindText( 'terra_blue_stat_3_label',  '.nx-hero-stat:nth-child(3) .nx-hero-stat__label' );

	// Carousel text (live)
	bindText( 'terra_blue_carousel_title',    '.bc-header__title' );
	bindText( 'terra_blue_carousel_subtitle', '.bc-header__subtitle' );

	// Hero text alignment (live)
	api( 'terra_blue_hero_align', function( setting ) {
		setting.bind( function( value ) {
			var alignItems = value === 'left' ? 'flex-start' : value === 'right' ? 'flex-end' : 'center';
			injectCSS( 'nx-preview-hero-align',
				'.nx-hero,.nx-hero__content{text-align:' + value + ';}' +
				'.nx-hero__content{align-items:' + alignItems + ';}'
			);
		} );
	} );

	// Carousel text alignment (live)
	api( 'terra_blue_carousel_align', function( setting ) {
		setting.bind( function( value ) {
			var ml = value === 'right' ? 'auto' : '0';
			var mr = value === 'left' ? 'auto' : '0';
			if ( value === 'center' ) { ml = 'auto'; mr = 'auto'; }
			injectCSS( 'nx-preview-carousel-align',
				'.bc-header{text-align:' + value + ';}' +
				'.bc-header__subtitle{margin-left:' + ml + ';margin-right:' + mr + ';}'
			);
		} );
	} );

	/* ─── Blog Alignment (live) ──────────────────────────────────────────── */

	api( 'terra_blue_blog_align', function( setting ) {
		setting.bind( function( value ) {
			injectCSS( 'nx-preview-blog-align',
				'.nx-post-card,.nx-post-card__content,.bc-card__content{text-align:' + value + ';}'
			);
		} );
	} );

	/* ─── Single Post Alignment (live) ───────────────────────────────────── */

	api( 'terra_blue_single_align', function( setting ) {
		setting.bind( function( value ) {
			injectCSS( 'nx-preview-single-align',
				'.nx-single-post__body,.nx-post-content,.nx-single-post__header{text-align:' + value + ';}'
			);
		} );
	} );

	/* ─── Footer ──────────────────────────────────────────────────────────── */

	api( 'terra_blue_footer_col_1_title', function( setting ) {
		setting.bind( function( value ) {
			$( '.nx-footer-col:nth-child(1) h4' ).text( value );
		} );
	} );
	api( 'terra_blue_footer_col_2_title', function( setting ) {
		setting.bind( function( value ) {
			$( '.nx-footer-col:nth-child(2) h4' ).text( value );
		} );
	} );
	api( 'terra_blue_footer_col_3_title', function( setting ) {
		setting.bind( function( value ) {
			$( '.nx-footer-col:nth-child(3) h4' ).text( value );
		} );
	} );

	// Footer columns visibility (live)
	api( 'terra_blue_footer_show_columns', function( setting ) {
		setting.bind( function( value ) {
			$( '.nx-footer-col' ).toggle( !! value );
			$( '.nx-footer-grid' ).toggleClass( 'nx-footer-grid--brand-only', ! value );
		} );
	} );

	// Footer text alignment (live)
	api( 'terra_blue_footer_align', function( setting ) {
		setting.bind( function( value ) {
			var css = '.nx-footer-top,.nx-footer-brand,.nx-footer-col,.nx-footer-bottom{text-align:' + value + ';}';
			if ( value === 'center' ) {
				css += '.nx-footer-brand{align-items:center;}.nx-footer-brand p{max-width:none;}.nx-footer-social{justify-content:center;}.nx-footer-bottom{justify-content:center;}';
			} else if ( value === 'right' ) {
				css += '.nx-footer-brand{align-items:flex-end;}.nx-footer-social{justify-content:flex-end;}.nx-footer-bottom{justify-content:flex-end;}';
			} else {
				css += '.nx-footer-brand{align-items:flex-start;}.nx-footer-brand p{max-width:28ch;}.nx-footer-social{justify-content:flex-start;}.nx-footer-bottom{justify-content:flex-start;}';
			}
			injectCSS( 'nx-preview-footer-align', css );
		} );
	} );

	// Footer dark toggle (live)
	api( 'terra_blue_footer_dark', function( setting ) {
		setting.bind( function( value ) {
			$( '#colophon' ).toggleClass( 'nx-footer--dark', !! value );
		} );
	} );

	/* ─── Cookie Notice ───────────────────────────────────────────────────── */

	api( 'terra_blue_cookie_text', function( setting ) {
		setting.bind( function( value ) {
			$( '#nx-cookie-notice p' ).html( value );
		} );
	} );

	api( 'terra_blue_cookie_notice', function( setting ) {
		setting.bind( function( value ) {
			$( '#nx-cookie-notice' ).toggle( !! value );
		} );
	} );

	/* ─── Footer Quick Links (live) ──────────────────────────────────────── */

	api( 'terra_blue_footer_quicklinks_show', function( setting ) {
		setting.bind( function( value ) {
			$( '#nx-footer-quicklinks' ).toggle( !! value );
		} );
	} );

	// Bind each quick link text + URL (1–9)
	for ( var ql = 1; ql <= 9; ql++ ) {
		( function( n ) {
			api( 'terra_blue_qlink_' + n + '_text', function( setting ) {
				setting.bind( function( value ) {
					var link = $( '.nx-quicklink[data-qlink="' + n + '"]' );
					if ( value ) {
						if ( link.length ) {
							link.text( value ).show();
						} else {
							var url = wp.customize( 'terra_blue_qlink_' + n + '_url' ) ? wp.customize( 'terra_blue_qlink_' + n + '_url' ).get() : '#';
							$( '.nx-quicklinks-row' ).append( '<a href="' + url + '" class="nx-quicklink" data-qlink="' + n + '">' + value + '</a>' );
						}
					} else {
						link.hide();
					}
				} );
			} );
			api( 'terra_blue_qlink_' + n + '_url', function( setting ) {
				setting.bind( function( value ) {
					$( '.nx-quicklink[data-qlink="' + n + '"]' ).attr( 'href', value );
				} );
			} );
		} )( ql );
	}

	/* ─── Social URLs (footer icons) ──────────────────────────────────────── */

	var socialMap = {
		'terra_blue_twitter_url':   '.nx-footer-social a[aria-label="Twitter/X"]',
		'terra_blue_github_url':    '.nx-footer-social a[aria-label="GitHub"]',
		'terra_blue_linkedin_url':  '.nx-footer-social a[aria-label="LinkedIn"]',
		'terra_blue_instagram_url': '.nx-footer-social a[aria-label="Instagram"]',
		'terra_blue_youtube_url':   '.nx-footer-social a[aria-label="YouTube"]',
	};

	Object.keys( socialMap ).forEach( function( settingId ) {
		bindHref( settingId, socialMap[ settingId ] );
	} );

} )( jQuery, wp.customize );
