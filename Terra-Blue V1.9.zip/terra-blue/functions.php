<?php
/**
 * Terra-Blue — Functions & Features
 *
 * @package Terra-Blue
 * @version 1.2.0
 */

defined( 'ABSPATH' ) || exit;

// ─── PHP Version Guard ────────────────────────────────────────────────────────
// Require PHP 7.4+ (matches style.css "Requires PHP" header).
// Shows a friendly admin notice instead of a fatal error on older hosts.
if ( version_compare( PHP_VERSION, '7.4', '<' ) ) {
    add_action( 'admin_notices', function () {
        echo '<div class="notice notice-error"><p>';
        printf(
            /* translators: 1: theme name 2: required PHP version 3: current PHP version */
            esc_html__( '%1$s requires PHP %2$s or higher. You are running PHP %3$s. Please upgrade PHP or contact your host.', 'terra-blue' ),
            '<strong>Terra-Blue</strong>',
            '7.4',
            PHP_VERSION
        );
        echo '</p></div>';
    } );
    return; // Abort loading theme functions entirely — prevents fatal errors.
}

// ─── Memory Management ───────────────────────────────────────────────────────
// Set a reasonable memory limit. 128 MB is sufficient for most theme operations.
// WordPress default is 40M; we raise to 128M only if not already configured.
if ( ! defined( 'WP_MEMORY_LIMIT' ) ) {
    define( 'WP_MEMORY_LIMIT', '128M' );
}

// ─── Constants ───────────────────────────────────────────────────────────────
define( 'TERRA_BLUE_VERSION',   '2.0.0' );
define( 'TERRA_BLUE_DIR',       get_template_directory() );
define( 'TERRA_BLUE_URI',       get_template_directory_uri() );
define( 'TERRA_BLUE_ASSETS',    TERRA_BLUE_URI . '/assets' );
define( 'TERRA_BLUE_INC',       TERRA_BLUE_DIR . '/inc' );
define( 'TERRA_BLUE_TEXT',      'terra-blue' );

// ─── Debug Mode ──────────────────────────────────────────────────────────────
// Theme-level debug flag. Follows WP_DEBUG when set, or can be enabled
// independently by adding:  define( 'TERRA_BLUE_DEBUG', true );  to wp-config.php
if ( ! defined( 'TERRA_BLUE_DEBUG' ) ) {
    define( 'TERRA_BLUE_DEBUG', defined( 'WP_DEBUG' ) && WP_DEBUG );
}

/**
 * Log a message to the PHP error log when debugging is enabled.
 *
 * @param mixed  $message  String or variable to log.
 * @param string $context  Optional label for the log entry.
 */
function terra_blue_debug_log( $message, $context = '' ) {
    if ( ! TERRA_BLUE_DEBUG ) {
        return;
    }
    $prefix = '[Terra-Blue]';
    if ( $context ) {
        $prefix .= '[' . $context . ']';
    }
    if ( is_array( $message ) || is_object( $message ) ) {
        error_log( $prefix . ' ' . print_r( $message, true ) );
    } else {
        error_log( $prefix . ' ' . $message );
    }
}

/**
 * Display theme debug info in the admin footer when TERRA_BLUE_DEBUG is on.
 */
function terra_blue_debug_admin_footer() {
    if ( ! TERRA_BLUE_DEBUG || ! current_user_can( 'manage_options' ) ) {
        return;
    }
    $info = array(
        'Theme'       => 'Terra-Blue ' . TERRA_BLUE_VERSION,
        'PHP'         => PHP_VERSION,
        'WordPress'   => get_bloginfo( 'version' ),
        'Memory used' => size_format( memory_get_peak_usage( true ) ),
        'Memory limit'=> ini_get( 'memory_limit' ),
        'Debug mode'  => 'ON',
    );
    echo '<div style="position:fixed;bottom:0;right:0;background:#0D1117;color:#00D9C0;font:11px/1.6 monospace;padding:8px 14px;border-radius:8px 0 0 0;z-index:99999;max-width:280px;opacity:0.92;">';
    foreach ( $info as $k => $v ) {
        echo esc_html( $k ) . ': <span style="color:#E6EDF3;">' . esc_html( $v ) . '</span><br>';
    }
    echo '</div>';
}
add_action( 'admin_footer', 'terra_blue_debug_admin_footer' );
add_action( 'wp_footer',    'terra_blue_debug_admin_footer' );

// ─── Load Includes ────────────────────────────────────────────────────────────
$terra_blue_includes = [
    'inc/customizer.php',
    'inc/block-styles.php',
    'inc/block-patterns.php',
    'inc/walker-nav.php',
    'inc/template-functions.php',
    'inc/template-tags.php',
    'inc/widget-areas.php',
    'inc/breadcrumbs.php',
    'inc/woocommerce.php',
    'inc/starter-content.php',
];

foreach ( $terra_blue_includes as $file ) {
    $path = TERRA_BLUE_DIR . '/' . $file;
    if ( file_exists( $path ) ) {
        require_once $path;
    }
}

// ─── Theme Setup ─────────────────────────────────────────────────────────────
if ( ! function_exists( 'terra_blue_setup' ) ) :
function terra_blue_setup() {

    // Translations
    load_theme_textdomain( TERRA_BLUE_TEXT, TERRA_BLUE_DIR . '/languages' );

    // Automatic feed links
    add_theme_support( 'automatic-feed-links' );

    // Title tag
    add_theme_support( 'title-tag' );

    // Post thumbnails — only register sizes the theme actually uses
    add_theme_support( 'post-thumbnails' );
    add_image_size( 'terra-blue-hero',  1200, 630, true );
    add_image_size( 'terra-blue-card',   800, 450, true );
    add_image_size( 'terra-blue-thumb',  400, 225, true );

    // HTML5 support
    add_theme_support( 'html5', [
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
        'navigation-widgets',
    ] );

    // Post formats
    add_theme_support( 'post-formats', [
        'aside',
        'gallery',
        'link',
        'image',
        'quote',
        'status',
        'video',
        'audio',
        'chat',
    ] );

    // Custom logo — with crop support
    add_theme_support( 'custom-logo', [
        'height'               => 80,
        'width'                => 300,
        'flex-width'           => true,
        'flex-height'          => true,
        'header-text'          => [ 'site-title', 'site-description' ],
        'unlink-homepage-logo' => true,
    ] );

    // Appearance tools — enables all block editor design controls
    add_theme_support( 'appearance-tools' );
    add_theme_support( 'custom-units', 'px', 'em', 'rem', 'vh', 'vw', '%' );
    add_theme_support( 'border' );

    // Custom header
    add_theme_support( 'custom-header', [
        'default-image'  => '',
        'width'          => 1920,
        'height'         => 800,
        'flex-width'     => true,
        'flex-height'    => true,
    ] );

    // Custom background
    add_theme_support( 'custom-background', [
        'default-color' => '080C10',
    ] );

    // Theme color (browser chrome)
    add_theme_support( 'custom-colors' );

    // Editor styles
    add_theme_support( 'editor-styles' );
    add_editor_style( 'css/editor-style.css' );

    // Wide alignment
    add_theme_support( 'align-wide' );

    // Responsive embeds
    add_theme_support( 'responsive-embeds' );

    // Block editor color palette
    add_theme_support( 'editor-color-palette', [
        [ 'name' => __( 'Accent Teal',   TERRA_BLUE_TEXT ), 'slug' => 'accent',   'color' => '#00D9C0' ],
        [ 'name' => __( 'Accent Purple', TERRA_BLUE_TEXT ), 'slug' => 'accent-2', 'color' => '#7C3AED' ],
        [ 'name' => __( 'Accent Amber',  TERRA_BLUE_TEXT ), 'slug' => 'accent-3', 'color' => '#F59E0B' ],
        [ 'name' => __( 'Base Dark',     TERRA_BLUE_TEXT ), 'slug' => 'base',     'color' => '#080C10' ],
        [ 'name' => __( 'Surface',       TERRA_BLUE_TEXT ), 'slug' => 'surface',  'color' => '#0D1117' ],
        [ 'name' => __( 'Surface 2',     TERRA_BLUE_TEXT ), 'slug' => 'surface-2','color' => '#161B22' ],
        [ 'name' => __( 'Text',          TERRA_BLUE_TEXT ), 'slug' => 'text',     'color' => '#E6EDF3' ],
        [ 'name' => __( 'Text Muted',    TERRA_BLUE_TEXT ), 'slug' => 'muted',    'color' => '#8B949E' ],
        [ 'name' => __( 'Success',       TERRA_BLUE_TEXT ), 'slug' => 'success',  'color' => '#10B981' ],
        [ 'name' => __( 'Danger',        TERRA_BLUE_TEXT ), 'slug' => 'danger',   'color' => '#EF4444' ],
        [ 'name' => __( 'Warning',       TERRA_BLUE_TEXT ), 'slug' => 'warning',  'color' => '#F59E0B' ],
    ] );

    // Block font sizes
    add_theme_support( 'editor-font-sizes', [
        [ 'name' => __( 'XS',      TERRA_BLUE_TEXT ), 'slug' => 'xs',     'size' => 12 ],
        [ 'name' => __( 'Small',   TERRA_BLUE_TEXT ), 'slug' => 'small',  'size' => 14 ],
        [ 'name' => __( 'Normal',  TERRA_BLUE_TEXT ), 'slug' => 'normal', 'size' => 16 ],
        [ 'name' => __( 'Medium',  TERRA_BLUE_TEXT ), 'slug' => 'medium', 'size' => 18 ],
        [ 'name' => __( 'Large',   TERRA_BLUE_TEXT ), 'slug' => 'large',  'size' => 24 ],
        [ 'name' => __( 'XL',      TERRA_BLUE_TEXT ), 'slug' => 'xl',     'size' => 32 ],
        [ 'name' => __( '2XL',     TERRA_BLUE_TEXT ), 'slug' => 'xxl',    'size' => 48 ],
        [ 'name' => __( '3XL',     TERRA_BLUE_TEXT ), 'slug' => 'xxxl',   'size' => 64 ],
        [ 'name' => __( 'Huge',    TERRA_BLUE_TEXT ), 'slug' => 'huge',   'size' => 96 ],
    ] );

    // Custom line heights
    add_theme_support( 'custom-line-height' );

    // Custom spacing
    add_theme_support( 'custom-spacing' );

    // Block editor gradient presets
    add_theme_support( 'editor-gradient-presets', [
        [ 'name' => __( 'Teal to Purple', TERRA_BLUE_TEXT ), 'slug' => 'teal-purple', 'gradient' => 'linear-gradient(135deg,#00D9C0,#7C3AED)' ],
        [ 'name' => __( 'Amber to Red',   TERRA_BLUE_TEXT ), 'slug' => 'amber-red',   'gradient' => 'linear-gradient(135deg,#F59E0B,#EF4444)' ],
        [ 'name' => __( 'Dark Mesh',      TERRA_BLUE_TEXT ), 'slug' => 'dark-mesh',   'gradient' => 'radial-gradient(at 40% 20%,#00D9C0 0,transparent 50%),radial-gradient(at 80% 0%,#7C3AED 0,transparent 50%),radial-gradient(at 0% 50%,#F59E0B 0,transparent 50%)' ],
    ] );

    // Disable custom colors / gradients to enforce palette (optional — commented out by default)
    // add_theme_support( 'disable-custom-colors' );

    // Menus
    register_nav_menus( [
        'primary'   => __( 'Primary Navigation',  TERRA_BLUE_TEXT ),
        'secondary' => __( 'Secondary Navigation', TERRA_BLUE_TEXT ),
        'footer'    => __( 'Footer Navigation',    TERRA_BLUE_TEXT ),
        'social'    => __( 'Social Links Menu',    TERRA_BLUE_TEXT ),
        'docs'      => __( 'Documentation Menu',   TERRA_BLUE_TEXT ),
    ] );

    // WooCommerce
    add_theme_support( 'woocommerce', [
        'thumbnail_image_width'       => 600,
        'single_image_width'          => 900,
        'product_grid'                => [
            'default_rows'    => 4,
            'min_rows'        => 1,
            'default_columns' => 3,
            'min_columns'     => 1,
            'max_columns'     => 6,
        ],
    ] );
    add_theme_support( 'wc-product-gallery-zoom' );
    add_theme_support( 'wc-product-gallery-lightbox' );
    add_theme_support( 'wc-product-gallery-slider' );
    add_theme_support( 'woocommerce-product-gallery-audio' );

    // AMP
    add_theme_support( 'amp' );

    // PWA / Service Worker
    add_theme_support( 'service_worker' );

    // Block template parts
    add_theme_support( 'block-template-parts' );

    // Dark mode
    add_theme_support( 'dark-editor-style' );

    // Starter content — populates the Customizer live preview with demo data.
    // Nothing is saved to the database until the user clicks "Publish".
    add_theme_support( 'starter-content', terra_blue_get_starter_content() );
}
endif;
add_action( 'after_setup_theme', 'terra_blue_setup' );

// ─── Content Width ────────────────────────────────────────────────────────────
function terra_blue_content_width() {
    $GLOBALS['content_width'] = apply_filters( 'terra_blue_content_width', 1152 );
}
add_action( 'after_setup_theme', 'terra_blue_content_width', 0 );

// ─── Enqueue Scripts & Styles ─────────────────────────────────────────────────
function terra_blue_scripts() {

    // ── Google Fonts — only 2 families, swap for fast first paint ──
    $fonts_url = 'https://fonts.googleapis.com/css2?family=Instrument+Sans:wght@400;500;600;700&family=Syne:wght@400;500;600;700&family=Outfit:wght@300;400;500;600;700&family=Space+Mono:wght@400;700&display=swap';
    wp_enqueue_style( 'terra-blue-fonts', $fonts_url, [], null, 'print' );
    // Load fonts as print, then swap to all — prevents render-blocking
    add_filter( 'style_loader_tag', function( $tag, $handle ) {
        if ( 'terra-blue-fonts' === $handle ) {
            return str_replace( "media='print'", "media='print' onload=\"this.media='all'\"", $tag );
        }
        return $tag;
    }, 10, 2 );

    // ── Theme Stylesheet ──
    wp_enqueue_style( 'terra-blue-style', get_stylesheet_uri(), [], TERRA_BLUE_VERSION );

    // ── Animations — only on frontend, not in admin/customizer ──
    if ( ! is_customize_preview() ) {
        wp_enqueue_style( 'terra-blue-animations', TERRA_BLUE_URI . '/css/animations.css', [ 'terra-blue-style' ], TERRA_BLUE_VERSION );
    }

    // ── WooCommerce — only when needed ──
    if ( function_exists( 'is_woocommerce' ) && ( is_woocommerce() || is_cart() || is_checkout() ) ) {
        wp_enqueue_style( 'terra-blue-woocommerce', TERRA_BLUE_URI . '/css/woocommerce.css', [ 'terra-blue-style' ], TERRA_BLUE_VERSION );
    }

    // ── Theme JS — deferred, in footer ──
    wp_enqueue_script(
        'terra-blue-theme',
        TERRA_BLUE_URI . '/js/theme.js',
        [],
        TERRA_BLUE_VERSION,
        [ 'strategy' => 'defer', 'in_footer' => true ]
    );

    // ── Minimal localized data ──
    wp_localize_script( 'terra-blue-theme', 'TT6ixData', [
        'themeUri' => TERRA_BLUE_URI,
        'siteUrl'  => home_url(),
        'i18n'     => [
            'loading' => __( 'Loading…', TERRA_BLUE_TEXT ),
            'copied'  => __( 'Copied!',  TERRA_BLUE_TEXT ),
        ],
    ] );

    // ── Comments ──
    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'terra_blue_scripts' );

// ─── Admin Enqueue ────────────────────────────────────────────────────────────
function terra_blue_admin_scripts( $hook ) {
    wp_enqueue_style( 'terra-blue-admin', TERRA_BLUE_URI . '/css/admin.css', [], TERRA_BLUE_VERSION );
    if ( in_array( $hook, [ 'post.php', 'post-new.php' ] ) ) {
        wp_enqueue_script( 'terra-blue-editor', TERRA_BLUE_URI . '/js/editor.js', [ 'wp-blocks', 'wp-dom-ready', 'wp-edit-post' ], TERRA_BLUE_VERSION, true );
    }
}
add_action( 'admin_enqueue_scripts', 'terra_blue_admin_scripts' );

// ─── Customizer Text Alignment — inline CSS ─────────────────────────────────
function terra_blue_alignment_css() {
    $hero_align     = get_theme_mod( 'terra_blue_hero_align',     'center' );
    $carousel_align = get_theme_mod( 'terra_blue_carousel_align', 'center' );
    $blog_align     = get_theme_mod( 'terra_blue_blog_align',     'left' );
    $single_align   = get_theme_mod( 'terra_blue_single_align',   'left' );
    $footer_align   = get_theme_mod( 'terra_blue_footer_align',   'left' );

    $css = '';

    if ( $hero_align !== 'center' ) {
        $css .= ".nx-hero,.nx-hero__content{text-align:{$hero_align};}";
        if ( $hero_align === 'left' ) {
            $css .= ".nx-hero__content{align-items:flex-start;}";
        } elseif ( $hero_align === 'right' ) {
            $css .= ".nx-hero__content{align-items:flex-end;}";
        }
    }

    // Carousel header alignment (independent of hero)
    $css .= ".bc-header{text-align:{$carousel_align};}";
    if ( $carousel_align === 'left' ) {
        $css .= ".bc-header__subtitle{margin-left:0;margin-right:auto;}";
    } elseif ( $carousel_align === 'right' ) {
        $css .= ".bc-header__subtitle{margin-left:auto;margin-right:0;}";
    } else {
        $css .= ".bc-header__subtitle{margin-left:auto;margin-right:auto;}";
    }

    if ( $blog_align !== 'left' ) {
        $css .= ".nx-post-card,.nx-post-card__content,.bc-card__content{text-align:{$blog_align};}";
    }

    if ( $single_align !== 'left' ) {
        $css .= ".nx-single-post__body,.nx-post-content,.nx-single-post__header{text-align:{$single_align};}";
    }

    if ( $footer_align !== 'left' ) {
        $css .= ".nx-footer-top,.nx-footer-brand,.nx-footer-col,.nx-footer-bottom{text-align:{$footer_align};}";
        if ( $footer_align === 'center' ) {
            $css .= ".nx-footer-brand{align-items:center;}.nx-footer-brand p{max-width:none;}.nx-footer-social{justify-content:center;}.nx-footer-bottom{justify-content:center;}";
        } elseif ( $footer_align === 'right' ) {
            $css .= ".nx-footer-brand{align-items:flex-end;}.nx-footer-social{justify-content:flex-end;}.nx-footer-bottom{justify-content:flex-end;}";
        }
    }

    if ( $css ) {
        echo '<style id="terra-blue-alignment">' . $css . '</style>' . "\n";
    }
}
add_action( 'wp_head', 'terra_blue_alignment_css', 90 );

// ─── Block Editor Assets ─────────────────────────────────────────────────────
function terra_blue_block_editor_assets() {
    wp_enqueue_style(  'terra-blue-editor-style', TERRA_BLUE_URI . '/css/editor-style.css', [ 'wp-edit-blocks' ], TERRA_BLUE_VERSION );
    wp_enqueue_script( 'terra-blue-blocks',       TERRA_BLUE_URI . '/js/blocks.js',         [ 'wp-blocks', 'wp-element', 'wp-editor', 'wp-components', 'wp-i18n' ], TERRA_BLUE_VERSION, true );
}
add_action( 'enqueue_block_editor_assets', 'terra_blue_block_editor_assets' );

// ─── Single Post Overflow Fix — injected at high priority ────────────────────
function terra_blue_single_post_containment() {
    if ( ! is_singular( 'post' ) ) return;
    ?>
    <style id="terra-blue-single-containment">
    html,body,#page,.site,#content,.site-content,.site-main{max-width:100vw!important;overflow-x:hidden!important;box-sizing:border-box!important}
    .nx-single-wrap{width:100%!important;max-width:100vw!important;overflow:hidden!important;padding:0 16px!important;box-sizing:border-box!important}
    .nx-single-post{display:block!important;width:100%!important;max-width:700px!important;margin-left:auto!important;margin-right:auto!important;overflow:hidden!important;box-sizing:border-box!important;float:none!important}
    .nx-single-post *{max-width:100%!important;box-sizing:border-box!important}
    .nx-single-post img,.nx-single-post iframe,.nx-single-post video,.nx-single-post embed,.nx-single-post table,.nx-single-post pre,.nx-single-post figure{max-width:100%!important;height:auto!important}
    .nx-single-post table{display:block!important;overflow-x:auto!important}
    .nx-single-post .entry-content,.nx-single-post .nx-post-content,.nx-single-post .nx-single-post__body{width:100%!important;max-width:100%!important;overflow:hidden!important}
    .nx-single-post .jp-relatedposts,.nx-single-post .sharedaddy,.nx-single-post .sd-block,.nx-single-post .wpcnt,.nx-single-post #jp-relatedposts{max-width:100%!important;overflow:hidden!important}
    .nx-single-post .jp-relatedposts-items{display:flex!important;flex-wrap:wrap!important;gap:12px!important}
    .nx-single-post .jp-relatedposts-post{flex:1 1 180px!important;min-width:0!important}
    </style>
    <?php
}
add_action( 'wp_head', 'terra_blue_single_post_containment', 9999 );

// ─── Add Theme-Color Meta ─────────────────────────────────────────────────────
function terra_blue_meta_theme_color() {
    $color = get_theme_mod( 'terra_blue_theme_color', '#080C10' );
    echo '<meta name="theme-color" content="' . esc_attr( $color ) . '">' . "\n";
    echo '<meta name="color-scheme" content="dark light">' . "\n";
    echo '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">' . "\n";
}
add_action( 'wp_head', 'terra_blue_meta_theme_color', 1 );

// ─── Resource Hints — preconnect to font CDN ────────────────────────────────
function terra_blue_resource_hints( $urls, $relation_type ) {
    if ( 'preconnect' === $relation_type ) {
        $urls[] = array( 'href' => 'https://fonts.googleapis.com' );
        $urls[] = array( 'href' => 'https://fonts.gstatic.com', 'crossorigin' => 'anonymous' );
    }
    return $urls;
}
add_filter( 'wp_resource_hints', 'terra_blue_resource_hints', 10, 2 );

// ─── Widgets & Sidebars ───────────────────────────────────────────────────────
function terra_blue_widgets_init() {

    $shared = [
        'before_widget' => '<section id="%1$s" class="nx-widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3 class="nx-widget-title">',
        'after_title'   => '</h3>',
    ];

    register_sidebar( array_merge( $shared, [
        'name'        => __( 'Primary Sidebar',    TERRA_BLUE_TEXT ),
        'id'          => 'sidebar-1',
        'description' => __( 'Widgets in the main sidebar.', TERRA_BLUE_TEXT ),
    ] ) );

    register_sidebar( array_merge( $shared, [
        'name'        => __( 'Blog Sidebar',       TERRA_BLUE_TEXT ),
        'id'          => 'sidebar-blog',
        'description' => __( 'Widgets in the blog sidebar.', TERRA_BLUE_TEXT ),
    ] ) );

    register_sidebar( array_merge( $shared, [
        'name'        => __( 'Shop Sidebar',       TERRA_BLUE_TEXT ),
        'id'          => 'sidebar-shop',
        'description' => __( 'Widgets in the WooCommerce shop sidebar.', TERRA_BLUE_TEXT ),
    ] ) );

    // Footer widget areas
    for ( $i = 1; $i <= 4; $i++ ) {
        register_sidebar( array_merge( $shared, [
            /* translators: %d: footer column number */
            'name'        => sprintf( __( 'Footer Column %d', TERRA_BLUE_TEXT ), $i ),
            'id'          => "footer-{$i}",
            'description' => sprintf( __( 'Footer column %d widgets.', TERRA_BLUE_TEXT ), $i ),
        ] ) );
    }

    register_sidebar( array_merge( $shared, [
        'name'        => __( 'Hero Area',          TERRA_BLUE_TEXT ),
        'id'          => 'hero-area',
        'description' => __( 'Widgets displayed in hero area.', TERRA_BLUE_TEXT ),
    ] ) );

    register_sidebar( array_merge( $shared, [
        'name'        => __( 'Off-Canvas Panel',   TERRA_BLUE_TEXT ),
        'id'          => 'offcanvas',
        'description' => __( 'Widgets in the off-canvas panel.', TERRA_BLUE_TEXT ),
    ] ) );
}
add_action( 'widgets_init', 'terra_blue_widgets_init' );

// ─── Custom Excerpt ───────────────────────────────────────────────────────────
function terra_blue_excerpt_length( $length ) {
    return is_admin() ? $length : 20;
}
add_filter( 'excerpt_length', 'terra_blue_excerpt_length' );

function terra_blue_excerpt_more( $more ) {
    return is_admin() ? $more : '&hellip;';
}
add_filter( 'excerpt_more', 'terra_blue_excerpt_more' );

// ─── Read Time Calculation ────────────────────────────────────────────────────
function terra_blue_reading_time( $post_id = null ) {
    $post_id  = $post_id ?: get_the_ID();
    $content  = get_post_field( 'post_content', $post_id );
    $words    = str_word_count( wp_strip_all_tags( $content ) );
    $minutes  = max( 1, (int) ceil( $words / 200 ) );
    /* translators: %d: reading time in minutes */
    return sprintf( _n( '%d min read', '%d min read', $minutes, TERRA_BLUE_TEXT ), $minutes );
}

// ─── Body Classes ─────────────────────────────────────────────────────────────
function terra_blue_body_classes( $classes ) {
    if ( is_singular() ) {
        $classes[] = 'nx-singular';
    }
    if ( is_singular( 'post' ) ) {
        $classes[] = 'nx-single-post';
    }
    if ( is_home() || is_archive() || is_search() ) {
        $classes[] = 'nx-post-archive';
    }
    if ( has_post_thumbnail() ) {
        $classes[] = 'has-thumbnail';
    }
    if ( get_theme_mod( 'terra_blue_sticky_header', true ) ) {
        $classes[] = 'nx-sticky-header';
    }
    if ( is_active_sidebar( 'sidebar-1' ) && ! is_page() ) {
        $classes[] = 'nx-has-sidebar';
    }
    if ( function_exists( 'is_woocommerce' ) && is_woocommerce() ) {
        $classes[] = 'nx-woocommerce-page';
    }
    return $classes;
}
add_filter( 'body_class', 'terra_blue_body_classes' );

// ─── Nav Menu Item Classes ────────────────────────────────────────────────────
function terra_blue_nav_menu_objects( $items ) {
    foreach ( $items as &$item ) {
        if ( $item->object === 'custom' ) {
            $item->classes[] = 'nx-custom-menu-item';
        }
        // Mark parent items that have children
        foreach ( $items as $parent ) {
            if ( (int) $item->menu_item_parent === (int) $parent->ID ) {
                $parent->classes[] = 'nx-has-children';
            }
        }
    }
    return $items;
}
add_filter( 'wp_nav_menu_objects', 'terra_blue_nav_menu_objects' );

// ─── Pagination ───────────────────────────────────────────────────────────────
function terra_blue_pagination( $args = [] ) {
    global $wp_query;
    $defaults = [
        'total'         => $wp_query->max_num_pages,
        'current'       => max( 1, get_query_var( 'paged' ) ),
        'mid_size'      => 2,
        'prev_text'     => '&larr;',
        'next_text'     => '&rarr;',
        'before_page_number' => '',
        'after_page_number'  => '',
    ];
    $args = wp_parse_args( $args, $defaults );
    $links = paginate_links( $args );
    if ( $links ) {
        echo '<nav class="nx-pagination" aria-label="' . esc_attr__( 'Posts pagination', TERRA_BLUE_TEXT ) . '">';
        echo wp_kses_post( $links );
        echo '</nav>';
    }
}

// ─── Dynamic CSS Output ───────────────────────────────────────────────────────
if ( ! function_exists( 'terra_blue_dynamic_css' ) ) :
function terra_blue_dynamic_css() {
    $accent      = get_theme_mod( 'terra_blue_accent_color',    '#00D9C0' );
    $accent_2    = get_theme_mod( 'terra_blue_accent_2_color',  '#7C3AED' );
    $font_body   = get_theme_mod( 'terra_blue_font_body',       '' );
    $font_disp   = get_theme_mod( 'terra_blue_font_display',    '' );
    $logo_h      = absint( get_theme_mod( 'terra_blue_logo_height',    28 ) );
    $logo_w      = absint( get_theme_mod( 'terra_blue_logo_max_width', 100 ) );

    $css = ':root{';
    if ( $accent )    $css .= "--nx-accent:{$accent};";
    if ( $accent_2 )  $css .= "--nx-accent-2:{$accent_2};";
    if ( $font_body ) $css .= "--nx-font-body:'{$font_body}',system-ui,sans-serif;";
    if ( $font_disp ) $css .= "--nx-font-display:'{$font_disp}',system-ui,sans-serif;";
    $css .= "--nx-logo-height:{$logo_h}px;";
    $css .= "--nx-logo-max-width:{$logo_w}px;";
    $css .= '}';

    wp_add_inline_style( 'terra-blue-style', $css );
}
endif;
add_action( 'wp_enqueue_scripts', 'terra_blue_dynamic_css' );

// ─── Custom Gutenberg Block Category ─────────────────────────────────────────
function terra_blue_block_categories( $categories ) {
    return array_merge(
        [ [
            'slug'  => 'terra-blue',
            'title' => __( 'Terra-Blue Blocks', TERRA_BLUE_TEXT ),
            'icon'  => 'star-filled',
        ] ],
        $categories
    );
}
add_filter( 'block_categories_all', 'terra_blue_block_categories' );

// ─── Comments Template ────────────────────────────────────────────────────────
function terra_blue_comment_form_defaults( $defaults ) {
    $defaults['class_container'] = 'nx-comment-form-wrap';
    $defaults['class_form']      = 'nx-comment-form';
    $defaults['label_submit']    = __( 'Post Comment', TERRA_BLUE_TEXT );
    $defaults['submit_button']   = '<input name="%1$s" type="submit" id="%2$s" class="%3$s nx-btn nx-btn-primary" value="%4$s" />';
    return $defaults;
}
add_filter( 'comment_form_defaults', 'terra_blue_comment_form_defaults' );

// ─── End of functions.php ────────────────────────────────────────────────────
