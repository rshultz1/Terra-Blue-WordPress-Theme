<?php
/**
 * Template part for displaying a featured/hero post card
 *
 * @package Terra-Blue
 */

defined( 'ABSPATH' ) || exit;

?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'nx-post-card nx-post-card--featured nx-reveal' ); ?> itemscope itemtype="https://schema.org/BlogPosting">

	<?php if ( has_post_thumbnail() ) : ?>
	<a class="nx-post-card__thumbnail" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
		<?php the_post_thumbnail( 'terra-blue-featured', array( 'itemprop' => 'image' ) ); ?>
		<div class="nx-post-card__overlay"></div>
	</a>
	<?php endif; ?>

	<div class="nx-post-card__body">
		<div class="nx-post-card__cats">
			<span class="nx-badge nx-badge--accent"><?php esc_html_e( 'Featured', 'terra-blue' ); ?></span>
			<?php terra_blue_post_categories(); ?>
		</div>

		<h2 class="nx-post-card__title nx-post-card__title--lg" itemprop="headline">
			<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
		</h2>

		<p class="nx-post-card__excerpt" itemprop="description">
			<?php echo wp_trim_words( get_the_excerpt(), 30, '…' ); ?>
		</p>

		<footer class="nx-post-card__footer">
			<div class="nx-post-card__author">
				<?php echo get_avatar( get_the_author_meta( 'ID' ), 36, '', '', array( 'class' => 'nx-post-card__avatar' ) ); ?>
				<div>
					<span class="nx-post-card__author-name" itemprop="author"><?php the_author(); ?></span>
					<time class="nx-post-card__date" datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>" itemprop="datePublished">
						<?php echo esc_html( get_the_date() ); ?>
					</time>
				</div>
			</div>
			<a href="<?php the_permalink(); ?>" class="nx-post-card__cta nx-button nx-button--ghost nx-button--sm">
				<?php esc_html_e( 'Read More', 'terra-blue' ); ?>
				<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14"/><polyline points="12 5 19 12 12 19"/></svg>
			</a>
		</footer>
	</div>

</article>
