<?php
/**
 * Template Part: Newsletter Signup Form
 * Used in footer when terra_blue_footer_newsletter customizer option is enabled.
 *
 * @package Terra-Blue
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="nx-newsletter-form" data-nx-newsletter>
	<form class="nx-newsletter-form__form" novalidate>
		<div class="nx-newsletter-form__fields">
			<label for="nx-newsletter-email" class="screen-reader-text">
				<?php esc_html_e( 'Your email address', 'terra-blue' ); ?>
			</label>
			<input
				id="nx-newsletter-email"
				type="email"
				name="email"
				class="nx-newsletter-form__input"
				placeholder="<?php esc_attr_e( 'your@email.com', 'terra-blue' ); ?>"
				required
				autocomplete="email"
			>
			<button type="submit" class="nx-btn nx-btn-primary">
				<?php esc_html_e( 'Subscribe', 'terra-blue' ); ?>
			</button>
		</div>
		<p class="nx-newsletter-form__status" role="status" aria-live="polite" hidden></p>
		<p class="nx-newsletter-form__note">
			<?php esc_html_e( 'No spam. Unsubscribe any time.', 'terra-blue' ); ?>
		</p>
	</form>
</div>

<script>
( function() {
	var form = document.querySelector( '[data-nx-newsletter] form' );
	if ( ! form ) return;
	form.addEventListener( 'submit', function( e ) {
		e.preventDefault();
		var email  = form.querySelector( 'input[type="email"]' ).value;
		var status = form.querySelector( '.nx-newsletter-form__status' );
		var btn    = form.querySelector( 'button[type="submit"]' );
		if ( ! email ) return;
		btn.disabled = true;
		var data = new FormData();
		data.append( 'action', 'terra_blue_newsletter' );
		data.append( 'email',  email );
		data.append( 'nonce',  ( window.TT6ixData && window.TT6ixData.nonce ) || '' );
		fetch( ( window.TT6ixData && window.TT6ixData.ajaxUrl ) || '<?php echo esc_url( admin_url( "admin-ajax.php" ) ); ?>', {
			method: 'POST',
			body: data,
		} )
		.then( function( r ) { return r.json(); } )
		.then( function( res ) {
			status.hidden = false;
			status.textContent = res.data && res.data.message ? res.data.message : ( res.success ? '<?php esc_html_e( "Thank you!", "terra-blue" ); ?>' : '<?php esc_html_e( "Something went wrong.", "terra-blue" ); ?>' );
			if ( res.success ) form.reset();
		} )
		.catch( function() {
			status.hidden = false;
			status.textContent = '<?php esc_html_e( "Something went wrong. Please try again.", "terra-blue" ); ?>';
		} )
		.finally( function() { btn.disabled = false; } );
	} );
} )();
</script>
