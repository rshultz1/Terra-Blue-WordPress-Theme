<?php
/**
 * Template part for displaying post cards
 *
 * @package Terra-Blue
 */

defined( 'ABSPATH' ) || exit;


$show_excerpt  = get_theme_mod( 'terra_blue_show_excerpt', true );
$show_author   = get_theme_mod( 'terra_blue_show_author', true );
$show_category = get_theme_mod( 'terra_blue_show_cat', true );
$show_readtime = get_theme_mod( 'terra_blue_show_read_time', true );
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'nx-card nx-post-card nx-reveal' ); ?> itemscope itemtype="https://schema.org/BlogPosting">

	<?php if ( has_post_thumbnail() ) : ?>
	<a class="nx-post-card__thumbnail" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
		<?php the_post_thumbnail( 'terra-blue-card', array( 'itemprop' => 'image', 'loading' => 'lazy' ) ); ?>
		<?php if ( $show_category ) : ?>
		<div class="nx-post-card__cats">
			<?php terra_blue_post_categories(); ?>
		</div>
		<?php endif; ?>
	</a>
	<?php endif; ?>

	<div class="nx-post-card__body">

		<?php if ( ! has_post_thumbnail() && $show_category ) : ?>
		<?php terra_blue_post_categories(); ?>
		<?php endif; ?>

		<h2 class="nx-post-card__title" itemprop="headline">
			<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
		</h2>

		<?php if ( $show_excerpt ) : ?>
		<p class="nx-post-card__excerpt" itemprop="description"><?php echo wp_trim_words( get_the_excerpt(), 20, '…' ); ?></p>
		<?php endif; ?>

		<footer class="nx-post-card__footer">
			<?php if ( $show_author ) : ?>
			<div class="nx-post-card__author">
				<?php echo get_avatar( get_the_author_meta( 'ID' ), 28, '', '', array( 'class' => 'nx-post-card__avatar' ) ); ?>
				<span itemprop="author"><?php the_author(); ?></span>
			</div>
			<?php endif; ?>
			<div class="nx-post-card__meta">
				<time class="nx-post-card__date" datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>" itemprop="datePublished">
					<?php echo esc_html( get_the_date() ); ?>
				</time>
				<?php if ( $show_readtime ) : ?>
				<span class="nx-post-card__readtime"><?php echo esc_html( terra_blue_reading_time() ); ?></span>
				<?php endif; ?>
			</div>
		</footer>

	</div>

</article>
