<?php
/**
 * Template part — BlogCarousel v1 (Floating 3D Blog Post Carousel)
 *
 * Self-contained full-width section with dark-teal backlit 3D perspective
 * carousel, ambient glow orbs, and translucent glass cards.
 *
 * Renders outside nx-container — see index.php.
 *
 * @package Terra-Blue
 * @since   2.0.0
 */

defined( 'ABSPATH' ) || exit;

$carousel_posts = new WP_Query( array(
    'posts_per_page'      => 6,
    'post_status'         => 'publish',
    'ignore_sticky_posts' => true,
    'no_found_rows'       => true,
    'orderby'             => 'date',
    'order'               => 'DESC',
) );

if ( ! $carousel_posts->have_posts() ) {
    return;
}

$total = $carousel_posts->post_count;
?>

<div class="bc-section-wrap" role="region" aria-label="<?php esc_attr_e( 'Featured posts carousel', 'terra-blue' ); ?>">

    <!-- Ambient background & orbs — positioned inside the wrap -->
    <div class="bc-ambient-bg" aria-hidden="true"></div>
    <div class="bc-orb bc-orb--1" aria-hidden="true"></div>
    <div class="bc-orb bc-orb--2" aria-hidden="true"></div>
    <div class="bc-orb bc-orb--3" aria-hidden="true"></div>

    <section class="bc-carousel" data-bc-carousel data-total="<?php echo esc_attr( $total ); ?>">

        <!-- Section header -->
        <header class="bc-header">
            <h2 class="bc-header__title">
                <?php echo esc_html( get_theme_mod( 'terra_blue_carousel_title', __( 'From the Blog', 'terra-blue' ) ) ); ?>
            </h2>
            <p class="bc-header__subtitle">
                <?php echo esc_html( get_theme_mod( 'terra_blue_carousel_subtitle', __( 'Curated insights, deep dives, and fresh perspectives on what matters most.', 'terra-blue' ) ) ); ?>
            </p>
        </header>

        <!-- 3D Stage -->
        <div class="bc-wrapper" id="bcWrapper">
            <div class="bc-stage" id="bcStage">
                <?php
                $i = 0;
                while ( $carousel_posts->have_posts() ) :
                    $carousel_posts->the_post();

                    // Calculate estimated reading time
                    $content    = get_the_content();
                    $word_count = str_word_count( wp_strip_all_tags( $content ) );
                    $read_time  = max( 1, (int) ceil( $word_count / 250 ) );

                    // Get first category
                    $categories   = get_the_category();
                    $category_name = ! empty( $categories ) ? $categories[0]->name : __( 'Uncategorized', 'terra-blue' );
                ?>

                <article class="bc-card" data-index="<?php echo esc_attr( $i ); ?>" itemscope itemtype="https://schema.org/BlogPosting">
                    <div class="bc-card__inner">

                        <!-- Image -->
                        <div class="bc-card__image">
                            <?php if ( has_post_thumbnail() ) : ?>
                                <a href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
                                    <?php the_post_thumbnail( 'medium_large', array(
                                        'itemprop' => 'image',
                                        'loading'  => 'lazy',
                                        'alt'      => the_title_attribute( array( 'echo' => false ) ),
                                    ) ); ?>
                                </a>
                            <?php else : ?>
                                <div class="bc-card__image-placeholder" aria-hidden="true"></div>
                            <?php endif; ?>
                            <div class="bc-card__image-overlay" aria-hidden="true"></div>
                            <span class="bc-card__category"><?php echo esc_html( $category_name ); ?></span>
                        </div>

                        <!-- Content -->
                        <div class="bc-card__content">
                            <div>
                                <h3 class="bc-card__title" itemprop="headline">
                                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                </h3>
                                <p class="bc-card__excerpt" itemprop="description">
                                    <?php echo esc_html( wp_trim_words( get_the_excerpt(), 16, '&hellip;' ) ); ?>
                                </p>
                            </div>
                            <footer class="bc-card__meta">
                                <div class="bc-card__author">
                                    <?php echo get_avatar( get_the_author_meta( 'ID' ), 30, '', esc_attr( get_the_author() ), array( 'class' => 'bc-card__avatar' ) ); ?>
                                    <div class="bc-card__author-info">
                                        <span class="bc-card__author-name" itemprop="author"><?php the_author(); ?></span>
                                        <time class="bc-card__date" datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>" itemprop="datePublished">
                                            <?php echo esc_html( get_the_date( 'M j, Y' ) ); ?>
                                        </time>
                                    </div>
                                </div>
                                <span class="bc-card__readtime">
                                    <?php
                                    /* translators: %d: estimated reading time in minutes */
                                    printf( esc_html__( '%d min', 'terra-blue' ), $read_time );
                                    ?>
                                </span>
                            </footer>
                        </div>

                    </div>
                </article>

                <?php
                    $i++;
                endwhile;
                ?>
            </div>
            <div class="bc-reflection" aria-hidden="true"></div>
        </div>

        <!-- Controls -->
        <nav class="bc-controls" aria-label="<?php esc_attr_e( 'Carousel navigation', 'terra-blue' ); ?>">
            <button class="bc-btn" id="bcPrev" aria-label="<?php esc_attr_e( 'Previous post', 'terra-blue' ); ?>" data-bc-prev type="button">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="15 18 9 12 15 6"/></svg>
            </button>
            <div class="bc-dots" id="bcDots" data-bc-dots role="tablist" aria-label="<?php esc_attr_e( 'Slide indicators', 'terra-blue' ); ?>">
                <?php for ( $d = 0; $d < $total; $d++ ) : ?>
                <button class="bc-dot<?php echo 0 === $d ? ' active' : ''; ?>"
                        data-dot="<?php echo esc_attr( $d ); ?>"
                        type="button"
                        role="tab"
                        aria-selected="<?php echo 0 === $d ? 'true' : 'false'; ?>"
                        aria-label="<?php echo esc_attr( sprintf( __( 'Go to post %d', 'terra-blue' ), $d + 1 ) ); ?>"></button>
                <?php endfor; ?>
            </div>
            <button class="bc-btn" id="bcNext" aria-label="<?php esc_attr_e( 'Next post', 'terra-blue' ); ?>" data-bc-next type="button">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="9 18 15 12 9 6"/></svg>
            </button>
        </nav>

    </section>

</div><!-- .bc-section-wrap -->

<?php wp_reset_postdata(); ?>
