<?php
/**
 * Template part for displaying a message when no posts are found
 *
 * @package Terra-Blue
 */

defined( 'ABSPATH' ) || exit;

?>

<section class="nx-no-results nx-reveal">
	<div class="nx-no-results__icon" aria-hidden="true">
		<svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
			<path d="M14.5 10c-.83 0-1.5-.67-1.5-1.5v-5c0-.83.67-1.5 1.5-1.5s1.5.67 1.5 1.5v5c0 .83-.67 1.5-1.5 1.5z"/><path d="M20.5 10H19V8.5c0-.83.67-1.5 1.5-1.5s1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"/><path d="M9.5 14c.83 0 1.5.67 1.5 1.5v5c0 .83-.67 1.5-1.5 1.5S8 21.33 8 20.5v-5c0-.83.67-1.5 1.5-1.5z"/><path d="M3.5 14H5v1.5c0 .83-.67 1.5-1.5 1.5S2 16.33 2 15.5 2.67 14 3.5 14z"/><path d="M14 14.5c0-.83.67-1.5 1.5-1.5h5c.83 0 1.5.67 1.5 1.5s-.67 1.5-1.5 1.5h-5c-.83 0-1.5-.67-1.5-1.5z"/><path d="M15.5 19H14v1.5c0 .83.67 1.5 1.5 1.5s1.5-.67 1.5-1.5-.67-1.5-1.5-1.5z"/><path d="M10 9.5C10 8.67 9.33 8 8.5 8h-5C2.67 8 2 8.67 2 9.5S2.67 11 3.5 11h5c.83 0 1.5-.67 1.5-1.5z"/><path d="M8.5 5H10V3.5C10 2.67 9.33 2 8.5 2S7 2.67 7 3.5 7.67 5 8.5 5z"/>
		</svg>
	</div>
	<h2 class="nx-no-results__title"><?php esc_html_e( 'Nothing Found', 'terra-blue' ); ?></h2>

	<?php if ( is_home() && current_user_can( 'publish_posts' ) ) : ?>
		<p class="nx-no-results__text">
			<?php
			printf(
				wp_kses( __( 'Ready to publish your first post? <a href="%1$s">Get started here</a>.', 'terra-blue' ), array( 'a' => array( 'href' => array() ) ) ),
				esc_url( admin_url( 'post-new.php' ) )
			);
			?>
		</p>

	<?php elseif ( is_search() ) : ?>
		<p class="nx-no-results__text"><?php esc_html_e( 'Sorry, no results matched your search. Try with different keywords.', 'terra-blue' ); ?></p>
		<?php get_search_form(); ?>

	<?php else : ?>
		<p class="nx-no-results__text"><?php esc_html_e( "It seems we can't find what you're looking for. Perhaps searching can help.", 'terra-blue' ); ?></p>
		<?php get_search_form(); ?>

	<?php endif; ?>

	<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="nx-button nx-button--primary">
		<?php esc_html_e( '← Back to Home', 'terra-blue' ); ?>
	</a>
</section>
