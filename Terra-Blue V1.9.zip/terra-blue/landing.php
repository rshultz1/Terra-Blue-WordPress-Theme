<?php
defined( 'ABSPATH' ) || exit;
/**
 * Template Name: Landing Page
 * Description: A distraction-free landing page — no header nav or footer widgets.
 *
 * @package Terra-Blue
 */

get_header(); ?>

<div class="nx-landing-template">

	<?php while ( have_posts() ) : the_post(); ?>

		<article id="post-<?php the_ID(); ?>" <?php post_class( 'nx-landing-content' ); ?>>

			<div class="entry-content nx-entry-content">
				<?php
				the_content();
				wp_link_pages( array(
					'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'terra-blue' ),
					'after'  => '</div>',
				) );
				?>
			</div>

		</article>

	<?php endwhile; ?>

</div>

<?php get_footer(); ?>
