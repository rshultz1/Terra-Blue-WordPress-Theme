<?php
defined( 'ABSPATH' ) || exit;
/**
 * Template Name: Team
 * Description: A team members page with card grid layout.
 *
 * @package Terra-Blue
 */

get_header(); ?>

<div class="nx-container-wide nx-section nx-team-template">

	<?php while ( have_posts() ) : the_post(); ?>

		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

			<header class="nx-page-header" style="text-align: center;">
				<?php the_title( '<h1 class="nx-page-title">', '</h1>' ); ?>
			</header>

			<div class="entry-content nx-entry-content">
				<?php the_content(); ?>
			</div>

		</article>

	<?php endwhile; ?>

	<?php
	$team_query = new WP_Query( array(
		'post_type'      => 'team_member',
		'posts_per_page' => 50,
		'orderby'        => 'menu_order',
		'order'          => 'ASC',
	) );

	if ( $team_query->have_posts() ) :
	?>
	<div class="nx-team-grid nx-stagger">
		<?php while ( $team_query->have_posts() ) : $team_query->the_post(); ?>

			<div <?php post_class( 'nx-card nx-team-card nx-reveal' ); ?>>
				<?php if ( has_post_thumbnail() ) : ?>
				<div class="nx-team-card__photo">
					<?php the_post_thumbnail( 'terra-blue-card', array( 'loading' => 'lazy' ) ); ?>
				</div>
				<?php endif; ?>
				<div class="nx-team-card__body">
					<h3 class="nx-team-card__name"><?php the_title(); ?></h3>
					<?php if ( $role = get_post_meta( get_the_ID(), '_team_role', true ) ) : ?>
						<p class="nx-team-card__role"><?php echo esc_html( $role ); ?></p>
					<?php endif; ?>
					<?php if ( has_excerpt() ) : ?>
						<p class="nx-team-card__bio"><?php echo wp_trim_words( get_the_excerpt(), 20, '&hellip;' ); ?></p>
					<?php endif; ?>
				</div>
			</div>

		<?php endwhile; wp_reset_postdata(); ?>
	</div>
	<?php endif; ?>

</div>

<?php get_footer(); ?>
