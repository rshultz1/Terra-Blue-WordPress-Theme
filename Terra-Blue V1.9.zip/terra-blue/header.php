<!doctype html>
<html <?php language_attributes(); ?> data-theme="dark">
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div id="page" class="site">

    <a class="screen-reader-text" href="#main"><?php esc_html_e( 'Skip to content', 'terra-blue' ); ?></a>

    <!-- ═══ SITE HEADER ═══ -->
    <header id="masthead" class="site-header" role="banner" aria-label="<?php esc_attr_e( 'Site header', 'terra-blue' ); ?>">
        <div class="nx-container-wide nx-header-inner">

            <!-- Logo -->
            <div class="nx-logo-wrap">
                <?php if ( has_custom_logo() ) : ?>
                    <?php the_custom_logo(); ?>
                <?php else : ?>
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="nx-logo" rel="home">
                        <span class="nx-logo-text">
                            <?php
                            $name  = get_bloginfo( 'name' );
                            $parts = explode( ' ', $name, 2 );
                            echo esc_html( $parts[0] );
                            if ( ! empty( $parts[1] ) ) {
                                echo '<span>' . esc_html( $parts[1] ) . '</span>';
                            }
                            ?>
                        </span>
                    </a>
                <?php endif; ?>
            </div>

            <!-- Primary Navigation -->
            <nav id="site-navigation" class="main-navigation" role="navigation" aria-label="<?php esc_attr_e( 'Primary Menu', 'terra-blue' ); ?>">
                <?php
                wp_nav_menu( [
                    'theme_location' => 'primary',
                    'menu_id'        => 'primary-menu',
                    'menu_class'     => 'nx-nav-menu',
                    'container'      => false,
                    'fallback_cb'    => 'terra_blue_fallback_nav',
                    'walker'         => class_exists( 'Terra_Blue_Nav_Walker' ) ? new Terra_Blue_Nav_Walker() : null,
                    'items_wrap'     => '<ul id="%1$s" class="%2$s" role="menubar">%3$s</ul>',
                ] );
                ?>
            </nav>

            <!-- Header Actions -->
            <div class="nx-header-actions">

                <!-- Search Toggle -->
                <button class="nx-search-toggle" aria-label="<?php esc_attr_e( 'Open Search', 'terra-blue' ); ?>" aria-expanded="false" aria-controls="nx-search-overlay" data-nx-search-toggle>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <circle cx="11" cy="11" r="8"></circle><path d="m21 21-4.35-4.35"></path>
                    </svg>
                </button>

                <!-- Theme Toggle -->
                <button class="nx-theme-toggle" aria-label="<?php esc_attr_e( 'Toggle color theme', 'terra-blue' ); ?>" data-nx-theme-toggle title="<?php esc_attr_e( 'Toggle dark/light mode', 'terra-blue' ); ?>">
                    <svg class="nx-icon-moon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
                    </svg>
                    <svg class="nx-icon-sun" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="display:none">
                        <circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
                    </svg>
                </button>

                <?php if ( function_exists( 'WC' ) && WC() && isset( WC()->cart ) ) : ?>
                <!-- WooCommerce Cart Icon -->
                <a href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="nx-btn nx-btn-secondary nx-btn-sm nx-cart-btn" aria-label="<?php esc_attr_e( 'Cart', 'terra-blue' ); ?>">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                    </svg>
                    <span class="nx-cart-count"><?php echo esc_html( WC()->cart->get_cart_contents_count() ); ?></span>
                </a>
                <?php endif; ?>

                <?php if ( get_theme_mod( 'terra_blue_header_cta_text' ) ) : ?>
                <a href="<?php echo esc_url( get_theme_mod( 'terra_blue_header_cta_url', '#' ) ); ?>" class="nx-btn nx-btn-primary nx-btn-sm">
                    <?php echo esc_html( get_theme_mod( 'terra_blue_header_cta_text' ) ); ?>
                </a>
                <?php endif; ?>

                <!-- Mobile Menu Toggle -->
                <button class="nx-menu-toggle" aria-label="<?php esc_attr_e( 'Toggle menu', 'terra-blue' ); ?>" aria-expanded="false" aria-controls="site-navigation" data-nx-menu-toggle>
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                </button>

            </div><!-- .nx-header-actions -->

        </div><!-- .nx-container-wide -->
    </header><!-- #masthead -->

    <!-- ═══ SEARCH OVERLAY ═══ -->
    <div id="nx-search-overlay" class="nx-search-overlay" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e( 'Search', 'terra-blue' ); ?>" data-nx-search-overlay>
        <div class="nx-search-form-wrap">
            <button class="nx-search-close" aria-label="<?php esc_attr_e( 'Close search', 'terra-blue' ); ?>" data-nx-search-close>
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
            <?php
            get_search_form();
            ?>
            <div id="nx-search-results" class="nx-search-results" role="listbox" aria-label="<?php esc_attr_e( 'Search results', 'terra-blue' ); ?>"></div>
        </div>
    </div>

    <!-- ═══ MAIN ═══ -->
    <div id="content" class="site-content">
        <main id="main" class="site-main" role="main" tabindex="-1">
