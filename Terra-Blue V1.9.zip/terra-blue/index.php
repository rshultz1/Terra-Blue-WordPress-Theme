<?php
defined( 'ABSPATH' ) || exit;
get_header();
?>

<?php if ( ( is_home() || is_front_page() ) && ! is_paged() ) : ?>

    <?php // BlogCarousel v1 renders full-width — outside nx-container ?>
    <?php get_template_part( 'template-parts/post', 'carousel' ); ?>

<?php else : ?>

<div class="nx-container-wide nx-section">

    <?php if ( is_home() && ! is_front_page() ) : ?>
        <header class="nx-archive-header">
            <h1 class="nx-archive-title"><?php esc_html_e( 'Blog', 'terra-blue' ); ?></h1>
        </header>
    <?php elseif ( is_archive() ) : ?>
        <header class="nx-archive-header">
            <?php the_archive_title( '<h1 class="nx-archive-title">', '</h1>' ); ?>
            <?php the_archive_description( '<div class="nx-archive-description">', '</div>' ); ?>
        </header>
    <?php elseif ( is_search() ) : ?>
        <header class="nx-archive-header">
            <h1 class="nx-archive-title">
                <?php printf( esc_html__( 'Search Results for: %s', 'terra-blue' ), '<span>' . get_search_query() . '</span>' ); ?>
            </h1>
        </header>
    <?php endif; ?>

    <div class="nx-blog-layout <?php echo is_active_sidebar( 'sidebar-1' ) ? 'nx-has-sidebar-layout' : ''; ?>">
        <div class="nx-blog-main">
            <?php if ( have_posts() ) : ?>
                <div class="nx-posts-grid nx-stagger" id="nx-posts-grid">
                    <?php
                    while ( have_posts() ) :
                        the_post();
                        get_template_part( 'template-parts/post', 'card' );
                    endwhile;
                    ?>
                </div>
                <?php terra_blue_pagination(); ?>
            <?php else : ?>
                <?php get_template_part( 'template-parts/content', 'none' ); ?>
            <?php endif; ?>
        </div>

        <?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
        <aside id="secondary" class="nx-sidebar widget-area" role="complementary" aria-label="<?php esc_attr_e( 'Blog Sidebar', 'terra-blue' ); ?>">
            <?php dynamic_sidebar( 'sidebar-1' ); ?>
        </aside>
        <?php endif; ?>
    </div>

</div>

<?php endif; ?>

<?php get_footer(); ?>
