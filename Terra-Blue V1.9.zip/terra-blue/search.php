<?php
/**
 * The template for displaying search results
 *
 * @package Terra-Blue
 */

defined( 'ABSPATH' ) || exit;


get_header();
?>

<main id="main" class="nx-site-main">
<div class="nx-container-wide">

	<header class="nx-archive-header nx-reveal">
		<div class="nx-archive-header__inner">
			<div class="nx-badge"><?php esc_html_e( 'Search Results', 'terra-blue' ); ?></div>
			<h1 class="nx-archive-header__title">
				<?php
				printf(
					esc_html__( 'Results for: %s', 'terra-blue' ),
					'<span class="nx-gradient-text">' . esc_html( get_search_query() ) . '</span>'
				);
				?>
			</h1>
			<?php if ( have_posts() ) : ?>
			<p class="nx-archive-header__desc">
				<?php
				printf(
					esc_html( _n( 'Found %s result', 'Found %s results', $wp_query->found_posts, 'terra-blue' ) ),
					'<strong>' . number_format_i18n( $wp_query->found_posts ) . '</strong>'
				);
				?>
			</p>
			<?php endif; ?>
		</div>
	</header>

	<div class="nx-search-bar nx-reveal">
		<?php get_search_form(); ?>
	</div>

	<?php if ( have_posts() ) : ?>

	<div class="nx-posts-grid nx-posts-grid--list" id="nx-posts-container">
		<?php
		while ( have_posts() ) :
			the_post();
			get_template_part( 'template-parts/post-card' );
		endwhile;
		?>
	</div>

	<?php terra_blue_pagination(); ?>

	<?php else : ?>

	<div class="nx-no-results nx-reveal">
		<div class="nx-no-results__icon">
			<svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/><line x1="11" y1="8" x2="11" y2="14"/><line x1="8" y1="11" x2="14" y2="11"/></svg>
		</div>
		<h2 class="nx-no-results__title"><?php esc_html_e( 'No results found', 'terra-blue' ); ?></h2>
		<p class="nx-no-results__text">
			<?php esc_html_e( 'Try different keywords or browse our latest posts.', 'terra-blue' ); ?>
		</p>
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="nx-button nx-button--primary">
			<?php esc_html_e( 'Back to Homepage', 'terra-blue' ); ?>
		</a>
	</div>

	<?php endif; ?>

</div>
</main>

<?php get_footer(); ?>
