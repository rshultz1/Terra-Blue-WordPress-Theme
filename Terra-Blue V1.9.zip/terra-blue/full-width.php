<?php
defined( 'ABSPATH' ) || exit;
/**
 * Template Name: Full Width
 * Description: A full-width page with no sidebar.
 *
 * @package Terra-Blue
 */

get_header(); ?>

<div class="nx-container-wide nx-section nx-full-width-template">

	<?php while ( have_posts() ) : the_post(); ?>

		<article id="post-<?php the_ID(); ?>" <?php post_class( 'nx-page-content' ); ?>>

			<?php if ( has_post_thumbnail() ) : ?>
			<div class="nx-page-hero">
				<?php the_post_thumbnail( 'terra-blue-hero', array( 'class' => 'nx-page-hero__img' ) ); ?>
			</div>
			<?php endif; ?>

			<header class="nx-page-header">
				<?php the_title( '<h1 class="nx-page-title">', '</h1>' ); ?>
			</header>

			<div class="entry-content nx-entry-content">
				<?php
				the_content();
				wp_link_pages( array(
					'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'terra-blue' ),
					'after'  => '</div>',
				) );
				?>
			</div>

		</article>

		<?php if ( comments_open() || get_comments_number() ) : ?>
			<?php comments_template(); ?>
		<?php endif; ?>

	<?php endwhile; ?>

</div>

<?php get_footer(); ?>
