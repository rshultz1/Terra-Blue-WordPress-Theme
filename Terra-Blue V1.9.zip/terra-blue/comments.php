<?php
/**
 * The template for displaying comments
 *
 * @package Terra-Blue
 */

defined( 'ABSPATH' ) || exit;


if ( post_password_required() ) {
	return;
}
?>

<section id="comments" class="nx-comments nx-reveal">

	<?php if ( have_comments() ) : ?>

	<h2 class="nx-comments__title">
		<?php
		$count = get_comments_number();
		printf(
			esc_html( _n( '%s Comment', '%s Comments', $count, 'terra-blue' ) ),
			'<span class="nx-gradient-text">' . number_format_i18n( $count ) . '</span>'
		);
		?>
	</h2>

	<ol class="nx-comment-list">
		<?php
		wp_list_comments( array(
			'style'       => 'ol',
			'short_ping'  => true,
			'avatar_size' => 48,
			'callback'    => 'terra_blue_comment_template',
		) );
		?>
	</ol>

	<?php if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) : ?>
	<nav class="nx-comment-pagination" aria-label="<?php esc_attr_e( 'Comment navigation', 'terra-blue' ); ?>">
		<div class="nx-comment-pagination__prev">
			<?php previous_comments_link( esc_html__( '← Older Comments', 'terra-blue' ) ); ?>
		</div>
		<div class="nx-comment-pagination__next">
			<?php next_comments_link( esc_html__( 'Newer Comments →', 'terra-blue' ) ); ?>
		</div>
	</nav>
	<?php endif; ?>

	<?php endif; ?>

	<?php if ( ! comments_open() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) : ?>
	<p class="nx-comments-closed"><?php esc_html_e( 'Comments are closed.', 'terra-blue' ); ?></p>
	<?php endif; ?>

	<?php
	comment_form( array(
		'class_form'           => 'nx-comment-form',
		'class_submit'         => 'nx-button nx-button--primary',
		'title_reply'          => esc_html__( 'Leave a Comment', 'terra-blue' ),
		'title_reply_before'   => '<h2 class="nx-comment-form__title">',
		'title_reply_after'    => '</h2>',
		'title_reply_to'       => esc_html__( 'Reply to %s', 'terra-blue' ),
		'cancel_reply_before'  => '<small>',
		'cancel_reply_after'   => '</small>',
		'label_submit'         => esc_html__( 'Post Comment', 'terra-blue' ),
		'comment_field'        => '<div class="nx-form-group"><label for="comment">' . esc_html__( 'Comment', 'terra-blue' ) . ' <span aria-hidden="true">*</span></label><textarea id="comment" name="comment" class="nx-form-control" rows="6" required></textarea></div>',
		'fields' => array(
			'author' => '<div class="nx-comment-form__fields"><div class="nx-form-group"><label for="author">' . esc_html__( 'Name', 'terra-blue' ) . ' <span aria-hidden="true">*</span></label><input id="author" name="author" type="text" class="nx-form-control" required></div>',
			'email'  => '<div class="nx-form-group"><label for="email">' . esc_html__( 'Email', 'terra-blue' ) . ' <span aria-hidden="true">*</span></label><input id="email" name="email" type="email" class="nx-form-control" required></div>',
			'url'    => '<div class="nx-form-group"><label for="url">' . esc_html__( 'Website', 'terra-blue' ) . '</label><input id="url" name="url" type="url" class="nx-form-control"></div></div>',
			'cookies' => '<div class="nx-form-check"><label><input type="checkbox" name="wp-comment-cookies-consent" value="yes"> ' . esc_html__( 'Save my name, email, and website in this browser for the next time I comment.', 'terra-blue' ) . '</label></div>',
		),
	) );
	?>

</section>
