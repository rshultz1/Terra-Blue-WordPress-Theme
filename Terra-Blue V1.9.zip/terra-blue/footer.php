        </main><!-- #main -->
    </div><!-- #content -->

    <!-- ═══ SITE FOOTER ═══ -->
    <footer id="colophon" class="site-footer" role="contentinfo">

        <div class="nx-footer-top">
            <div class="nx-container-wide">
                <div class="nx-footer-grid<?php echo ! get_theme_mod( 'terra_blue_footer_show_columns', true ) ? ' nx-footer-grid--brand-only' : ''; ?>">

                    <!-- Brand Column -->
                    <div class="nx-footer-brand">

                        <?php if ( $tagline = get_bloginfo( 'description' ) ) : ?>
                            <p><?php echo esc_html( $tagline ); ?></p>
                        <?php endif; ?>

                        <!-- Social Links -->
                        <?php if ( has_nav_menu( 'social' ) ) : ?>
                        <nav class="nx-footer-social" aria-label="<?php esc_attr_e( 'Social Links', 'terra-blue' ); ?>">
                            <?php
                            wp_nav_menu( [
                                'theme_location'  => 'social',
                                'container'       => false,
                                'menu_class'      => '',
                                'link_before'     => '<span class="screen-reader-text">',
                                'link_after'      => '</span>',
                                'depth'           => 1,
                                'fallback_cb'     => false,
                                'items_wrap'      => '%3$s',
                            ] );
                            ?>
                        </nav>
                        <?php else : ?>
                        <div class="nx-footer-social">
                            <?php
                            $socials = [
                                'terra_blue_twitter_url'   => [ 'Twitter/X', '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.748l7.73-8.835-8.164-10.665h5.69l4.259 5.658Zm-1.161 17.52h1.833L7.084 4.126H5.117Z"/></svg>' ],
                                'terra_blue_github_url'    => [ 'GitHub',    '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2A10 10 0 0 0 2 12c0 4.42 2.87 8.17 6.84 9.5.5.08.66-.23.66-.5v-1.69c-2.77.6-3.36-1.34-3.36-1.34-.46-1.16-1.11-1.47-1.11-1.47-.91-.62.07-.6.07-.6 1 .07 1.53 1.03 1.53 1.03.87 1.52 2.34 1.07 2.91.83.09-.65.35-1.09.63-1.34-2.22-.25-4.55-1.11-4.55-4.92 0-1.11.38-2 1.03-2.71-.1-.25-.45-1.29.1-2.64 0 0 .84-.27 2.75 1.02.79-.22 1.65-.33 2.5-.33.85 0 1.71.11 2.5.33 1.91-1.29 2.75-1.02 2.75-1.02.55 1.35.2 2.39.1 2.64.65.71 1.03 1.6 1.03 2.71 0 3.82-2.34 4.66-4.57 4.91.36.31.69.92.69 1.85V21c0 .27.16.59.67.5C19.14 20.16 22 16.42 22 12A10 10 0 0 0 12 2z"/></svg>' ],
                                'terra_blue_linkedin_url'  => [ 'LinkedIn',  '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6zM2 9h4v12H2z"/><circle cx="4" cy="4" r="2"/></svg>' ],
                                'terra_blue_instagram_url' => [ 'Instagram', '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line></svg>' ],
                                'terra_blue_youtube_url'   => [ 'YouTube',   '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M22.54 6.42a2.78 2.78 0 0 0-1.95-1.96C18.88 4 12 4 12 4s-6.88 0-8.59.46a2.78 2.78 0 0 0-1.95 1.96A29 29 0 0 0 1 12a29 29 0 0 0 .46 5.58A2.78 2.78 0 0 0 3.41 19.6C5.12 20 12 20 12 20s6.88 0 8.59-.46a2.78 2.78 0 0 0 1.95-1.95A29 29 0 0 0 23 12a29 29 0 0 0-.46-5.58zM9.75 15.02V8.98L15.5 12l-5.75 3.02z"/></svg>' ],
                            ];
                            foreach ( $socials as $mod_key => $data ) {
                                $url = get_theme_mod( $mod_key );
                                if ( $url ) {
                                    printf(
                                        '<a href="%s" target="_blank" rel="noopener noreferrer" aria-label="%s">%s</a>',
                                        esc_url( $url ),
                                        esc_attr( $data[0] ),
                                        $data[1] // phpcs:ignore
                                    );
                                }
                            }
                            ?>
                        </div>
                        <?php endif; ?>
                    </div>

                    <!-- Footer Navigation Columns -->
                    <?php if ( get_theme_mod( 'terra_blue_footer_show_columns', true ) ) : ?>
                    <?php
                    $footer_menus = [
                        'terra_blue_footer_col_1_title' => __( 'Company',   'terra-blue' ),
                        'terra_blue_footer_col_2_title' => __( 'Product',   'terra-blue' ),
                        'terra_blue_footer_col_3_title' => __( 'Resources', 'terra-blue' ),
                    ];
                    foreach ( $footer_menus as $mod_key => $default_title ) :
                        $title = get_theme_mod( $mod_key, $default_title );
                    ?>
                    <div class="nx-footer-col">
                        <h4><?php echo esc_html( $title ); ?></h4>
                        <?php
                        wp_nav_menu( [
                            'theme_location' => 'footer',
                            'container'      => false,
                            'depth'          => 1,
                            'fallback_cb'    => false,
                        ] );
                        ?>
                    </div>
                    <?php endforeach; ?>
                    <?php endif; ?>

                </div><!-- .nx-footer-grid -->

                <?php if ( get_theme_mod( 'terra_blue_footer_newsletter', false ) ) : ?>
                <!-- Newsletter Signup -->
                <div class="nx-footer-newsletter">
                    <h4><?php esc_html_e( 'Stay Updated', 'terra-blue' ); ?></h4>
                    <?php get_template_part( 'template-parts/newsletter', 'form' ); ?>
                </div>
                <?php endif; ?>

            </div><!-- .nx-container-wide -->
        </div><!-- .nx-footer-top -->

        <?php if ( get_theme_mod( 'terra_blue_footer_quicklinks_show', false ) ) : ?>
        <!-- Footer Quick Links Bar -->
        <div class="nx-footer-quicklinks" id="nx-footer-quicklinks">
            <div class="nx-container-wide">
                <div class="nx-quicklinks-row">
                    <?php for ( $ql = 1; $ql <= 9; $ql++ ) :
                        $text = get_theme_mod( "terra_blue_qlink_{$ql}_text", '' );
                        $url  = get_theme_mod( "terra_blue_qlink_{$ql}_url", '#' );
                        if ( $text ) : ?>
                        <a href="<?php echo esc_url( $url ); ?>" class="nx-quicklink" data-qlink="<?php echo esc_attr( $ql ); ?>"><?php echo esc_html( $text ); ?></a>
                    <?php endif; endfor; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Footer Bottom Bar -->
        <div class="nx-footer-bottom">
            <div class="nx-container-wide nx-flex-between" style="flex-wrap:wrap;gap:1rem">
                <p>
                    &copy; <?php echo esc_html( date( 'Y' ) ); // phpcs:ignore ?>
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a>.
                    <?php esc_html_e( 'All rights reserved.', 'terra-blue' ); ?>
                    &mdash; <?php printf( esc_html__( 'Built with %s', 'terra-blue' ), '<a href="https://wordpress.org" target="_blank" rel="noopener">WordPress</a> &amp; <a href="' . esc_url( home_url( '/' ) ) . '">Terra-Blue</a>' ); // phpcs:ignore ?>
                </p>
                <div class="nx-footer-bottom-links">
                    <?php
                    wp_nav_menu( [
                        'theme_location' => 'secondary',
                        'container'      => false,
                        'depth'          => 1,
                        'fallback_cb'    => false,
                    ] );
                    ?>
                </div>
            </div>
        </div>

    </footer><!-- #colophon -->

</div><!-- #page -->

<!-- ═══ BACK TO TOP ═══ -->
<button id="nx-back-to-top" class="nx-back-to-top" aria-label="<?php esc_attr_e( 'Back to top', 'terra-blue' ); ?>" data-nx-back-to-top>
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="18 15 12 9 6 15"></polyline></svg>
</button>

<!-- ═══ COOKIE NOTICE ═══ -->
<?php if ( get_theme_mod( 'terra_blue_cookie_notice', false ) && ! isset( $_COOKIE['nx_cookie_ok'] ) ) : ?>
<div id="nx-cookie-notice" class="nx-cookie-notice" role="alert">
    <div class="nx-container-wide nx-flex-between" style="gap:1rem;flex-wrap:wrap">
        <p><?php echo wp_kses_post( get_theme_mod( 'terra_blue_cookie_text', __( 'We use cookies to enhance your experience. By continuing to visit this site you agree to our use of cookies.', 'terra-blue' ) ) ); ?></p>
        <div style="display:flex;gap:.75rem;flex-shrink:0">
            <button class="nx-btn nx-btn-primary nx-btn-sm" id="nx-cookie-accept"><?php esc_html_e( 'Accept', 'terra-blue' ); ?></button>
            <a href="<?php echo esc_url( get_privacy_policy_url() ); ?>" class="nx-btn nx-btn-secondary nx-btn-sm"><?php esc_html_e( 'Learn More', 'terra-blue' ); ?></a>
        </div>
    </div>
</div>
<?php endif; ?>

<?php wp_footer(); ?>
</body>
</html>
