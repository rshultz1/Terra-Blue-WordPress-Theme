<?php
defined( 'ABSPATH' ) || exit;
/**
 * Template Name: Contact
 * Description: A contact page layout with space for a form and optional map.
 *
 * @package Terra-Blue
 */

get_header(); ?>

<div class="nx-container-wide nx-section nx-contact-template">

	<?php while ( have_posts() ) : the_post(); ?>

		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

			<header class="nx-page-header" style="text-align: center;">
				<?php the_title( '<h1 class="nx-page-title">', '</h1>' ); ?>
			</header>

			<div class="entry-content nx-entry-content">
				<?php the_content(); ?>
			</div>

		</article>

		<?php if ( comments_open() || get_comments_number() ) : ?>
			<?php comments_template(); ?>
		<?php endif; ?>

	<?php endwhile; ?>

</div>

<?php get_footer(); ?>
