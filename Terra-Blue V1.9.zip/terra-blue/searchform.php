<?php
/**
 * Template for displaying the search form
 *
 * @package Terra-Blue
 */

defined( 'ABSPATH' ) || exit;


$unique_id = esc_attr( uniqid( 'search-form-' ) );
?>
<div class="nx-search-form-wrap">
	<label for="<?php echo $unique_id; ?>" class="screen-reader-text"><?php esc_html_e( 'Search for:', 'terra-blue' ); ?></label>
	<div class="nx-search-form">
		<input
			type="search"
			id="<?php echo $unique_id; ?>"
			class="nx-search-form__input nx-form-control"
			placeholder="<?php esc_attr_e( 'Search…', 'terra-blue' ); ?>"
			value="<?php echo esc_attr( get_search_query() ); ?>"
			name="s"
			form="<?php echo $unique_id; ?>-form"
		>
		<form role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" id="<?php echo $unique_id; ?>-form" class="nx-search-form__form">
			<input type="hidden" name="s" value="">
			<button type="submit" class="nx-search-form__submit" aria-label="<?php esc_attr_e( 'Submit search', 'terra-blue' ); ?>">
				<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
			</button>
		</form>
	</div>
</div>
