<?php
/**
 * Custom Navigation Walker
 *
 * @package Terra-Blue
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class Terra_Blue_Nav_Walker extends Walker_Nav_Menu {

	/**
	 * Start level (sub-menu)
	 */
	public function start_lvl( &$output, $depth = 0, $args = null ) {
		$indent = str_repeat( "\t", $depth );
		$class  = $depth === 0 ? 'nx-nav__dropdown' : 'nx-nav__sub-dropdown';
		$output .= "\n$indent<ul class=\"$class\" role=\"menu\">\n";
	}

	/**
	 * End level
	 */
	public function end_lvl( &$output, $depth = 0, $args = null ) {
		$indent = str_repeat( "\t", $depth );
		$output .= "$indent</ul>\n";
	}

	/**
	 * Start element
	 */
	public function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {

		$classes   = empty( $item->classes ) ? array() : (array) $item->classes;
		$classes[] = 'nx-nav__item';

		if ( $depth === 0 ) {
			$classes[] = 'nx-nav__item--top';
		}

		$has_children = in_array( 'menu-item-has-children', $classes );

		if ( $has_children ) {
			$classes[] = 'nx-nav__item--has-dropdown';
		}

		$class_names = implode( ' ', array_filter( apply_filters( 'nav_menu_css_class', $classes, $item, $args, $depth ) ) );

		$id = apply_filters( 'nav_menu_item_id', 'menu-item-' . $item->ID, $item, $args, $depth );

		$output .= '<li' . ( $id ? ' id="' . esc_attr( $id ) . '"' : '' ) . ' class="' . esc_attr( $class_names ) . '">';

		$atts = array(
			'title'  => ! empty( $item->attr_title ) ? $item->attr_title : '',
			'target' => ! empty( $item->target ) ? $item->target : '',
			'rel'    => ! empty( $item->xfn ) ? $item->xfn : '',
			'href'   => ! empty( $item->url ) ? $item->url : '',
			'class'  => 'nx-nav__link',
		);

		if ( $depth === 0 ) {
			$atts['class'] .= ' nx-nav__link--top';
		}

		if ( in_array( 'current-menu-item', $classes ) || in_array( 'current-menu-ancestor', $classes ) ) {
			$atts['class']       .= ' nx-nav__link--active';
			$atts['aria-current'] = 'page';
		}

		if ( ! empty( $item->target ) && '_blank' === $item->target ) {
			$atts['rel'] = 'noopener noreferrer';
		}

		$atts = apply_filters( 'nav_menu_link_attributes', $atts, $item, $args, $depth );

		$attr_string = '';
		foreach ( $atts as $attr => $value ) {
			if ( is_scalar( $value ) && '' !== $value ) {
				$attr_string .= ' ' . $attr . '="' . esc_attr( $value ) . '"';
			}
		}

		$title = apply_filters( 'the_title', $item->title, $item->ID );
		$title = apply_filters( 'nav_menu_item_title', $title, $item, $args, $depth );

		$output .= '<a' . $attr_string . '>';
		$output .= esc_html( $title );

		if ( $has_children && $depth === 0 ) {
			$output .= '<svg class="nx-nav__chevron" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>';
		}

		$output .= '</a>';

		if ( $has_children ) {
			$output .= '<button class="nx-nav__toggle" aria-expanded="false" aria-label="' . esc_attr__( 'Toggle submenu', 'terra-blue' ) . '">';
			$output .= '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>';
			$output .= '</button>';
		}
	}

	/**
	 * End element
	 */
	public function end_el( &$output, $item, $depth = 0, $args = null ) {
		$output .= "</li>\n";
	}
}
