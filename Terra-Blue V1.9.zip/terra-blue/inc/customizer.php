<?php
/**
 * Terra-Blue Customizer
 *
 * @package Terra-Blue
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register Customizer settings, sections, and controls.
 */
function terra_blue_customizer_register( WP_Customize_Manager $wp_customize ) {

    // ─── Helper: Add Section ─────────────────────────────────────────────────
    $add_section = static function( $id, $title, $priority = 30 ) use ( $wp_customize ) {
        $wp_customize->add_section( $id, [
            'title'    => $title,
            'priority' => $priority,
        ] );
    };

    // ─── Helper: Add Control ─────────────────────────────────────────────────
    $add = static function( $id, $label, $section, $default, $type, $args = [] ) use ( $wp_customize ) {
        $wp_customize->add_setting( $id, array_merge( [
            'default'           => $default,
            'sanitize_callback' => 'terra_blue_sanitize_' . $type,
            'transport'         => 'postMessage',
        ], $args['setting'] ?? [] ) );

        $control_args = array_merge( [
            'label'   => $label,
            'section' => $section,
            'type'    => $type,
        ], $args['control'] ?? [] );

        if ( ! empty( $args['class'] ) ) {
            $control_class = $args['class'];
            $wp_customize->add_control( new $control_class( $wp_customize, $id, $control_args ) );
        } else {
            $wp_customize->add_control( $id, $control_args );
        }
    };

    // ═══════════════════════════════════════════════════════════════════
    // 1. IDENTITY
    // ═══════════════════════════════════════════════════════════════════
    $wp_customize->get_section( 'title_tagline' )->priority = 5;

    // Logo Height (px)
    $wp_customize->add_setting( 'terra_blue_logo_height', [
        'default'           => 28,
        'sanitize_callback' => 'absint',
        'transport'         => 'postMessage',
    ] );
    $wp_customize->add_control( 'terra_blue_logo_height', [
        'label'       => __( 'Logo Height (px)', 'terra-blue' ),
        'description' => __( 'Controls the maximum height of your site logo in the header. Range: 16–80px.', 'terra-blue' ),
        'section'     => 'title_tagline',
        'type'        => 'range',
        'priority'    => 8,
        'input_attrs' => [
            'min'  => 16,
            'max'  => 80,
            'step' => 2,
        ],
    ] );

    // Logo Max Width (px)
    $wp_customize->add_setting( 'terra_blue_logo_max_width', [
        'default'           => 100,
        'sanitize_callback' => 'absint',
        'transport'         => 'postMessage',
    ] );
    $wp_customize->add_control( 'terra_blue_logo_max_width', [
        'label'       => __( 'Logo Max Width (px)', 'terra-blue' ),
        'description' => __( 'Controls the maximum width of your site logo. Range: 40–300px.', 'terra-blue' ),
        'section'     => 'title_tagline',
        'type'        => 'range',
        'priority'    => 9,
        'input_attrs' => [
            'min'  => 40,
            'max'  => 300,
            'step' => 5,
        ],
    ] );

    // Favicon
    $wp_customize->add_setting( 'terra_blue_favicon', [
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
    ] );
    $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'terra_blue_favicon', [
        'label'   => __( 'Favicon', 'terra-blue' ),
        'section' => 'title_tagline',
    ] ) );

    // ═══════════════════════════════════════════════════════════════════
    // 2. COLORS & BRANDING
    // ═══════════════════════════════════════════════════════════════════
    $add_section( 'terra_blue_colors', __( 'Colors & Branding', 'terra-blue' ), 10 );

    $colors = [
        'terra_blue_accent_color'       => [ __( 'Accent Color (Primary)',   'terra-blue' ), '#00D9C0' ],
        'terra_blue_accent_2_color'     => [ __( 'Accent Color (Secondary)', 'terra-blue' ), '#7C3AED' ],
        'terra_blue_accent_3_color'     => [ __( 'Accent Color (Tertiary)',  'terra-blue' ), '#F59E0B' ],
        'terra_blue_theme_color'        => [ __( 'Browser Theme Color',      'terra-blue' ), '#080C10' ],
    ];
    foreach ( $colors as $id => $data ) {
        $wp_customize->add_setting( $id, [
            'default'           => $data[1],
            'sanitize_callback' => 'sanitize_hex_color',
            'transport'         => 'postMessage',
        ] );
        $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $id, [
            'label'   => $data[0],
            'section' => 'terra_blue_colors',
        ] ) );
    }

    // ═══════════════════════════════════════════════════════════════════
    // 3. TYPOGRAPHY
    // ═══════════════════════════════════════════════════════════════════
    $add_section( 'terra_blue_typography', __( 'Typography', 'terra-blue' ), 15 );

    $font_choices = [
        ''                   => __( '— Default —',        'terra-blue' ),
        'Syne'               => 'Syne (Display)',
        'Instrument Sans'    => 'Instrument Sans (Body)',
        'DM Sans'            => 'DM Sans',
        'Inter'              => 'Inter',
        'Plus Jakarta Sans'  => 'Plus Jakarta Sans',
        'Outfit'             => 'Outfit',
        'Urbanist'           => 'Urbanist',
        'Manrope'            => 'Manrope',
        'Figtree'            => 'Figtree',
        'Geist'              => 'Geist',
        'Space Grotesk'      => 'Space Grotesk',
        'Cabinet Grotesk'    => 'Cabinet Grotesk',
        'Clash Display'      => 'Clash Display',
        'Satoshi'            => 'Satoshi',
        'Epilogue'           => 'Epilogue',
    ];

    $wp_customize->add_setting( 'terra_blue_font_display', [
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'postMessage',
    ] );
    $wp_customize->add_control( 'terra_blue_font_display', [
        'label'   => __( 'Display / Heading Font', 'terra-blue' ),
        'section' => 'terra_blue_typography',
        'type'    => 'select',
        'choices' => $font_choices,
    ] );

    $wp_customize->add_setting( 'terra_blue_font_body', [
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'postMessage',
    ] );
    $wp_customize->add_control( 'terra_blue_font_body', [
        'label'   => __( 'Body Font', 'terra-blue' ),
        'section' => 'terra_blue_typography',
        'type'    => 'select',
        'choices' => $font_choices,
    ] );

    // ═══════════════════════════════════════════════════════════════════
    // 4. HEADER
    // ═══════════════════════════════════════════════════════════════════
    $add_section( 'terra_blue_header', __( 'Header Options', 'terra-blue' ), 20 );

    $header_settings = [
        'terra_blue_sticky_header'    => [ __( 'Sticky Header',            'terra-blue' ), true,  'checkbox' ],
        'terra_blue_transparent_header' => [ __( 'Transparent Header (homepage)', 'terra-blue' ), false, 'checkbox' ],
        'terra_blue_header_cta_text'  => [ __( 'Header CTA Button Text',   'terra-blue' ), '',    'text' ],
        'terra_blue_header_cta_url'   => [ __( 'Header CTA Button URL',    'terra-blue' ), '#',   'url' ],
        'terra_blue_header_search'    => [ __( 'Show Search Icon',         'terra-blue' ), true,  'checkbox' ],
        'terra_blue_header_style'     => [ __( 'Header Layout Style',      'terra-blue' ), 'default', 'select' ],
    ];

    foreach ( $header_settings as $id => $data ) {
        $wp_customize->add_setting( $id, [
            'default'           => $data[1],
            'sanitize_callback' => $data[2] === 'checkbox' ? 'terra_blue_sanitize_checkbox' : 'sanitize_text_field',
            'transport'         => 'postMessage',
        ] );
        $ctrl = [
            'label'   => $data[0],
            'section' => 'terra_blue_header',
            'type'    => $data[2],
        ];
        if ( $id === 'terra_blue_header_style' ) {
            $ctrl['choices'] = [
                'default'  => __( 'Default (Logo Left)',  'terra-blue' ),
                'centered' => __( 'Centered',             'terra-blue' ),
                'minimal'  => __( 'Minimal',              'terra-blue' ),
            ];
        }
        $wp_customize->add_control( $id, $ctrl );
    }

    // ═══════════════════════════════════════════════════════════════════
    // 5. HERO / HOMEPAGE
    // ═══════════════════════════════════════════════════════════════════
    $add_section( 'terra_blue_hero', __( 'Hero / Homepage', 'terra-blue' ), 25 );

    $hero_controls = [
        'terra_blue_hero_badge'        => [ __( 'Hero Badge Text',      'terra-blue' ), 'Welcome',    'text'     ],
        'terra_blue_hero_title'        => [ __( 'Hero Title',           'terra-blue' ), get_bloginfo('name'), 'text' ],
        'terra_blue_hero_subtitle'     => [ __( 'Hero Subtitle / Gradient Text', 'terra-blue' ), '', 'text'     ],
        'terra_blue_hero_description'  => [ __( 'Hero Description',     'terra-blue' ), get_bloginfo('description'), 'textarea' ],
        'terra_blue_hero_cta_1_text'   => [ __( 'CTA 1 Text',           'terra-blue' ), 'Get Started',  'text'   ],
        'terra_blue_hero_cta_1_url'    => [ __( 'CTA 1 URL',            'terra-blue' ), '#',            'url'    ],
        'terra_blue_hero_cta_2_text'   => [ __( 'CTA 2 Text',           'terra-blue' ), 'Learn More',   'text'   ],
        'terra_blue_hero_cta_2_url'    => [ __( 'CTA 2 URL',            'terra-blue' ), '#',            'url'    ],
        'terra_blue_hero_style'        => [ __( 'Hero Style',           'terra-blue' ), 'particles',    'select' ],
        'terra_blue_hero_overlay'      => [ __( 'Show Overlay Effect',  'terra-blue' ), true,           'checkbox' ],
        'terra_blue_stat_1_number'     => [ __( 'Stat 1 Number',        'terra-blue' ), '10K+',         'text'   ],
        'terra_blue_stat_1_label'      => [ __( 'Stat 1 Label',         'terra-blue' ), 'Users',        'text'   ],
        'terra_blue_stat_2_number'     => [ __( 'Stat 2 Number',        'terra-blue' ), '500+',         'text'   ],
        'terra_blue_stat_2_label'      => [ __( 'Stat 2 Label',         'terra-blue' ), 'Projects',     'text'   ],
        'terra_blue_stat_3_number'     => [ __( 'Stat 3 Number',        'terra-blue' ), '99%',          'text'   ],
        'terra_blue_stat_3_label'      => [ __( 'Stat 3 Label',         'terra-blue' ), 'Satisfaction', 'text'   ],
        'terra_blue_hero_align'        => [ __( 'Hero Text Alignment',  'terra-blue' ), 'center',       'select' ],
        'terra_blue_carousel_title'    => [ __( 'Carousel Title',       'terra-blue' ), 'From the Blog',   'text' ],
        'terra_blue_carousel_subtitle' => [ __( 'Carousel Subtitle',    'terra-blue' ), 'Curated insights, deep dives, and fresh perspectives on what matters most.', 'textarea' ],
        'terra_blue_carousel_align'    => [ __( 'Carousel Text Alignment', 'terra-blue' ), 'center', 'select' ],
    ];

    foreach ( $hero_controls as $id => $data ) {
        $wp_customize->add_setting( $id, [
            'default'           => $data[1],
            'sanitize_callback' => $data[2] === 'checkbox' ? 'terra_blue_sanitize_checkbox' : 'sanitize_text_field',
            'transport'         => 'postMessage',
        ] );
        $ctrl = [
            'label'   => $data[0],
            'section' => 'terra_blue_hero',
            'type'    => $data[2],
        ];
        if ( $id === 'terra_blue_hero_style' ) {
            $ctrl['choices'] = [
                'particles'   => __( 'Particles',    'terra-blue' ),
                'gradient'    => __( 'Gradient',     'terra-blue' ),
                'mesh'        => __( 'Gradient Mesh','terra-blue' ),
                'video'       => __( 'Video',        'terra-blue' ),
                'image'       => __( 'Image',        'terra-blue' ),
                'minimal'     => __( 'Minimal',      'terra-blue' ),
            ];
        }
        if ( $id === 'terra_blue_hero_align' ) {
            $ctrl['choices'] = [
                'left'   => __( 'Left',   'terra-blue' ),
                'center' => __( 'Center', 'terra-blue' ),
                'right'  => __( 'Right',  'terra-blue' ),
            ];
        }
        if ( $id === 'terra_blue_carousel_align' ) {
            $ctrl['choices'] = [
                'left'   => __( 'Left',   'terra-blue' ),
                'center' => __( 'Center', 'terra-blue' ),
                'right'  => __( 'Right',  'terra-blue' ),
            ];
        }
        $wp_customize->add_control( $id, $ctrl );
    }

    // ═══════════════════════════════════════════════════════════════════
    // 6. BLOG SETTINGS
    // ═══════════════════════════════════════════════════════════════════
    $add_section( 'terra_blue_blog', __( 'Blog Settings', 'terra-blue' ), 30 );

    $blog_controls = [
        'terra_blue_blog_layout'      => [ __( 'Blog Layout',             'terra-blue' ), 'grid',    'select' ],
        'terra_blue_blog_columns'     => [ __( 'Grid Columns',            'terra-blue' ), '3',       'select' ],
        'terra_blue_show_featured'    => [ __( 'Show Featured Post',      'terra-blue' ), true,      'checkbox' ],
        'terra_blue_show_excerpt'     => [ __( 'Show Excerpt',            'terra-blue' ), true,      'checkbox' ],
        'terra_blue_show_read_time'   => [ __( 'Show Reading Time',       'terra-blue' ), true,      'checkbox' ],
        'terra_blue_show_author'      => [ __( 'Show Author',             'terra-blue' ), true,      'checkbox' ],
        'terra_blue_show_cat'         => [ __( 'Show Category',           'terra-blue' ), true,      'checkbox' ],
        'terra_blue_infinite_scroll'  => [ __( 'Infinite Scroll',         'terra-blue' ), false,     'checkbox' ],
        'terra_blue_excerpt_length'   => [ __( 'Excerpt Word Count',      'terra-blue' ), '25',      'number'   ],
        'terra_blue_blog_align'       => [ __( 'Blog Card Text Alignment', 'terra-blue' ), 'left',    'select'   ],
    ];

    foreach ( $blog_controls as $id => $data ) {
        $wp_customize->add_setting( $id, [
            'default'           => $data[1],
            'sanitize_callback' => $data[2] === 'checkbox' ? 'terra_blue_sanitize_checkbox' : 'sanitize_text_field',
            'transport'         => 'postMessage',
        ] );
        $ctrl = [
            'label'   => $data[0],
            'section' => 'terra_blue_blog',
            'type'    => $data[2],
        ];
        if ( $id === 'terra_blue_blog_layout' ) {
            $ctrl['choices'] = [
                'grid'     => __( 'Grid',     'terra-blue' ),
                'list'     => __( 'List',     'terra-blue' ),
                'masonry'  => __( 'Masonry',  'terra-blue' ),
                'magazine' => __( 'Magazine', 'terra-blue' ),
            ];
        }
        if ( $id === 'terra_blue_blog_columns' ) {
            $ctrl['choices'] = [ '2' => '2', '3' => '3', '4' => '4' ];
        }
        if ( $id === 'terra_blue_blog_align' ) {
            $ctrl['choices'] = [
                'left'   => __( 'Left',   'terra-blue' ),
                'center' => __( 'Center', 'terra-blue' ),
                'right'  => __( 'Right',  'terra-blue' ),
            ];
        }
        $wp_customize->add_control( $id, $ctrl );
    }

    // ═══════════════════════════════════════════════════════════════════
    // 7. SINGLE POST
    // ═══════════════════════════════════════════════════════════════════
    $add_section( 'terra_blue_single', __( 'Single Post', 'terra-blue' ), 35 );

    $single_controls = [
        'terra_blue_single_sidebar'       => [ __( 'Sidebar Position',       'terra-blue' ), 'right',  'select' ],
        'terra_blue_show_progress_bar'    => [ __( 'Reading Progress Bar',    'terra-blue' ), true,     'checkbox' ],
        'terra_blue_show_toc'             => [ __( 'Table of Contents',       'terra-blue' ), false,    'checkbox' ],
        'terra_blue_show_author_box'      => [ __( 'Author Box',              'terra-blue' ), true,     'checkbox' ],
        'terra_blue_show_related_posts'   => [ __( 'Related Posts',           'terra-blue' ), true,     'checkbox' ],
        'terra_blue_show_social_share'    => [ __( 'Social Share Buttons',    'terra-blue' ), true,     'checkbox' ],
        'terra_blue_show_post_nav'        => [ __( 'Previous/Next Post',      'terra-blue' ), true,     'checkbox' ],
        'terra_blue_post_hero_style'      => [ __( 'Post Hero Style',         'terra-blue' ), 'default','select'  ],
        'terra_blue_single_align'         => [ __( 'Post Content Text Alignment', 'terra-blue' ), 'left', 'select' ],
    ];

    foreach ( $single_controls as $id => $data ) {
        $wp_customize->add_setting( $id, [
            'default'           => $data[1],
            'sanitize_callback' => $data[2] === 'checkbox' ? 'terra_blue_sanitize_checkbox' : 'sanitize_text_field',
            'transport'         => 'postMessage',
        ] );
        $ctrl = [
            'label'   => $data[0],
            'section' => 'terra_blue_single',
            'type'    => $data[2],
        ];
        if ( $id === 'terra_blue_single_sidebar' ) {
            $ctrl['choices'] = [
                'right' => __( 'Right', 'terra-blue' ),
                'left'  => __( 'Left',  'terra-blue' ),
                'none'  => __( 'None',  'terra-blue' ),
            ];
        }
        if ( $id === 'terra_blue_single_align' ) {
            $ctrl['choices'] = [
                'left'   => __( 'Left',   'terra-blue' ),
                'center' => __( 'Center', 'terra-blue' ),
                'right'  => __( 'Right',  'terra-blue' ),
            ];
        }
        $wp_customize->add_control( $id, $ctrl );
    }

    // ═══════════════════════════════════════════════════════════════════
    // 8. FOOTER
    // ═══════════════════════════════════════════════════════════════════
    $add_section( 'terra_blue_footer', __( 'Footer Settings', 'terra-blue' ), 40 );

    $footer_controls = [
        'terra_blue_footer_show_columns' => [ __( 'Show Footer Columns',    'terra-blue' ), true,  'checkbox' ],
        'terra_blue_footer_col_1_title'  => [ __( 'Column 1 Title', 'terra-blue' ), __( 'Company',   'terra-blue' ), 'text' ],
        'terra_blue_footer_col_2_title'  => [ __( 'Column 2 Title', 'terra-blue' ), __( 'Product',   'terra-blue' ), 'text' ],
        'terra_blue_footer_col_3_title'  => [ __( 'Column 3 Title', 'terra-blue' ), __( 'Resources', 'terra-blue' ), 'text' ],
        'terra_blue_footer_newsletter'   => [ __( 'Show Newsletter Signup', 'terra-blue' ), false,  'checkbox' ],
        'terra_blue_footer_dark'         => [ __( 'Dark Footer',   'terra-blue' ), true,  'checkbox' ],
        'terra_blue_footer_align'        => [ __( 'Footer Text Alignment',  'terra-blue' ), 'left', 'select' ],
        'terra_blue_twitter_url'   => [ __( 'Twitter/X URL',   'terra-blue' ), '', 'url' ],
        'terra_blue_github_url'    => [ __( 'GitHub URL',      'terra-blue' ), '', 'url' ],
        'terra_blue_linkedin_url'  => [ __( 'LinkedIn URL',    'terra-blue' ), '', 'url' ],
        'terra_blue_instagram_url' => [ __( 'Instagram URL',   'terra-blue' ), '', 'url' ],
        'terra_blue_youtube_url'   => [ __( 'YouTube URL',     'terra-blue' ), '', 'url' ],
    ];

    foreach ( $footer_controls as $id => $data ) {
        $wp_customize->add_setting( $id, [
            'default'           => $data[1],
            'sanitize_callback' => $data[2] === 'checkbox' ? 'terra_blue_sanitize_checkbox' : ( $data[2] === 'url' ? 'esc_url_raw' : 'sanitize_text_field' ),
            'transport'         => 'postMessage',
        ] );
        $ctrl = [
            'label'   => $data[0],
            'section' => 'terra_blue_footer',
            'type'    => $data[2],
        ];
        if ( $id === 'terra_blue_footer_align' ) {
            $ctrl['choices'] = [
                'left'   => __( 'Left',   'terra-blue' ),
                'center' => __( 'Center', 'terra-blue' ),
                'right'  => __( 'Right',  'terra-blue' ),
            ];
        }
        $wp_customize->add_control( $id, $ctrl );
    }

    // ═══════════════════════════════════════════════════════════════════
    // 8b. FOOTER QUICK LINKS
    // ═══════════════════════════════════════════════════════════════════
    $add_section( 'terra_blue_footer_links', __( 'Footer Quick Links', 'terra-blue' ), 41 );

    // Master toggle
    $wp_customize->add_setting( 'terra_blue_footer_quicklinks_show', [
        'default'           => false,
        'sanitize_callback' => 'terra_blue_sanitize_checkbox',
        'transport'         => 'postMessage',
    ] );
    $wp_customize->add_control( 'terra_blue_footer_quicklinks_show', [
        'label'       => __( 'Show Footer Quick Links Bar', 'terra-blue' ),
        'description' => __( 'Displays a row of quick links above the copyright bar. Leave a link text empty to hide it.', 'terra-blue' ),
        'section'     => 'terra_blue_footer_links',
        'type'        => 'checkbox',
    ] );

    // 9 quick links: 6 preset + 3 blank
    $quicklinks = [
        1 => 'Accessibility',
        2 => 'Terms of Service',
        3 => 'Privacy',
        4 => 'Help',
        5 => 'News',
        6 => 'Sitemap',
        7 => '',
        8 => '',
        9 => '',
    ];

    foreach ( $quicklinks as $num => $default_text ) {
        $label = $default_text ? $default_text : sprintf( __( 'Custom Link %d', 'terra-blue' ), $num - 6 );

        $wp_customize->add_setting( "terra_blue_qlink_{$num}_text", [
            'default'           => $default_text,
            'sanitize_callback' => 'sanitize_text_field',
            'transport'         => 'postMessage',
        ] );
        $wp_customize->add_control( "terra_blue_qlink_{$num}_text", [
            'label'   => sprintf( __( 'Link %d — %s', 'terra-blue' ), $num, $label ),
            'section' => 'terra_blue_footer_links',
            'type'    => 'text',
        ] );

        $wp_customize->add_setting( "terra_blue_qlink_{$num}_url", [
            'default'           => '#',
            'sanitize_callback' => 'esc_url_raw',
            'transport'         => 'postMessage',
        ] );
        $wp_customize->add_control( "terra_blue_qlink_{$num}_url", [
            'label'   => sprintf( __( 'Link %d URL', 'terra-blue' ), $num ),
            'section' => 'terra_blue_footer_links',
            'type'    => 'url',
        ] );
    }

    // ═══════════════════════════════════════════════════════════════════
    // 9. PERFORMANCE & SCRIPTS
    // ═══════════════════════════════════════════════════════════════════
    $add_section( 'terra_blue_performance', __( 'Performance & Scripts', 'terra-blue' ), 45 );

    $perf_controls = [
        'terra_blue_smooth_scroll'    => [ __( 'Smooth Scroll',        'terra-blue' ), true,  'checkbox' ],
        'terra_blue_animations'       => [ __( 'Page Animations',      'terra-blue' ), true,  'checkbox' ],
        'terra_blue_lazy_load'        => [ __( 'Lazy Load Images',     'terra-blue' ), true,  'checkbox' ],
        'terra_blue_disable_emojis'   => [ __( 'Disable Emoji Scripts','terra-blue' ), true,  'checkbox' ],
        'terra_blue_head_scripts'     => [ __( 'Head Scripts (before </head>)',   'terra-blue' ), '', 'textarea' ],
        'terra_blue_footer_scripts'   => [ __( 'Footer Scripts (before </body>)', 'terra-blue' ), '', 'textarea' ],
    ];

    foreach ( $perf_controls as $id => $data ) {
        $wp_customize->add_setting( $id, [
            'default'           => $data[1],
            'sanitize_callback' => $data[2] === 'checkbox' ? 'terra_blue_sanitize_checkbox' : 'wp_kses_post',
        ] );
        $wp_customize->add_control( $id, [
            'label'   => $data[0],
            'section' => 'terra_blue_performance',
            'type'    => $data[2],
        ] );
    }

    // ═══════════════════════════════════════════════════════════════════
    // 10. COOKIE NOTICE & GDPR
    // ═══════════════════════════════════════════════════════════════════
    $add_section( 'terra_blue_gdpr', __( 'Cookie Notice / GDPR', 'terra-blue' ), 50 );

    $wp_customize->add_setting( 'terra_blue_cookie_notice', [
        'default'           => false,
        'sanitize_callback' => 'terra_blue_sanitize_checkbox',
    ] );
    $wp_customize->add_control( 'terra_blue_cookie_notice', [
        'label'   => __( 'Enable Cookie Notice', 'terra-blue' ),
        'section' => 'terra_blue_gdpr',
        'type'    => 'checkbox',
    ] );

    $wp_customize->add_setting( 'terra_blue_cookie_text', [
        'default'           => __( 'We use cookies to enhance your experience. By continuing to visit this site you agree to our use of cookies.', 'terra-blue' ),
        'sanitize_callback' => 'wp_kses_post',
    ] );
    $wp_customize->add_control( 'terra_blue_cookie_text', [
        'label'   => __( 'Cookie Notice Text', 'terra-blue' ),
        'section' => 'terra_blue_gdpr',
        'type'    => 'textarea',
    ] );

    // ═══════════════════════════════════════════════════════════════════
    // 11. CUSTOM CSS / JS INJECTION (Advanced)
    // ═══════════════════════════════════════════════════════════════════
    // Note: Core provides "Additional CSS" section natively.
    // We augment with Custom JS.
    $add_section( 'terra_blue_custom_code', __( 'Custom Code (Advanced)', 'terra-blue' ), 55 );

    $wp_customize->add_setting( 'terra_blue_custom_js', [
        'default'           => '',
        'sanitize_callback' => 'wp_kses_post',
    ] );
    $wp_customize->add_control( 'terra_blue_custom_js', [
        'label'       => __( 'Custom JavaScript', 'terra-blue' ),
        'description' => __( 'Injected before </body>. Do not include &lt;script&gt; tags.', 'terra-blue' ),
        'section'     => 'terra_blue_custom_code',
        'type'        => 'textarea',
        'settings'    => 'terra_blue_custom_js',
    ] );

    // ─── Selective Refresh Partials ────────────────────────────────────
    if ( isset( $wp_customize->selective_refresh ) ) {
        $wp_customize->selective_refresh->add_partial( 'blogname', [
            'selector'        => '.nx-logo-text',
            'render_callback' => function() { return get_bloginfo( 'name', 'display' ); },
        ] );
        $wp_customize->selective_refresh->add_partial( 'blogdescription', [
            'selector'        => '.nx-footer-brand p',
            'render_callback' => function() { return get_bloginfo( 'description', 'display' ); },
        ] );
        $wp_customize->selective_refresh->add_partial( 'terra_blue_hero_title', [
            'selector'        => '.nx-hero-title',
            'render_callback' => function() { return get_theme_mod( 'terra_blue_hero_title', get_bloginfo( 'name' ) ); },
        ] );
    }

    // ═══════════════════════════════════════════════════════════════════
    // WooCommerce Settings (only registered when WooCommerce is active)
    // ═══════════════════════════════════════════════════════════════════
    if ( class_exists( 'WooCommerce' ) ) {
        $add_section( 'terra_blue_woocommerce', __( 'WooCommerce', 'terra-blue' ), 70 );

        $wc_controls = [
            'terra_blue_wc_columns'  => [ __( 'Products Per Row',  'terra-blue' ), 3,  'number' ],
            'terra_blue_wc_per_page' => [ __( 'Products Per Page', 'terra-blue' ), 12, 'number' ],
        ];

        foreach ( $wc_controls as $id => $data ) {
            $wp_customize->add_setting( $id, [
                'default'           => $data[1],
                'sanitize_callback' => 'absint',
                'transport'         => 'refresh',
            ] );
            $wp_customize->add_control( $id, [
                'label'   => $data[0],
                'section' => 'terra_blue_woocommerce',
                'type'    => $data[2],
            ] );
        }
    }
}
add_action( 'customize_register', 'terra_blue_customizer_register' );

// ─── Sanitization Callbacks ───────────────────────────────────────────────────
function terra_blue_sanitize_checkbox( $val ) { return (bool) $val; }
function terra_blue_sanitize_text( $val )     { return sanitize_text_field( $val ); }
function terra_blue_sanitize_url( $val )      { return esc_url_raw( $val ); }
function terra_blue_sanitize_number( $val )   { return absint( $val ); }
function terra_blue_sanitize_select( $val, $setting ) {
    $choices = $setting->manager->get_control( $setting->id )->choices ?? [];
    return array_key_exists( $val, $choices ) ? $val : $setting->default;
}
function terra_blue_sanitize_textarea( $val ) { return wp_kses_post( $val ); }

// ─── Live Preview (postMessage) ───────────────────────────────────────────────
function terra_blue_customize_preview_js() {
    wp_enqueue_script(
        'terra-blue-customizer-preview',
        TERRA_BLUE_URI . '/js/customizer-preview.js',
        [ 'customize-preview' ],
        TERRA_BLUE_VERSION,
        true
    );
}
add_action( 'customize_preview_init', 'terra_blue_customize_preview_js' );

// ─── Custom Head / Footer Scripts from Customizer ─────────────────────────────
function terra_blue_custom_head_scripts() {
    $scripts = get_theme_mod( 'terra_blue_head_scripts', '' );
    if ( $scripts ) {
        echo "\n<!-- Terra-Blue Custom Head Scripts -->\n";
        echo $scripts . "\n"; // phpcs:ignore
    }
}
add_action( 'wp_head', 'terra_blue_custom_head_scripts', 99 );

function terra_blue_custom_footer_scripts() {
    $scripts = get_theme_mod( 'terra_blue_footer_scripts', '' );
    if ( $scripts ) {
        echo "\n<!-- Terra-Blue Custom Footer Scripts -->\n";
        echo $scripts . "\n"; // phpcs:ignore
    }
    $custom_js = get_theme_mod( 'terra_blue_custom_js', '' );
    if ( $custom_js ) {
        echo '<script id="terra-blue-custom-js">' . "\n" . $custom_js . "\n" . '</script>' . "\n"; // phpcs:ignore
    }
}
add_action( 'wp_footer', 'terra_blue_custom_footer_scripts', 99 );
