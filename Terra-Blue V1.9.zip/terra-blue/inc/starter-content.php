<?php
/**
 * Terra-Blue — Starter Content
 *
 * Populates the Customizer live preview with realistic placeholder content
 * so the theme never looks blank when users first activate it.
 *
 * WordPress only uses this data inside the Customizer preview. Nothing is
 * written to the database until the user explicitly clicks "Publish".
 *
 * @package Terra-Blue
 * @since   1.4.0
 * @see     https://developer.wordpress.org/themes/functionality/starter-content/
 */

defined( 'ABSPATH' ) || exit;

/**
 * Return the starter content array.
 *
 * @return array
 */
function terra_blue_get_starter_content() {

    return [

        // ─── Theme Mods (Customizer defaults) ────────────────────────────
        'theme_mods' => [
            'terra_blue_show_excerpt'      => true,
            'terra_blue_show_author'       => true,
            'terra_blue_show_cat'          => true,
            'terra_blue_show_read_time'    => true,
            'terra_blue_header_cta_text'   => __( 'Get Started', 'terra-blue' ),
            'terra_blue_header_cta_url'    => '#pricing',
            'terra_blue_cookie_notice'     => false,
            'terra_blue_footer_newsletter' => true,
            'terra_blue_footer_col_1_title' => __( 'Company', 'terra-blue' ),
            'terra_blue_footer_col_2_title' => __( 'Product', 'terra-blue' ),
            'terra_blue_footer_col_3_title' => __( 'Resources', 'terra-blue' ),
        ],

        // ─── Attachments (placeholder images) ────────────────────────────
        'attachments' => [
            'terra-blue-hero-image' => [
                'post_title' => __( 'Hero Image', 'terra-blue' ),
                'file'       => 'assets/starter/hero.jpg',
            ],
            'terra-blue-post-image-1' => [
                'post_title' => __( 'Post Image 1', 'terra-blue' ),
                'file'       => 'assets/starter/post-1.jpg',
            ],
            'terra-blue-post-image-2' => [
                'post_title' => __( 'Post Image 2', 'terra-blue' ),
                'file'       => 'assets/starter/post-2.jpg',
            ],
            'terra-blue-post-image-3' => [
                'post_title' => __( 'Post Image 3', 'terra-blue' ),
                'file'       => 'assets/starter/post-3.jpg',
            ],
        ],

        // ─── Posts ───────────────────────────────────────────────────────
        'posts' => [

            // --- Pages ---

            'home' => [
                'post_type'    => 'page',
                'post_title'   => __( 'Home', 'terra-blue' ),
                'post_content' => '',
            ],

            'about' => [
                'post_type'    => 'page',
                'post_title'   => __( 'About', 'terra-blue' ),
                'post_content' => sprintf(
                    '<!-- wp:heading {"level":1} -->
<h1>%1$s</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>%2$s</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>%3$s</p>
<!-- /wp:paragraph -->

<!-- wp:separator -->
<hr class="wp-block-separator"/>
<!-- /wp:separator -->

<!-- wp:heading -->
<h2>%4$s</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>%5$s</p>
<!-- /wp:paragraph -->',
                    __( 'About Us',                                                  'terra-blue' ),
                    __( 'We are a small team of designers and developers passionate about crafting tools that help creators publish beautiful, fast, and accessible websites.', 'terra-blue' ),
                    __( 'Terra-Blue started as a side project in 2024 and has since grown into a fully-featured WordPress theme used by developers, freelancers, and agencies worldwide.', 'terra-blue' ),
                    __( 'Our Mission',                                               'terra-blue' ),
                    __( 'We believe the web should be fast for everyone. Every decision we make — from the CSS architecture to the JavaScript bundle — is guided by performance, accessibility, and developer experience.', 'terra-blue' )
                ),
            ],

            'blog' => [
                'post_type'  => 'page',
                'post_title' => __( 'Blog', 'terra-blue' ),
            ],

            'contact' => [
                'post_type'    => 'page',
                'post_title'   => __( 'Contact', 'terra-blue' ),
                'template'     => 'contact.php',
                'post_content' => sprintf(
                    '<!-- wp:heading {"level":1} -->
<h1>%1$s</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>%2$s</p>
<!-- /wp:paragraph -->',
                    __( 'Get in Touch',                                              'terra-blue' ),
                    __( 'Have a question, a project idea, or just want to say hello? Drop us a message and we will get back to you within 24 hours.', 'terra-blue' )
                ),
            ],

            // --- Blog Posts ---

            'starter-post-1' => [
                'post_type'    => 'post',
                'post_title'   => __( 'Getting Started with Terra-Blue: A Quick Setup Guide', 'terra-blue' ),
                'post_excerpt' => __( 'Everything you need to know to install, activate, and customize Terra-Blue for your next project.', 'terra-blue' ),
                'post_content' => sprintf(
                    '<!-- wp:paragraph -->
<p>%1$s</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2>%2$s</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>%3$s</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2>%4$s</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>%5$s</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2>%6$s</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>%7$s</p>
<!-- /wp:paragraph -->',
                    __( 'Welcome to Terra-Blue! This guide walks you through the essential steps to get your new theme up and running in minutes.', 'terra-blue' ),
                    __( 'Installation',        'terra-blue' ),
                    __( 'Upload the theme ZIP file via Appearance → Themes → Add New → Upload Theme. Once activated, head to the Customizer to start configuring your site identity, colors, menus, and homepage layout.', 'terra-blue' ),
                    __( 'Setting Up Menus',    'terra-blue' ),
                    __( 'Navigate to Appearance → Menus and create your Primary Navigation. Terra-Blue supports dropdown submenus, mega-menu columns, and a dedicated social links menu in the footer.', 'terra-blue' ),
                    __( 'Customizing the Homepage', 'terra-blue' ),
                    __( 'Set your homepage display to a static page under Settings → Reading. Use the block editor to build hero sections, feature grids, testimonials, and CTAs using Terra-Blue block patterns.', 'terra-blue' )
                ),
                'thumbnail'    => '{{terra-blue-post-image-1}}',
            ],

            'starter-post-2' => [
                'post_type'    => 'post',
                'post_title'   => __( 'Designing for Dark Mode: Tips and Best Practices', 'terra-blue' ),
                'post_excerpt' => __( 'Dark interfaces reduce eye strain and save battery. Here is how to design them well.', 'terra-blue' ),
                'post_content' => sprintf(
                    '<!-- wp:paragraph -->
<p>%1$s</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2>%2$s</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>%3$s</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2>%4$s</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>%5$s</p>
<!-- /wp:paragraph -->',
                    __( 'Dark mode has gone from a niche preference to an expected feature. With Terra-Blue, dark mode is not an afterthought — it is the foundation.', 'terra-blue' ),
                    __( 'Contrast and Readability',  'terra-blue' ),
                    __( 'Avoid pure black backgrounds (#000). Terra-Blue uses #080C10 as the base — dark enough to feel immersive but soft enough to reduce halation on OLED screens. Text sits at #E6EDF3 for a comfortable 12.5:1 contrast ratio.', 'terra-blue' ),
                    __( 'Color on Dark Surfaces',    'terra-blue' ),
                    __( 'Saturated colors can vibrate against dark backgrounds. Terra-Blue desaturates accent hues by 10-15% in dark mode and uses translucent tints for badges, tags, and hover states instead of solid fills.', 'terra-blue' )
                ),
                'thumbnail'    => '{{terra-blue-post-image-2}}',
            ],

            'starter-post-3' => [
                'post_type'    => 'post',
                'post_title'   => __( 'Optimizing Core Web Vitals in WordPress Themes', 'terra-blue' ),
                'post_excerpt' => __( 'Practical strategies to achieve high Lighthouse scores without sacrificing design quality.', 'terra-blue' ),
                'post_content' => sprintf(
                    '<!-- wp:paragraph -->
<p>%1$s</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2>%2$s</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>%3$s</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2>%4$s</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>%5$s</p>
<!-- /wp:paragraph -->',
                    __( 'Google uses Core Web Vitals as a ranking signal. Here is how Terra-Blue is engineered to score 90+ on Lighthouse from day one.', 'terra-blue' ),
                    __( 'Largest Contentful Paint (LCP)', 'terra-blue' ),
                    __( 'Terra-Blue defers non-critical CSS, lazy-loads below-the-fold images, and uses responsive srcset attributes on all thumbnails. Fonts load via font-display: swap to prevent invisible text.', 'terra-blue' ),
                    __( 'Cumulative Layout Shift (CLS)',   'terra-blue' ),
                    __( 'Every image and embed has explicit aspect-ratio set via CSS. The sticky header uses transform animations instead of layout-triggering properties. No content jumps, ever.', 'terra-blue' )
                ),
                'thumbnail'    => '{{terra-blue-post-image-3}}',
            ],

            'starter-post-4' => [
                'post_type'    => 'post',
                'post_title'   => __( 'Block Patterns: Build Pages Without Writing Code', 'terra-blue' ),
                'post_excerpt' => __( 'Terra-Blue ships with pre-designed block patterns for heroes, features, pricing, and more.', 'terra-blue' ),
                'post_content' => sprintf(
                    '<!-- wp:paragraph -->
<p>%1$s</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>%2$s</p>
<!-- /wp:paragraph -->',
                    __( 'Block patterns are pre-built layouts you can insert with a single click in the block editor. Terra-Blue includes patterns for hero sections, feature grids, pricing tables, testimonial sliders, newsletter CTAs, and team member cards.', 'terra-blue' ),
                    __( 'Each pattern is fully customizable — change the text, swap the images, adjust the colors. They are designed to work together so you can compose full pages in minutes without touching a line of code.', 'terra-blue' )
                ),
            ],

            'starter-post-5' => [
                'post_type'    => 'post',
                'post_title'   => __( 'Accessibility Checklist for WordPress Theme Developers', 'terra-blue' ),
                'post_excerpt' => __( 'A comprehensive guide to building themes that meet WCAG 2.1 AA standards.', 'terra-blue' ),
                'post_content' => sprintf(
                    '<!-- wp:paragraph -->
<p>%1$s</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>%2$s</p>
<!-- /wp:paragraph -->',
                    __( 'Accessibility is not a feature — it is a requirement. Over one billion people worldwide live with some form of disability. Every theme we ship should work for every user.', 'terra-blue' ),
                    __( 'Terra-Blue meets WCAG 2.1 AA with proper ARIA landmarks on every template, visible focus indicators on all interactive elements, skip-to-content links, semantic heading hierarchy, sufficient color contrast ratios, and full keyboard navigation support throughout.', 'terra-blue' )
                ),
            ],

            'starter-post-6' => [
                'post_type'    => 'post',
                'post_title'   => __( 'Fluid Typography with CSS clamp(): A Practical Guide', 'terra-blue' ),
                'post_excerpt' => __( 'Stop using breakpoints for font sizes. Let CSS do the scaling for you.', 'terra-blue' ),
                'post_content' => sprintf(
                    '<!-- wp:paragraph -->
<p>%1$s</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>%2$s</p>
<!-- /wp:paragraph -->',
                    __( 'The clamp() function lets you define a minimum, preferred, and maximum font size in a single declaration. Terra-Blue uses it across every text size token for smooth, proportional scaling from mobile to ultrawide.', 'terra-blue' ),
                    __( 'The result is typography that feels intentionally designed at every viewport width — no jarring jumps between breakpoints, no text that is too large on mobile or too small on desktop.', 'terra-blue' )
                ),
            ],
        ],

        // ─── Navigation Menus ────────────────────────────────────────────
        'nav_menus' => [

            'primary' => [
                'name'  => __( 'Primary Navigation', 'terra-blue' ),
                'items' => [
                    'link_home',
                    'page_about'   => [ 'type' => 'post_type', 'object' => 'page', 'object_id' => '{{about}}' ],
                    'page_blog'    => [ 'type' => 'post_type', 'object' => 'page', 'object_id' => '{{blog}}' ],
                    'page_contact' => [ 'type' => 'post_type', 'object' => 'page', 'object_id' => '{{contact}}' ],
                ],
            ],

            'footer' => [
                'name'  => __( 'Footer Navigation', 'terra-blue' ),
                'items' => [
                    'link_home',
                    'page_about'   => [ 'type' => 'post_type', 'object' => 'page', 'object_id' => '{{about}}' ],
                    'page_blog'    => [ 'type' => 'post_type', 'object' => 'page', 'object_id' => '{{blog}}' ],
                    'page_contact' => [ 'type' => 'post_type', 'object' => 'page', 'object_id' => '{{contact}}' ],
                ],
            ],

            'social' => [
                'name'  => __( 'Social Links', 'terra-blue' ),
                'items' => [
                    'github'   => [ 'title' => 'GitHub',   'url' => 'https://github.com/' ],
                    'twitter'  => [ 'title' => 'Twitter',  'url' => 'https://twitter.com/' ],
                    'linkedin' => [ 'title' => 'LinkedIn', 'url' => 'https://linkedin.com/' ],
                ],
            ],
        ],

        // ─── Core Options ────────────────────────────────────────────────
        'options' => [
            'show_on_front'  => 'posts',
            'blogdescription' => __( 'A modern dark-first WordPress theme', 'terra-blue' ),
        ],

        // ─── Widgets ─────────────────────────────────────────────────────
        'widgets' => [

            'sidebar-1' => [
                'search',
                'text_about' => [
                    'text' => [
                        'title' => __( 'About This Blog', 'terra-blue' ),
                        'text'  => __( 'Thoughts on design, development, and building for the modern web. Powered by Terra-Blue.', 'terra-blue' ),
                    ],
                ],
                'recent-posts',
                'categories',
            ],

            'footer-1' => [
                'text_footer_about' => [
                    'text' => [
                        'title' => '',
                        'text'  => __( 'Terra-Blue is a professional WordPress theme built for developers and creatives who care about performance and design.', 'terra-blue' ),
                    ],
                ],
            ],

            'footer-2' => [
                'recent-posts',
            ],

            'footer-3' => [
                'categories',
            ],
        ],
    ];
}
