<?php
/**
 * Terra-Blue — WooCommerce Integration
 *
 * @package Terra-Blue
 */

defined( 'ABSPATH' ) || exit;

// Only run when WooCommerce is active.
if ( ! class_exists( 'WooCommerce' ) ) {
	return;
}

/**
 * Remove default WooCommerce wrappers and use theme wrappers.
 */
remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper',     10 );
remove_action( 'woocommerce_after_main_content',  'woocommerce_output_content_wrapper_end', 10 );

function terra_blue_wc_wrapper_start() {
	echo '<div class="nx-container-wide nx-wc-wrapper">';
}
function terra_blue_wc_wrapper_end() {
	echo '</div>';
}
add_action( 'woocommerce_before_main_content', 'terra_blue_wc_wrapper_start', 10 );
add_action( 'woocommerce_after_main_content',  'terra_blue_wc_wrapper_end',   10 );

/**
 * Breadcrumb: use theme breadcrumbs on WC pages if desired.
 */
add_action( 'woocommerce_before_main_content', function() {
	if ( function_exists( 'terra_blue_breadcrumbs' ) ) {
		terra_blue_breadcrumbs();
	}
}, 5 );

/**
 * Move WC breadcrumbs off (we output our own above).
 */
remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20 );

/**
 * Sidebar on WC pages.
 */
add_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );

/**
 * Number of products per row / page.
 */
add_filter( 'loop_shop_columns',        function() { return get_theme_mod( 'terra_blue_wc_columns', 3 ); } );
add_filter( 'loop_shop_per_page',       function() { return get_theme_mod( 'terra_blue_wc_per_page', 12 ); }, 20 );

/**
 * Sale badge text.
 */
add_filter( 'woocommerce_sale_flash', function( $html ) {
	return '<span class="onsale nx-badge nx-badge-danger">' . esc_html__( 'Sale', 'terra-blue' ) . '</span>';
} );

/**
 * Add product schema JSON-LD for single products.
 */
function terra_blue_wc_product_schema() {
	if ( ! is_singular( 'product' ) ) {
		return;
	}
	global $product;
	if ( ! $product instanceof WC_Product ) {
		$product = wc_get_product( get_the_ID() );
	}
	if ( ! $product ) {
		return;
	}

	$schema = [
		'@context'    => 'https://schema.org',
		'@type'       => 'Product',
		'name'        => $product->get_name(),
		'description' => wp_strip_all_tags( $product->get_description() ),
		'url'         => get_permalink(),
		'sku'         => $product->get_sku(),
		'offers'      => [
			'@type'         => 'Offer',
			'price'         => $product->get_price(),
			'priceCurrency' => get_woocommerce_currency(),
			'availability'  => $product->is_in_stock() ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock',
			'url'           => get_permalink(),
		],
	];

	$image_url = get_the_post_thumbnail_url( null, 'full' );
	if ( $image_url ) {
		$schema['image'] = $image_url;
	}

	echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>' . "\n";
}
add_action( 'wp_head', 'terra_blue_wc_product_schema' );
