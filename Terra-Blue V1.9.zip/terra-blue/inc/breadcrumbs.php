<?php
/**
 * Terra-Blue — Breadcrumbs
 *
 * @package Terra-Blue
 */

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'terra_blue_breadcrumbs' ) ) :
/**
 * Output breadcrumb navigation.
 */
function terra_blue_breadcrumbs() {

	// Do not show on front page or if a plugin is handling it.
	if ( is_front_page() ) {
		return;
	}

	// Prefer Yoast SEO or RankMath breadcrumbs if available.
	if ( function_exists( 'yoast_breadcrumb' ) ) {
		yoast_breadcrumb( '<nav class="nx-breadcrumbs" aria-label="' . esc_attr__( 'Breadcrumbs', 'terra-blue' ) . '">', '</nav>' );
		return;
	}

	if ( function_exists( 'rank_math_the_breadcrumbs' ) ) {
		echo '<nav class="nx-breadcrumbs" aria-label="' . esc_attr__( 'Breadcrumbs', 'terra-blue' ) . '">';
		rank_math_the_breadcrumbs();
		echo '</nav>';
		return;
	}

	// Native breadcrumbs fallback.
	$separator = '<span class="nx-breadcrumb-sep" aria-hidden="true">/</span>';
	$home_text = __( 'Home', 'terra-blue' );
	$items     = [];

	// Home.
	$items[] = '<a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html( $home_text ) . '</a>';

	if ( is_singular() ) {
		// Category / taxonomy for posts.
		if ( is_singular( 'post' ) ) {
			$cats = get_the_category();
			if ( $cats ) {
				$cat     = $cats[0];
				$items[] = '<a href="' . esc_url( get_category_link( $cat->term_id ) ) . '">' . esc_html( $cat->name ) . '</a>';
			}
		}
		// Portfolio category.
		if ( is_singular( 'portfolio' ) ) {
			$terms = get_the_terms( get_the_ID(), 'portfolio_category' );
			if ( $terms && ! is_wp_error( $terms ) ) {
				$items[] = '<a href="' . esc_url( get_term_link( $terms[0] ) ) . '">' . esc_html( $terms[0]->name ) . '</a>';
			}
		}
		$items[] = '<span aria-current="page">' . get_the_title() . '</span>';

	} elseif ( is_archive() ) {
		if ( is_tax() || is_tag() || is_category() ) {
			$term    = get_queried_object();
			$items[] = '<span aria-current="page">' . esc_html( single_term_title( '', false ) ) . '</span>';
		} elseif ( is_post_type_archive() ) {
			$items[] = '<span aria-current="page">' . esc_html( post_type_archive_title( '', false ) ) . '</span>';
		} elseif ( is_author() ) {
			$items[] = '<span aria-current="page">' . esc_html( get_the_author() ) . '</span>';
		} elseif ( is_date() ) {
			$items[] = '<span aria-current="page">' . esc_html( get_the_date( 'F Y' ) ) . '</span>';
		}
	} elseif ( is_search() ) {
		/* translators: %s: search term */
		$items[] = '<span aria-current="page">' . sprintf( esc_html__( 'Search: %s', 'terra-blue' ), '<em>' . esc_html( get_search_query() ) . '</em>' ) . '</span>';
	} elseif ( is_404() ) {
		$items[] = '<span aria-current="page">' . esc_html__( '404 Not Found', 'terra-blue' ) . '</span>';
	}

	if ( count( $items ) <= 1 ) {
		return;
	}

	echo '<nav class="nx-breadcrumbs" aria-label="' . esc_attr__( 'Breadcrumbs', 'terra-blue' ) . '">';
	echo '<ol class="nx-breadcrumb-list" itemscope itemtype="https://schema.org/BreadcrumbList">';

	foreach ( $items as $index => $item ) {
		$pos = $index + 1;
		echo '<li class="nx-breadcrumb-item" itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">';
		echo '<span itemprop="name">' . wp_kses_post( $item ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<meta itemprop="position" content="' . esc_attr( $pos ) . '">';
		echo '</li>';

		if ( $index < count( $items ) - 1 ) {
			echo wp_kses_post( $separator );
		}
	}

	echo '</ol>';
	echo '</nav>';
}
endif;
