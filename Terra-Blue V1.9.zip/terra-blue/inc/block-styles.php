<?php
/**
 * Block Style Variations
 *
 * @package Terra-Blue
 */

if ( ! defined( 'ABSPATH' ) ) exit;

function terra_blue_register_block_styles() {

	// Button styles
	register_block_style( 'core/button', array(
		'name'  => 'gradient',
		'label' => esc_html__( 'Gradient', 'terra-blue' ),
	) );
	register_block_style( 'core/button', array(
		'name'  => 'ghost',
		'label' => esc_html__( 'Ghost', 'terra-blue' ),
	) );
	register_block_style( 'core/button', array(
		'name'  => 'glow',
		'label' => esc_html__( 'Glow', 'terra-blue' ),
	) );

	// Image styles
	register_block_style( 'core/image', array(
		'name'  => 'rounded',
		'label' => esc_html__( 'Rounded', 'terra-blue' ),
	) );
	register_block_style( 'core/image', array(
		'name'  => 'glow',
		'label' => esc_html__( 'Glow', 'terra-blue' ),
	) );
	register_block_style( 'core/image', array(
		'name'  => 'polaroid',
		'label' => esc_html__( 'Polaroid', 'terra-blue' ),
	) );

	// Group styles
	register_block_style( 'core/group', array(
		'name'  => 'glass',
		'label' => esc_html__( 'Glass Card', 'terra-blue' ),
	) );
	register_block_style( 'core/group', array(
		'name'  => 'gradient-border',
		'label' => esc_html__( 'Gradient Border', 'terra-blue' ),
	) );
	register_block_style( 'core/group', array(
		'name'  => 'feature-card',
		'label' => esc_html__( 'Feature Card', 'terra-blue' ),
	) );
	register_block_style( 'core/group', array(
		'name'  => 'callout-info',
		'label' => esc_html__( 'Callout Info', 'terra-blue' ),
	) );
	register_block_style( 'core/group', array(
		'name'  => 'callout-warning',
		'label' => esc_html__( 'Callout Warning', 'terra-blue' ),
	) );
	register_block_style( 'core/group', array(
		'name'  => 'callout-success',
		'label' => esc_html__( 'Callout Success', 'terra-blue' ),
	) );

	// Quote styles
	register_block_style( 'core/quote', array(
		'name'  => 'pull-quote',
		'label' => esc_html__( 'Pull Quote', 'terra-blue' ),
	) );
	register_block_style( 'core/quote', array(
		'name'  => 'accent',
		'label' => esc_html__( 'Accent Line', 'terra-blue' ),
	) );

	// Separator styles
	register_block_style( 'core/separator', array(
		'name'  => 'gradient',
		'label' => esc_html__( 'Gradient', 'terra-blue' ),
	) );
	register_block_style( 'core/separator', array(
		'name'  => 'dots',
		'label' => esc_html__( 'Dots', 'terra-blue' ),
	) );

	// List styles
	register_block_style( 'core/list', array(
		'name'  => 'check',
		'label' => esc_html__( 'Checkmarks', 'terra-blue' ),
	) );
	register_block_style( 'core/list', array(
		'name'  => 'arrow',
		'label' => esc_html__( 'Arrows', 'terra-blue' ),
	) );
	register_block_style( 'core/list', array(
		'name'  => 'none',
		'label' => esc_html__( 'No Bullets', 'terra-blue' ),
	) );

	// Heading styles
	register_block_style( 'core/heading', array(
		'name'  => 'gradient',
		'label' => esc_html__( 'Gradient', 'terra-blue' ),
	) );

	// Columns styles
	register_block_style( 'core/columns', array(
		'name'  => 'card-grid',
		'label' => esc_html__( 'Card Grid', 'terra-blue' ),
	) );
}
add_action( 'init', 'terra_blue_register_block_styles' );
