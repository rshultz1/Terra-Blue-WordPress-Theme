<?php
/**
 * Terra-Blue — Widget Areas (stub)
 * All widget registration is handled in functions.php via terra_blue_widgets_init().
 * This file is kept for compatibility with any future widget-area extensions.
 *
 * @package Terra-Blue
 */

defined( 'ABSPATH' ) || exit;
