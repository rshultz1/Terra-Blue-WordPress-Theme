<?php
/**
 * Template functions & tags
 *
 * @package Terra-Blue
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* =====================================================================
   CATEGORY PILLS
   ===================================================================== */

if ( ! function_exists( 'terra_blue_post_categories' ) ) :
function terra_blue_post_categories() {
	$cats = get_the_category();
	if ( ! $cats ) return;
	echo '<div class="nx-post-cats">';
	foreach ( $cats as $cat ) {
		printf(
			'<a href="%s" class="nx-badge nx-badge--cat">%s</a>',
			esc_url( home_url( '/' ) ),
			esc_html( $cat->name )
		);
	}
	echo '</div>';
}
endif;

/* =====================================================================
   POST META (FULL)
   ===================================================================== */

if ( ! function_exists( 'terra_blue_post_meta_full' ) ) :
function terra_blue_post_meta_full() {
	?>
	<div class="nx-post-meta">
		<div class="nx-post-meta__author">
			<?php echo get_avatar( get_the_author_meta( 'ID' ), 36, '', '', array( 'class' => 'nx-post-meta__avatar' ) ); ?>
			<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" class="nx-post-meta__author-name">
				<?php the_author(); ?>
			</a>
		</div>
		<span class="nx-post-meta__sep" aria-hidden="true">·</span>
		<time class="nx-post-meta__date" datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>">
			<?php echo esc_html( get_the_date() ); ?>
		</time>
		<span class="nx-post-meta__sep" aria-hidden="true">·</span>
		<span class="nx-post-meta__readtime">
			<?php echo esc_html( terra_blue_reading_time() ); ?>
		</span>
		<?php if ( comments_open() ) : ?>
		<span class="nx-post-meta__sep" aria-hidden="true">·</span>
		<a href="<?php the_permalink(); ?>#comments" class="nx-post-meta__comments">
			<?php
			printf(
				esc_html( _n( '%s comment', '%s comments', get_comments_number(), 'terra-blue' ) ),
				number_format_i18n( get_comments_number() )
			);
			?>
		</a>
		<?php endif; ?>
	</div>
	<?php
}
endif;

/* =====================================================================
   AUTHOR BOX
   ===================================================================== */

if ( ! function_exists( 'terra_blue_author_box' ) ) :
function terra_blue_author_box() {
	$author_id  = get_the_author_meta( 'ID' );
	$bio        = get_the_author_meta( 'description' );
	$posts_url  = get_author_posts_url( $author_id );
	?>
	<div class="nx-author-box nx-reveal">
		<?php echo get_avatar( $author_id, 80, '', '', array( 'class' => 'nx-author-box__avatar' ) ); ?>
		<div class="nx-author-box__info">
			<p class="nx-author-box__label"><?php esc_html_e( 'Written by', 'terra-blue' ); ?></p>
			<h3 class="nx-author-box__name">
				<a href="<?php echo esc_url( $posts_url ); ?>"><?php the_author(); ?></a>
			</h3>
			<?php if ( $bio ) : ?>
			<p class="nx-author-box__bio"><?php echo wp_kses_post( $bio ); ?></p>
			<?php endif; ?>
			<a href="<?php echo esc_url( $posts_url ); ?>" class="nx-author-box__link">
				<?php printf( esc_html__( 'More posts by %s →', 'terra-blue' ), esc_html( get_the_author() ) ); ?>
			</a>
		</div>
	</div>
	<?php
}
endif;

/* =====================================================================
   RELATED POSTS
   ===================================================================== */

if ( ! function_exists( 'terra_blue_related_posts' ) ) :
function terra_blue_related_posts() {
	$tags       = wp_get_post_tags( get_the_ID(), array( 'fields' => 'ids' ) );
	$categories = wp_get_post_categories( get_the_ID(), array( 'fields' => 'ids' ) );

	$args = array(
		'posts_per_page'      => 3,
		'post__not_in'        => array( get_the_ID() ),
		'ignore_sticky_posts' => 1,
		'no_found_rows'       => true,
	);

	if ( $tags ) {
		$args['tag__in'] = $tags;
	} elseif ( $categories ) {
		$args['category__in'] = $categories;
	}

	$related = new WP_Query( $args );

	if ( ! $related->have_posts() ) return;
	?>
	<section class="nx-related nx-reveal">
		<h2 class="nx-related__title"><?php esc_html_e( 'Related Posts', 'terra-blue' ); ?></h2>
		<div class="nx-related__grid">
			<?php while ( $related->have_posts() ) : $related->the_post(); ?>
			<article class="nx-related__item nx-card">
				<?php if ( has_post_thumbnail() ) : ?>
				<a class="nx-related__thumbnail" href="<?php the_permalink(); ?>" tabindex="-1">
					<?php the_post_thumbnail( 'terra-blue-card' ); ?>
				</a>
				<?php endif; ?>
				<div class="nx-related__body">
					<?php terra_blue_post_categories(); ?>
					<h3 class="nx-related__post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
					<time class="nx-related__date"><?php echo esc_html( get_the_date() ); ?></time>
				</div>
			</article>
			<?php endwhile; wp_reset_postdata(); ?>
		</div>
	</section>
	<?php
}
endif;

/* =====================================================================
   SHARE LINKS
   ===================================================================== */

if ( ! function_exists( 'terra_blue_share_links' ) ) :
function terra_blue_share_links() {
	$url   = urlencode( get_permalink() );
	$title = urlencode( get_the_title() );

	$links = array(
		'twitter'  => array(
			'url'   => "https://twitter.com/intent/tweet?url={$url}&text={$title}",
			'label' => esc_html__( 'Twitter/X', 'terra-blue' ),
			'icon'  => '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.744l7.73-8.835L1.254 2.25H8.08l4.259 5.633L18.244 2.25zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>',
		),
		'linkedin' => array(
			'url'   => "https://www.linkedin.com/sharing/share-offsite/?url={$url}",
			'label' => esc_html__( 'LinkedIn', 'terra-blue' ),
			'icon'  => '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 0 1-2.063-2.065 2.064 2.064 0 1 1 2.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>',
		),
		'facebook' => array(
			'url'   => "https://www.facebook.com/sharer/sharer.php?u={$url}",
			'label' => esc_html__( 'Facebook', 'terra-blue' ),
			'icon'  => '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>',
		),
		'copy'     => array(
			'url'   => '#copy',
			'label' => esc_html__( 'Copy link', 'terra-blue' ),
			'icon'  => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>',
		),
	);

	foreach ( $links as $key => $link ) {
		printf(
			'<a href="%s" class="nx-share-link nx-share-link--%s" %s title="%s" aria-label="%s" rel="noopener noreferrer">%s</a>',
			esc_url( $link['url'] ),
			esc_attr( $key ),
			$key !== 'copy' ? 'target="_blank"' : 'data-copy-link',
			esc_attr( $link['label'] ),
			esc_attr( $link['label'] ),
			$link['icon']
		);
	}
}
endif;

/* =====================================================================
   COMMENT TEMPLATE CALLBACK
   ===================================================================== */

if ( ! function_exists( 'terra_blue_comment_template' ) ) :
function terra_blue_comment_template( $comment, $args, $depth ) {
	$is_pingback = ( 'pingback' === $comment->comment_type || 'trackback' === $comment->comment_type );
	?>
	<li id="comment-<?php comment_ID(); ?>" <?php comment_class( array( 'nx-comment', $is_pingback ? 'nx-comment--ping' : '' ), $comment ); ?>>
		<?php if ( ! $is_pingback ) : ?>
		<article class="nx-comment__body">
			<header class="nx-comment__header">
				<div class="nx-comment__author-avatar">
					<?php echo get_avatar( $comment, 44, '', '', array( 'class' => 'nx-comment__avatar' ) ); ?>
				</div>
				<div class="nx-comment__meta">
					<span class="nx-comment__author-name"><?php comment_author_link(); ?></span>
					<time class="nx-comment__date" datetime="<?php comment_time( 'c' ); ?>">
						<a href="<?php echo esc_url( get_comment_link( $comment ) ); ?>">
							<?php printf( esc_html__( '%1$s at %2$s', 'terra-blue' ), get_comment_date(), get_comment_time() ); ?>
						</a>
					</time>
				</div>
				<div class="nx-comment__reply">
					<?php
					comment_reply_link( array_merge( $args, array(
						'add_below' => 'comment',
						'depth'     => $depth,
						'max_depth' => $args['max_depth'],
						'before'    => '',
						'after'     => '',
					) ) );
					?>
				</div>
			</header>

			<?php if ( '0' === $comment->comment_approved ) : ?>
			<p class="nx-comment__moderated"><em><?php esc_html_e( 'Your comment is awaiting moderation.', 'terra-blue' ); ?></em></p>
			<?php endif; ?>

			<div class="nx-comment__content"><?php comment_text(); ?></div>
		</article>
		<?php else : ?>
		<div class="nx-comment__ping">
			<?php _e( 'Pingback:', 'terra-blue' ); ?> <?php comment_author_link(); ?>
		</div>
		<?php endif; ?>
	<?php
	// Note: no closing </li> — Walker adds it
}
endif;
