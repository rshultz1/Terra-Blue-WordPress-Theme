<?php
/**
 * Template helper functions
 *
 * @package Terra-Blue
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* =====================================================================
   FALLBACK NAVIGATION
   ===================================================================== */

if ( ! function_exists( 'terra_blue_fallback_nav' ) ) :
/**
 * Fallback navigation when no menu is assigned to the primary location.
 * Outputs a simple page list so the site is never left with no navigation.
 */
function terra_blue_fallback_nav() {
	echo '<ul id="primary-menu" class="nx-nav-menu" role="menubar">';

	// Home link
	printf(
		'<li class="nx-nav__item nx-nav__item--top%s"><a href="%s" class="nx-nav__link nx-nav__link--top%s">%s</a></li>',
		is_front_page() ? ' current-menu-item' : '',
		esc_url( home_url( '/' ) ),
		is_front_page() ? ' nx-nav__link--active' : '',
		esc_html__( 'Home', 'terra-blue' )
	);

	// Top-level pages
	$pages = get_pages( [
		'sort_column' => 'menu_order',
		'sort_order'  => 'ASC',
		'parent'      => 0,
	] );

	foreach ( $pages as $page ) {
		$is_current = is_page( $page->ID );
		printf(
			'<li class="nx-nav__item nx-nav__item--top%s"><a href="%s" class="nx-nav__link nx-nav__link--top%s"%s>%s</a></li>',
			$is_current ? ' current-menu-item' : '',
			esc_url( get_permalink( $page->ID ) ),
			$is_current ? ' nx-nav__link--active' : '',
			$is_current ? ' aria-current="page"' : '',
			esc_html( $page->post_title )
		);
	}

	// Assign a menu prompt for admins
	if ( current_user_can( 'manage_options' ) ) {
		printf(
			'<li class="nx-nav__item nx-nav__item--top"><a href="%s" class="nx-nav__link nx-nav__link--top" style="opacity:.5;font-size:.85em;">%s</a></li>',
			esc_url( admin_url( 'nav-menus.php' ) ),
			esc_html__( '+ Assign Menu', 'terra-blue' )
		);
	}

	echo '</ul>';
}
endif;
