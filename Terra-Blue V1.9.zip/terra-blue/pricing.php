<?php
defined( 'ABSPATH' ) || exit;
/**
 * Template Name: Pricing
 * Description: A pricing page layout optimised for block-based pricing tables.
 *
 * @package Terra-Blue
 */

get_header(); ?>

<div class="nx-container-wide nx-section nx-pricing-template">

	<?php while ( have_posts() ) : the_post(); ?>

		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

			<header class="nx-page-header" style="text-align: center;">
				<?php the_title( '<h1 class="nx-page-title">', '</h1>' ); ?>
				<?php if ( has_excerpt() ) : ?>
					<div class="nx-page-subtitle"><?php the_excerpt(); ?></div>
				<?php endif; ?>
			</header>

			<div class="entry-content nx-entry-content">
				<?php the_content(); ?>
			</div>

		</article>

		<?php if ( comments_open() || get_comments_number() ) : ?>
			<?php comments_template(); ?>
		<?php endif; ?>

	<?php endwhile; ?>

</div>

<?php get_footer(); ?>
