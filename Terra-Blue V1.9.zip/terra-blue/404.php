<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package Terra-Blue
 */

defined( 'ABSPATH' ) || exit;


get_header();
?>

<main id="main" class="nx-site-main">
<div class="nx-container-wide">

	<div class="nx-error-page nx-reveal">
		<div class="nx-error-page__graphic" aria-hidden="true">
			<span class="nx-error-page__number nx-gradient-text">404</span>
			<div class="nx-error-page__orbit">
				<div class="nx-error-page__planet"></div>
			</div>
		</div>

		<div class="nx-error-page__content">
			<h1 class="nx-error-page__title"><?php esc_html_e( 'Page Not Found', 'terra-blue' ); ?></h1>
			<p class="nx-error-page__text">
				<?php esc_html_e( "The page you're looking for has drifted into another dimension — or maybe it was never here.", 'terra-blue' ); ?>
			</p>

			<div class="nx-error-page__actions">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="nx-button nx-button--primary">
					<?php esc_html_e( '← Back to Home', 'terra-blue' ); ?>
				</a>
				<a href="<?php echo esc_url( get_search_link() ); ?>" class="nx-button nx-button--ghost">
					<?php esc_html_e( 'Search', 'terra-blue' ); ?>
				</a>
			</div>

			<div class="nx-error-page__search">
				<p><?php esc_html_e( 'Or try searching:', 'terra-blue' ); ?></p>
				<?php get_search_form(); ?>
			</div>
		</div>

		<?php
		$recent = new WP_Query( array(
			'posts_per_page' => 3,
			'post_status'    => 'publish',
			'no_found_rows'  => true,
		) );
		if ( $recent->have_posts() ) :
		?>
		<div class="nx-error-page__recent">
			<h2 class="nx-error-page__recent-title"><?php esc_html_e( 'Recent Posts', 'terra-blue' ); ?></h2>
			<ul class="nx-error-page__recent-list">
				<?php while ( $recent->have_posts() ) : $recent->the_post(); ?>
				<li>
					<a href="<?php the_permalink(); ?>" class="nx-error-page__recent-link">
						<?php if ( has_post_thumbnail() ) : ?>
						<span class="nx-error-page__recent-thumb">
							<?php the_post_thumbnail( 'thumbnail' ); ?>
						</span>
						<?php endif; ?>
						<span class="nx-error-page__recent-text">
							<strong><?php the_title(); ?></strong>
							<time><?php echo esc_html( get_the_date() ); ?></time>
						</span>
					</a>
				</li>
				<?php endwhile; wp_reset_postdata(); ?>
			</ul>
		</div>
		<?php endif; ?>

	</div>

</div>
</main>

<?php get_footer(); ?>
